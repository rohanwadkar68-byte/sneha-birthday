import React from 'react';
import { BotState } from '../types';
import { AlertTriangle, CheckCircle2, ShieldAlert, Cpu, BarChart3, TrendingUp } from 'lucide-react';

interface Props {
  state: BotState;
}

export const AetherMarketReport: React.FC<Props> = ({ state }) => {
  const closedTrades = state.trades.filter(t => t.status === 'CLOSED');
  const avgRR = state.metrics.avgWin / (Math.abs(state.metrics.avgLoss) || 1);
  
  const recommendations = [
    {
      title: "Risk-to-Reward Efficiency",
      value: `${avgRR.toFixed(2)}x`,
      status: avgRR >= 3.0 ? 'EXCELLENT' : avgRR >= 2.0 ? 'NOMINAL' : 'CRITICAL',
      desc: avgRR < 3.0 ? "Targeting higher RR (1:3+) is required to offset frequency of stop-outs." : "Maintaining elite RR consistency."
    },
    {
      title: "Drawdown Protection",
      value: `${state.metrics.maxDrawdown.toFixed(1)}%`,
      status: state.metrics.maxDrawdown <= 5 ? 'EXCELLENT' : state.metrics.maxDrawdown <= 15 ? 'NOMINAL' : 'CRITICAL',
      desc: state.metrics.maxDrawdown > 15 ? "Aggressive de-leveraging engaged to protect core capital." : "Portfolio delta within safe institutional bounds."
    },
    {
      title: "Win-Loss Delta",
      value: `${state.metrics.winRate.toFixed(0)}%`,
      status: state.metrics.winRate >= 45 ? 'EXCELLENT' : state.metrics.winRate >= 30 ? 'NOMINAL' : 'CRITICAL',
      desc: state.metrics.winRate < 30 ? "Filtering for high-probability clusters only. Quality over quantity." : "Healthy sample size of winning executions."
    }
  ];

  return (
    <div className="bg-[#0A0A0A] border border-[#1A1B1E] rounded-lg overflow-hidden flex flex-col shadow-2xl">
      <div className="p-3 border-b border-[#1A1B1E] bg-[#111] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Cpu className="w-3.5 h-3.5 text-purple-500" />
          <span className="text-[10px] font-mono font-black uppercase tracking-[0.2em] text-white">Aether_System_Audit</span>
        </div>
        <div className="text-[8px] font-mono text-[#4A4A4A] bg-black px-2 py-0.5 rounded border border-[#1A1B1E] uppercase leading-none pt-1">
          REVISION_163.V2
        </div>
      </div>
      
      <div className="p-4 space-y-4">
        <div className="grid grid-cols-1 gap-3">
          {recommendations.map((rec, i) => (
            <div key={i} className="p-3 bg-black border border-[#141414] rounded relative group hover:border-[#1A1B1E] transition-all">
              <div className="flex justify-between items-start mb-1">
                <span className="text-[9px] font-mono text-[#4E4E4E] uppercase font-bold tracking-widest">{rec.title}</span>
                <span className={`text-[10px] font-mono font-black ${rec.status === 'EXCELLENT' ? 'text-green-500' : rec.status === 'NOMINAL' ? 'text-blue-400' : 'text-red-500 underline decoration-red-500/50 underline-offset-4'}`}>
                  {rec.value}
                </span>
              </div>
              <p className="text-[9px] font-mono text-[#666] leading-relaxed pr-8 italic">
                {rec.desc}
              </p>
              <div className="absolute right-3 top-1/2 -translate-y-1/2 opacity-20 group-hover:opacity-100 transition-opacity">
                {rec.status === 'EXCELLENT' && <CheckCircle2 className="w-4 h-4 text-green-500" />}
                {rec.status === 'NOMINAL' && <BarChart3 className="w-4 h-4 text-blue-400" />}
                {rec.status === 'CRITICAL' && <AlertTriangle className="w-4 h-4 text-red-500 animate-pulse" />}
              </div>
            </div>
          ))}
        </div>

        <div className="pt-2 border-t border-[#141414]">
          <div className="flex items-center gap-2 mb-2">
            <ShieldAlert className="w-3 h-3 text-orange-500" />
            <span className="text-[8px] font-mono font-bold text-orange-500 uppercase tracking-widest">Active_Strategy_Performance</span>
          </div>
          <div className="space-y-2">
             {(Object.entries(state.strategyPerformance) as [string, { wins: number; losses: number; totalProfit: number }][]).slice(0, 3).map(([name, perf]) => (
                <div key={name} className="flex items-center justify-between">
                   <div className="flex flex-col">
                      <span className="text-[9px] font-mono text-[#4A4A4A] truncate w-24 uppercase">{name.split('_').pop()}</span>
                      <div className="w-24 h-1 bg-[#111] rounded-full overflow-hidden mt-0.5">
                         <div className="h-full bg-green-500/50" style={{ width: `${(perf.wins / (perf.wins + perf.losses || 1)) * 100}%` }} />
                      </div>
                   </div>
                   <div className="flex flex-col items-end">
                      <span className={`text-[10px] font-mono font-bold ${perf.totalProfit >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                         {perf.totalProfit >= 0 ? '+' : ''}${perf.totalProfit.toFixed(1)}
                      </span>
                      <span className="text-[7px] font-mono text-[#333]">SR: {(perf.wins / (perf.wins + perf.losses || 1) * 10).toFixed(1)}/10</span>
                   </div>
                </div>
             ))}
          </div>
        </div>

        <button className="w-full py-2 bg-[#111] border border-[#1A1B1E] hover:bg-[#1A1A1A] rounded text-[9px] font-mono font-black text-[#4A4A4A] hover:text-white uppercase tracking-widest transition-all">
           Generate Detailed PDF Audit
        </button>
      </div>
    </div>
  );
};

import React from 'react';
import { TradingMetrics } from '../types';
import { Target, TrendingUp, TrendingDown, Percent, Zap } from 'lucide-react';

interface Props {
  metrics: TradingMetrics;
  balance: number;
}

export const PerformanceStats: React.FC<Props> = ({ metrics, balance }) => {
  return (
    <div className="grid grid-cols-5 gap-4 h-full">
      <div className="flex flex-col justify-center border-r border-[#1A1B1E] pr-4">
        <div className="flex items-center gap-1.5 mb-1">
          <Percent className="w-3 h-3 text-[#4A4A4A]" />
          <span className="text-[7px] text-[#4A4A4A] uppercase font-bold tracking-widest">Sharpe_Ratio</span>
        </div>
        <span className={`text-lg font-black font-mono transition-colors ${metrics.sharpeRatio > 2 ? 'text-green-500 shadow-[0_0_15px_rgba(34,197,94,0.2)]' : 'text-white'}`}>
          {metrics.sharpeRatio.toFixed(2)}
        </span>
      </div>

      <div className="flex flex-col justify-center border-r border-[#1A1B1E] px-4">
        <div className="flex items-center gap-1.5 mb-1">
          <Target className="w-3 h-3 text-[#4A4A4A]" />
          <span className="text-[7px] text-[#4A4A4A] uppercase font-bold tracking-widest">Profit_Factor</span>
        </div>
        <span className={`text-lg font-black font-mono transition-colors ${metrics.profitFactor > 1.5 ? 'text-cyan-400' : 'text-white'}`}>
          {metrics.profitFactor.toFixed(2)}
        </span>
      </div>

      <div className="flex flex-col justify-center border-r border-[#1A1B1E] px-4">
        <div className="flex items-center gap-1.5 mb-1">
          <TrendingDown className="w-3 h-3 text-red-500/50" />
          <span className="text-[7px] text-[#4A4A4A] uppercase font-bold tracking-widest">Max_Drawdown</span>
        </div>
        <span className="text-lg font-black font-mono text-red-500">
          -{metrics.maxDrawdown.toFixed(2)}%
        </span>
      </div>

      <div className="flex flex-col justify-center border-r border-[#1A1B1E] px-4">
        <div className="flex items-center gap-1.5 mb-1">
          <TrendingUp className="w-3 h-3 text-green-500/50" />
          <span className="text-[7px] text-[#4A4A4A] uppercase font-bold tracking-widest">Avg_Winner</span>
        </div>
        <span className="text-lg font-black font-mono text-green-500">
          +${metrics.avgWin.toFixed(2)}
        </span>
      </div>

      <div className="flex flex-col justify-center pl-4 bg-white/5 rounded px-3">
        <div className="flex items-center gap-1.5 mb-1">
          <Zap className="w-3 h-3 text-yellow-500" />
          <span className="text-[7px] text-white uppercase font-black tracking-widest">Growth_Exp</span>
        </div>
        <span className="text-lg font-black font-mono text-white">
          {((balance / 50 - 1) * 100).toFixed(1)}%
        </span>
      </div>
    </div>
  );
};

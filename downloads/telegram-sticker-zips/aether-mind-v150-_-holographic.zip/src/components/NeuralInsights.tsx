import React from 'react';
import { BotState, MarketInsight } from '../types';
import { Brain, AlertTriangle, CheckCircle2, Zap } from 'lucide-react';
import { motion } from 'motion/react';

interface Props {
  state: BotState;
  insights: MarketInsight[];
}

export const NeuralInsights: React.FC<Props> = ({ state, insights }) => {
  return (
    <div className="bg-[#0A0A0A] border border-[#1A1B1E] flex flex-col h-full shadow-2xl">
      <div className="p-3 border-b border-[#1A1B1E] bg-[#111] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Brain className="w-4 h-4 text-pink-400" />
          <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">Neural_Synapse_Storage 🧠</span>
        </div>
        <span className="text-[8px] font-mono text-[#333]">V150_AETHER_MIND_SYNC</span>
      </div>

      <div className="p-3 space-y-3 bg-[#080808] border-b border-[#1A1B1E]">
        <div className="flex justify-between items-center mb-1">
          <div className="text-[8px] font-mono text-[#4A4A4A] uppercase tracking-tighter">Holographic decision nodes (LIVE)</div>
          <div className="text-[7px] font-mono text-pink-500 font-bold animate-pulse">AETHER_CORE: V150_ACTIVE</div>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <div className="flex flex-col gap-1">
            <span className="text-[7px] font-mono text-[#4A4A4A]">Institutional</span>
            <div className="h-1.5 w-full bg-[#111] rounded-full overflow-hidden">
               <motion.div 
                 initial={{ width: 0 }}
                 animate={{ width: `${Math.min(100, (state.nexusNodes?.smc || 0) / 2)}%` }}
                 className="h-full bg-cyan-500 shadow-[0_0_8px_rgba(6,182,212,0.5)]" 
               />
            </div>
            <span className="text-[9px] font-mono text-cyan-400 font-bold">{(state.nexusNodes?.smc || 0).toFixed(0)}</span>
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-[7px] font-mono text-[#4A4A4A]">Momentum</span>
            <div className="h-1.5 w-full bg-[#111] rounded-full overflow-hidden">
               <motion.div 
                 initial={{ width: 0 }}
                 animate={{ width: `${Math.min(100, (state.nexusNodes?.momentum || 0) / 1.5)}%` }}
                 className="h-full bg-pink-500 shadow-[0_0_8px_rgba(236,72,153,0.5)]" 
               />
            </div>
            <span className="text-[9px] font-mono text-pink-400 font-bold">{(state.nexusNodes?.momentum || 0).toFixed(0)}</span>
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-[7px] font-mono text-[#4A4A4A]">Environmental</span>
            <div className="h-1.5 w-full bg-[#111] rounded-full overflow-hidden">
               <motion.div 
                 initial={{ width: 0 }}
                 animate={{ width: `${Math.min(100, (state.nexusNodes?.context || 0) / 1.5)}%` }}
                 className="h-full bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.5)]" 
               />
            </div>
            <span className="text-[9px] font-mono text-orange-400 font-bold">{(state.nexusNodes?.context || 0).toFixed(0)}</span>
          </div>
        </div>
      </div>

      <div className="p-4 grid grid-cols-2 gap-4 border-b border-[#1A1B1E] bg-[#050505]">
          <div className="bg-[#080808] border border-[#1A1B1E] p-3 rounded">
             <div className="text-[8px] font-mono text-[#4A4A4A] uppercase mb-1">Human Lessons</div>
             <div className="flex items-center gap-2">
                <Zap size={14} className="text-yellow-500" />
                <span className="text-xl font-mono font-bold text-white">48</span>
             </div>
          </div>
          <div className="bg-[#080808] border border-[#1A1B1E] p-3 rounded">
             <div className="text-[8px] font-mono text-[#4A4A4A] uppercase mb-1">Sync_State</div>
             <div className="text-xs font-mono text-cyan-400 font-bold">SOVEREIGN_V150</div>
          </div>
      </div>

      <div className="flex-1 overflow-y-auto p-2 space-y-2 scrollbar-none">
        <div className="text-[9px] font-mono text-[#4A4A4A] uppercase px-2 py-1 flex items-center gap-2">
           <Brain size={10} /> Learned Insights
        </div>
        
        {insights.length === 0 ? (
           <div className="p-8 text-center text-[9px] font-mono text-[#333]">Waiting for trade outcome analysis...</div>
        ) : (
          insights.map((insight, i) => (
            <div key={i} className="bg-[#080808] border border-[#1A1B1E] p-2 rounded hover:border-[#333] transition-colors">
              <div className="flex justify-between items-center mb-1">
                <span className={`text-[8px] font-mono font-bold uppercase ${insight.successRate > 50 ? 'text-green-500' : 'text-red-500'}`}>
                   {insight.pattern} @ {insight.environment}
                </span>
                <span className="text-[8px] font-mono text-gray-500 flex items-center gap-2">
                  {insight.successRate}% SR <span>{new Date(insight.lastObserved).toLocaleTimeString()}</span>
                </span>
              </div>
              <p className="text-[9px] font-mono text-gray-300 flex items-start gap-2">
                {insight.successRate > 50 ? <CheckCircle2 size={10} className="text-green-500 shrink-0 mt-0.5" /> : <AlertTriangle size={10} className="text-red-500 shrink-0 mt-0.5" />}
                {insight.lesson}
              </p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

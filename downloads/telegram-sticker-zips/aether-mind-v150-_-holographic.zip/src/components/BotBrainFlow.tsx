/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BotState } from '../types';
import { Activity, Brain, Target, Shield, Zap, TrendingUp, Search, CheckCircle2, AlertTriangle, MessageSquare } from 'lucide-react';

interface Props {
  state: BotState;
}

const steps = [
  { id: 'MarketData', label: 'Market Data', icon: Activity },
  { id: 'Context', label: 'Context Engine', icon: Search },
  { id: 'Strategy', label: 'Strategy', icon: Brain },
  { id: 'Setup', label: 'Setup Detection', icon: Target },
  { id: 'Score', label: 'Scoring', icon: Zap },
  { id: 'AI', label: 'AI Filter', icon: Shield },
  { id: 'Trade', label: 'Execution', icon: TrendingUp },
];

export const BotBrainFlow: React.FC<Props> = ({ state }) => {
  const currentHour = new Date().getUTCHours();
  const isInstitutionalWindow = (currentHour >= 7 && currentHour <= 10) || (currentHour >= 12 && currentHour <= 15);
  
  let baseRequirement = isInstitutionalWindow ? 3.5 : 3.2;
  if (state.isScalpingEnabled) baseRequirement = 2.8;

  return (
    <div className="flex flex-col h-full">
      <div className="mb-2 p-2 bg-[#111] border border-[#1A1B1E] flex items-center justify-between rounded-t">
        <span className="text-[8px] font-mono text-[#4A4A4A] uppercase font-bold tracking-widest">Institutional_Window</span>
        <div className="flex items-center gap-2">
          <span className={`text-[9px] font-mono font-bold ${isInstitutionalWindow ? 'text-green-500' : 'text-[#333]'}`}>
            {isInstitutionalWindow ? 'ACTIVE_SESSION' : 'LOW_VOLUME_IDLE'}
          </span>
          <div className={`w-1.5 h-1.5 rounded-full ${isInstitutionalWindow ? 'bg-green-500 animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.5)]' : 'bg-[#1A1B1E]'}`} />
        </div>
      </div>
      <div className="space-y-[1px] bg-[#1A1B1E]">
        {steps.map((step, index) => {
          const isActive = true; // Always active for visualization
          const StepIcon = step.icon;
          
          let statusText = 'WAITING';
          let statusColor = 'text-[#4A4A4A]';
          let bgColor = 'bg-[#0A0A0A]';

          if (step.id === 'Context') {
            statusText = state.environment;
            statusColor = 'text-blue-500';
          } else if (step.id === 'Strategy') {
            statusText = state.activeStrategy || 'SEARCHING';
            statusColor = 'text-purple-500';
          } else if (step.id === 'Setup') {
            statusText = state.setupFound ? 'DETECTION_ACK' : 'SCAN_IDLE';
            statusColor = state.setupFound ? 'text-green-500' : 'text-[#4A4A4A]';
          } else if (step.id === 'Score') {
            statusText = `SIG_VAL: ${state.score.toFixed(1)}`;
            statusColor = state.score >= baseRequirement ? 'text-yellow-500' : 'text-[#4A4A4A]';
          } else if (step.id === 'AI') {
            statusText = state.aiValidation;
            statusColor = state.aiValidation === 'VALID' ? 'text-green-500' : (state.aiValidation === 'REJECTED' ? 'text-red-500' : 'text-[#4A4A4A]');
          } else if (step.id === 'MarketData') {
            statusText = 'RECLAIMING';
            statusColor = 'text-green-500';
          } else if (step.id === 'Trade') {
            statusText = state.trades.length > 0 ? (state.trades[0].status === 'OPEN' ? 'EXECUTED' : 'LEDGER_LOCKED') : 'STANDBY';
            statusColor = 'text-white';
          }

          return (
            <motion.div 
              key={step.id}
              className={`flex items-center justify-between p-2 ${bgColor} border-b border-[#1A1B1E]`}
            >
              <div className="flex items-center gap-3">
                <StepIcon className={`w-3 h-3 ${state.setupFound && index < 4 ? 'text-white' : 'text-[#4A4A4A]'}`} />
                <span className="text-[9px] font-mono text-[#8E9299] uppercase tracking-tighter">{step.label}</span>
              </div>
              
              <div className={`text-[9px] font-mono tracking-widest font-bold ${statusColor}`}>
                {statusText}
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="mt-4 bg-[#0A0A0A] border border-[#1A1B1E] flex flex-col h-40">
        <div className="p-2 border-b border-[#1A1B1E] bg-[#111] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-3 h-3 text-[#4A4A4A]" />
            <span className="text-[8px] text-[#4A4A4A] font-mono font-bold uppercase tracking-[0.2em]">Synaptic_Logs</span>
          </div>
          <span className="text-[7px] font-mono text-green-500 underline">ENCRYPTED</span>
        </div>
        <div className="flex-1 overflow-y-auto space-y-1 font-mono text-[8px] p-3 scrollbar-none leading-tight">
          {state.logs.map((log) => {
             const isAudit = log.message.includes('AUDIT');
             const isAlert = log.message.includes('ALERT');
             const isStep = log.message.includes('STEP');
             const isMemory = log.message.includes('MEMORY') || log.message.includes('NEURAL');
             const isDiag = log.message.includes('DIAGNOSTIC');
             const isInst = log.message.includes('INSTITUTIONAL') || log.message.includes('HTF');
             
             let color = 'text-[#8E9299]';
             if (isAudit) color = 'text-green-400';
             if (isAlert) color = 'text-orange-500';
             if (isStep) color = 'text-blue-400/80';
             if (isMemory) color = 'text-purple-400';
             if (isDiag) color = 'text-gray-500 italic';
             if (isInst) color = 'text-cyan-400 font-bold';

             return (
              <div key={log.id} className={`${color} hover:text-white transition-colors cursor-crosshair border-l border-white/5 pl-2 py-0.5`}>
                <span className="text-[#333] mr-1">[{log.time}]</span>
                {log.message}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

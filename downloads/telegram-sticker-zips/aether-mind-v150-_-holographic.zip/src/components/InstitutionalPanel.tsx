/**
 * Institutional Elite Panel
 * Displays Higher Timeframe (HTF) Bias and Liquidity Map targets.
 */

import React from 'react';
import { BotState } from '../types';
import { Target, TrendingUp, TrendingDown, Layers, Map as MapIcon, ShieldCheck } from 'lucide-react';

interface Props {
  state: BotState;
}

export const InstitutionalPanel: React.FC<Props> = ({ state }) => {
  const biasColor = state.htfBias === 'BULLISH' ? 'text-green-400' : (state.htfBias === 'BEARISH' ? 'text-red-400' : 'text-gray-400');
  
  return (
    <div className="bg-[#0A0A0A] border border-[#1A1B1E] p-4 rounded flex flex-col gap-4">
      {/* Header with Account Health */}
      <div className="flex items-center justify-between border-b border-[#1A1B1E] pb-3">
        <div className="flex flex-col">
          <h3 className="text-[#8E9299] font-mono text-[10px] uppercase tracking-widest flex items-center gap-2">
            <ShieldCheck size={14} className="text-orange-500" />
            V34_Humanoid_Core
          </h3>
          <span className="text-[10px] font-mono text-cyan-400 mt-0.5">Wallet_Health: OK</span>
        </div>
        <div className="flex flex-col items-end">
          <span className={`font-mono text-xs font-bold ${state.monthlyPnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            {state.monthlyPnl >= 0 ? '+' : ''}${state.monthlyPnl.toFixed(2)}
          </span>
          <span className="text-[8px] font-mono text-[#8E9299] uppercase">30D_Net_PnL</span>
        </div>
      </div>

      {/* Narrative Section (The Mental Log) */}
      <div className="bg-[#0C0D0F] p-4 border border-[#1A1B1E] rounded-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 p-2">
          <Target size={12} className="text-[#1A1B1E]" />
        </div>
        <div className="text-[9px] uppercase text-[#8E9299] mb-2 font-mono flex items-center justify-between">
          <span>Decision_Narrative</span>
          <span className={`${state.htfBias === 'BULLISH' ? 'text-green-400' : 'text-red-400'}`}>{state.htfBias}</span>
        </div>
        <div className="text-[11px] text-white font-mono italic leading-relaxed">
          " {state.tradingPlan} "
        </div>
      </div>

      {/* Daily Progress Grid */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-[#050505] p-3 border border-[#1A1B1E] rounded-lg">
          <div className="text-[8px] uppercase text-[#8E9299] mb-2 font-mono flex justify-between">
            <span>Daily_Profit</span>
            <span className="text-green-400">Goal: 4%</span>
          </div>
          <div className="flex items-end justify-between mb-2">
             <span className="text-xs font-mono font-bold">${state.dailyProfit.toFixed(2)}</span>
             <span className="text-[8px] text-[#4A4A4A] font-mono">/ ${state.dailyProfitTarget.toFixed(2)}</span>
          </div>
          <div className="h-1 bg-[#1A1B1E] rounded-full overflow-hidden">
             <div 
               className={`h-full transition-all duration-700 ${state.dailyProfit >= state.dailyProfitTarget ? 'bg-green-400' : 'bg-cyan-500'}`}
               style={{ width: `${Math.min(100, (state.dailyProfit / state.dailyProfitTarget) * 100)}%` }}
             />
          </div>
        </div>

        <div className="bg-[#050505] p-3 border border-[#1A1B1E] rounded-lg">
          <div className="text-[8px] uppercase text-[#8E9299] mb-2 font-mono flex justify-between">
             <span>Daily_Risk</span>
             <span className="text-red-400">Limit: 2%</span>
          </div>
          <div className="flex items-end justify-between mb-2">
             <span className="text-xs font-mono font-bold">${state.dailyLoss.toFixed(2)}</span>
             <span className="text-[8px] text-[#4A4A4A] font-mono">/ ${state.dailyLossLimit.toFixed(2)}</span>
          </div>
          <div className="h-1 bg-[#1A1B1E] rounded-full overflow-hidden">
             <div 
               className="h-full bg-red-500 transition-all duration-500"
               style={{ width: `${Math.min(100, (state.dailyLoss / state.dailyLossLimit) * 100)}%` }}
             />
          </div>
        </div>
      </div>

      {/* Market Intel Grid */}
      <div className="grid grid-cols-4 gap-2">
        <div className="bg-[#080808] p-2 border border-[#1A1B1E] rounded text-center">
          <div className="text-[7px] text-[#4A4A4A] uppercase font-mono mb-1">Trades</div>
          <div className="text-[9px] font-mono font-bold text-white">
            {state.trades.filter(t => new Date(t.time).toDateString() === new Date().toDateString()).length}
          </div>
        </div>
        <div className="bg-[#080808] p-2 border border-[#1A1B1E] rounded text-center">
          <div className="text-[7px] text-[#4A4A4A] uppercase font-mono mb-1">Structure</div>
          <div className="text-[9px] font-mono font-bold text-white truncate px-1">{state.marketPhase || 'SYNCING'}</div>
        </div>
        <div className="bg-[#080808] p-2 border border-[#1A1B1E] rounded text-center">
          <div className="text-[7px] text-[#4A4A4A] uppercase font-mono mb-1">Setup</div>
          <div className={`text-[9px] font-mono font-bold ${state.setupFound ? 'text-cyan-400' : 'text-orange-500'}`}>{state.score.toFixed(0)} α</div>
        </div>
        <div className="bg-[#080808] p-2 border border-[#1A1B1E] rounded text-center">
          <div className="text-[7px] text-[#4A4A4A] uppercase font-mono mb-1">Win_Rate</div>
          <div className="text-[9px] font-mono font-bold text-white">{state.monthlyWinRate.toFixed(0)}%</div>
        </div>
      </div>

      {/* Neural Performance Tracker */}
      <div className="bg-[#050505] p-3 border border-[#1A1B1E] rounded-lg">
        <div className="text-[8px] uppercase text-[#8E9299] mb-3 font-mono flex items-center gap-2">
          <Layers size={12} className="text-cyan-400" />
          Neural_Accuracy_Vectors
        </div>
        <div className="grid grid-cols-3 gap-3">
          {Object.entries(state.strategyPerformance || {}).map(([name, stats]) => {
            const castStats = stats as { wins: number, losses: number, totalProfit: number };
            const total = castStats.wins + castStats.losses;
            const rate = total > 0 ? (castStats.wins / total) * 100 : 0;
            return (
              <div key={name} className="flex flex-col">
                <span className="text-[7px] text-[#4A4A4A] font-mono truncate mb-1">{name.replace('SMC_', '')}</span>
                <div className="flex items-baseline gap-1">
                   <span className={`text-[11px] font-mono font-bold ${rate > 55 ? 'text-green-400' : 'text-gray-300'}`}>{rate.toFixed(0)}%</span>
                   <span className="text-[7px] text-[#4A4A4A] font-mono">WR</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

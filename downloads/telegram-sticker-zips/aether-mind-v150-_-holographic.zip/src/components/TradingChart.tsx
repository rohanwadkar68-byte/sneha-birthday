/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ComposedChart, Bar, Line } from 'recharts';
import { Candle, BotState } from '../types';
import { market } from '../lib/marketEngine';

interface Props {
  data: Candle[];
  state: BotState;
}

export const TradingChart: React.FC<Props> = ({ data, state }) => {
  // Format data for recharts
  const chartData = data.map((d, i) => ({
    ...d,
    index: i,
    // Candle body
    candleTop: Math.max(d.open, d.close),
    candleBottom: Math.min(d.open, d.close),
    // Wick
    wickHigh: d.high,
    wickLow: d.low,
    color: d.close >= d.open ? '#00FF00' : '#FF0000'
  }));

  const domain = [
    Math.min(...data.map(d => d.low), market.getInstitutionalLevels()?.pdl || 999999) - 50,
    Math.max(...data.map(d => d.high), market.getInstitutionalLevels()?.pdh || 0) + 50
  ];

  return (
    <div className="w-full h-full bg-[#050505] p-2 rounded border border-[#1A1B1E] relative overflow-hidden group">
      {/* Neural Grid Overlay */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.03]" 
           style={{ backgroundImage: 'radial-gradient(#ffffff 0.5px, transparent 0.5px)', backgroundSize: '20px 20px' }} />
      
      <div className="absolute top-4 left-4 z-10 flex flex-col gap-1">
        <h3 className="text-[#8E9299] font-mono text-[10px] uppercase tracking-[0.2em] flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
          Neural_Flux_Stream :: {state.currentAsset === 'GOLD' ? 'XAUUSD' : 'BTCUSDT'}
        </h3>
        <p className="text-[8px] font-mono text-[#4A4A4A] tracking-tighter uppercase italic">
          Fetching high-fidelity Binance liquidity clusters...
        </p>
      </div>

      <div className="absolute top-4 right-20 z-10 flex gap-4">
        <div className="flex flex-col items-end">
          <span className="text-[8px] font-mono text-[#4A4A4A] uppercase text-right">Vol_Index</span>
          <span className="text-[10px] font-mono text-white">{(Math.abs(data[data.length-1].close - data[data.length-1].open) / data[data.length-1].open * 100).toFixed(3)}%</span>
        </div>
        <div className="flex flex-col items-end">
          <span className="text-[8px] font-mono text-[#4A4A4A] uppercase text-right">Alpha_Rel</span>
          <span className="text-[10px] font-mono text-cyan-400">{(state.score).toFixed(1)} SRC</span>
        </div>
      </div>
      
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={chartData} margin={{ top: 40, right: 0, bottom: 0, left: 0 }}>
          <XAxis dataKey="index" hide />
          <YAxis 
            domain={domain} 
            orientation="right" 
            tick={{ fill: '#4A4A4A', fontSize: 9, fontFamily: 'monospace' }}
            axisLine={false}
            tickLine={false}
            mirror
          />
          <Tooltip 
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                const d = payload[0].payload as Candle;
                return (
                  <div className="bg-[#0A0A0A] border border-orange-500/20 p-2 text-[10px] font-mono shadow-2xl backdrop-blur-md">
                    <div className="text-orange-500 border-b border-orange-500/10 mb-1 pb-1 font-bold uppercase tracking-wider">Node Metadata</div>
                    <div className="flex justify-between gap-4"><span>O:</span> <span className="text-white">{d.open.toFixed(2)}</span></div>
                    <div className="flex justify-between gap-4"><span>H:</span> <span className="text-white">{d.high.toFixed(2)}</span></div>
                    <div className="flex justify-between gap-4"><span>L:</span> <span className="text-white">{d.low.toFixed(2)}</span></div>
                    <div className="flex justify-between gap-4"><span>C:</span> <span className="text-white">{d.close.toFixed(2)}</span></div>
                  </div>
                );
              }
              return null;
            }}
          />
          <CartesianGrid vertical={false} stroke="#1A1B1E" strokeDasharray="3 3" opacity={0.5} />
          
          {/* Institutional Price Action (Real Candlesticks) */}
          <Bar 
            dataKey="candleTop" 
            fill={(d: any) => d.color} 
            background={{ fill: 'transparent' }}
            isAnimationActive={false}
          />
          
          {/* Wicks */}
          <Line 
            type="monotone" 
            dataKey="wickHigh" 
            stroke="#4A4A4A" 
            strokeWidth={1} 
            dot={false} 
            isAnimationActive={false} 
          />
          <Line 
            type="monotone" 
            dataKey="wickLow" 
            stroke="#4A4A4A" 
            strokeWidth={1} 
            dot={false} 
            isAnimationActive={false} 
          />

          {/* Institutional Levels (PDH/PDL) */}
          {market.getInstitutionalLevels() && (
            <>
              <Line 
                type="monotone" 
                dataKey={() => market.getInstitutionalLevels()?.pdh} 
                stroke="#ef4444" 
                strokeDasharray="5 5" 
                strokeWidth={1} 
                dot={false} 
                isAnimationActive={false}
              />
              <Line 
                type="monotone" 
                dataKey={() => market.getInstitutionalLevels()?.pdl} 
                stroke="#22c55e" 
                strokeDasharray="5 5" 
                strokeWidth={1} 
                dot={false} 
                isAnimationActive={false}
              />
            </>
          )}

          {/* Active Price Line */}
          <Line 
            type="step" 
            dataKey="close" 
            stroke="#f97316" 
            strokeWidth={2}
            dot={false}
            isAnimationActive={false}
          />

          {/* Institutional Liquidity Maps (1H) */}
          <Line 
            type="monotone"
            dataKey={() => state.liquidityMap.buyside}
            stroke="#06b6d4" // Cyan
            strokeWidth={1}
            strokeDasharray="10 10"
            dot={false}
            opacity={0.3}
            isAnimationActive={false}
          />
          <Line 
            type="monotone"
            dataKey={() => state.liquidityMap.sellside}
            stroke="#d946ef" // Magenta
            strokeWidth={1}
            strokeDasharray="10 10"
            dot={false}
            opacity={0.3}
            isAnimationActive={false}
          />

          {/* Internal Minor Swings (Tactical) */}
          <Line 
            type="monotone"
            dataKey={() => {
              const subset = data.slice(-15);
              return subset.length > 0 ? Math.max(...subset.map(c => c.high)) : null;
            }}
            stroke="#87ceeb" // Skyblue
            strokeWidth={1}
            strokeDasharray="3 3"
            dot={false}
            opacity={0.2}
            isAnimationActive={false}
          />
          <Line 
            type="monotone"
            dataKey={() => {
              const subset = data.slice(-15);
              return subset.length > 0 ? Math.min(...subset.map(c => c.low)) : null;
            }}
            stroke="#bc8f8f" // Rosybrown
            strokeWidth={1}
            strokeDasharray="3 3"
            dot={false}
            opacity={0.2}
            isAnimationActive={false}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
};

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BotState, StrategyPerformance } from '../types';
import { Play, Loader2, BarChart3, TrendingUp, History, AlertCircle, Brain, ShieldAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Props {
  state: BotState;
  onRun: (days: number, asset: any, mode: any) => void;
}

export const BacktestPanel: React.FC<Props> = ({ state, onRun }) => {
  const [days, setDays] = useState(30);
  const [asset, setAsset] = useState('CRYPTO');
  const [mode, setMode] = useState('INSTITUTIONAL');

  return (
    <div className="bg-[#151619] rounded-xl border border-[#141414] overflow-hidden flex flex-col">
      <div className="bg-[#1A1A1A] p-3 border-b border-[#141414] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-purple-500" />
          <span className="text-xs font-mono text-white">QUANTUM BACKTESTER V4.0 💀</span>
        </div>
      </div>
      
      <div className="p-4 space-y-4 relative">
        {state.isBacktesting && (
          <div className="absolute inset-0 z-50 bg-[#050505]/60 backdrop-blur-sm flex flex-col items-center justify-center space-y-3">
             <div className="relative">
                <Loader2 className="w-8 h-8 text-purple-500 animate-spin" />
                <div className="absolute inset-0 bg-purple-500/20 blur-xl rounded-full" />
             </div>
             <div className="flex flex-col items-center">
                <span className="text-[10px] font-mono text-white animate-pulse">SYNTHESIZING ALPHA LEDGER</span>
                <span className="text-[8px] font-mono text-purple-400">CRUNCHING ${days}D DATASETS...</span>
             </div>
          </div>
        )}
        
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <label className="text-[10px] font-mono text-[#4A4A4A] uppercase">Simulation Core</label>
            <select 
              value={mode}
              onChange={(e) => setMode(e.target.value)}
              className="w-full bg-[#0A0A0A] border border-[#141414] rounded px-2 py-1.5 text-[10px] font-mono text-white focus:outline-none"
            >
              <option value="INSTITUTIONAL">INSTITUTIONAL (SMC/ICT)</option>
              <option value="SCALPING">SCALPING (DEX_SPEED)</option>
            </select>
          </div>
          <div className="space-y-1">
            <label className="text-[10px] font-mono text-[#4A4A4A] uppercase">Market Sector</label>
            <select 
              value={asset}
              onChange={(e) => setAsset(e.target.value)}
              className="w-full bg-[#0A0A0A] border border-[#141414] rounded px-2 py-1.5 text-[10px] font-mono text-white focus:outline-none"
            >
              <option value="CRYPTO">CRYPTO CLUSTER</option>
              <option value="GOLD">XAU/USD (SPOT)</option>
              <option value="FOREX">EUR/USD (LIQUIDITY)</option>
            </select>
          </div>
        </div>

        <div className="space-y-4">
          <div className="p-3 bg-black/40 border border-[#141414] rounded-lg">
            <label className="text-[10px] font-mono text-purple-400 uppercase mb-2 block tracking-widest font-bold">Simulation Intensity</label>
            <div className="space-y-3">
              <div>
                <label className="text-[9px] font-mono text-[#4A4A4A] uppercase mb-1 block">Time Horizon (Historical Depth)</label>
                <div className="flex gap-2">
                  <input 
                    type="number" 
                    value={days}
                    onChange={(e) => setDays(Number(e.target.value))}
                    disabled={state.isBacktesting}
                    placeholder="Days..."
                    className="flex-1 bg-[#0A0A0A] border border-[#141414] rounded px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-purple-500 transition-colors"
                  />
                  <div className="flex gap-1">
                    {[30, 90, 365].map((d) => (
                      <button
                        key={d}
                        onClick={() => setDays(d)}
                        disabled={state.isBacktesting}
                        className={`px-2 py-1 border transition-all text-[9px] font-mono rounded uppercase ${days === d ? 'border-purple-500 text-white bg-purple-500/10' : 'bg-[#0A0A0A] border-[#141414] text-[#4A4A4A] hover:text-white'}`}
                      >
                        {d}D
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <button 
                onClick={() => onRun(days, asset, mode)}
                disabled={state.isBacktesting}
                className="w-full py-3 bg-purple-600 hover:bg-purple-500 disabled:opacity-30 disabled:cursor-not-allowed text-white rounded font-mono text-[10px] font-black uppercase tracking-[0.2em] flex items-center justify-center gap-3 transition-all active:scale-[0.98] shadow-lg shadow-purple-600/20"
              >
                {state.isBacktesting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                {state.isBacktesting ? 'SYNTHESIZING...' : 'EXECUTE_BACKTEST'}
              </button>
            </div>
          </div>
        </div>

        <div className="pt-2 border-t border-[#141414]">
          <label className="text-[10px] font-mono text-[#4A4A4A] uppercase mb-2 block">Quick Neural Benchmarks</label>
          <div className="grid grid-cols-3 gap-2">
            <button 
              onClick={() => onRun(30, 'CRYPTO', 'INSTITUTIONAL')}
              className="py-1.5 px-2 bg-[#0A0A0A] border border-[#141414] hover:border-orange-500/50 text-[9px] font-mono text-[#4A4A4A] hover:text-white rounded transition-all"
            >
              ⚡ CRYPTO_30D
            </button>
            <button 
              onClick={() => onRun(30, 'GOLD', 'INSTITUTIONAL')}
              className="py-1.5 px-2 bg-[#0A0A0A] border border-[#141414] hover:border-yellow-500/50 text-[9px] font-mono text-[#4A4A4A] hover:text-white rounded transition-all"
            >
              🏆 GOLD_30D
            </button>
            <button 
              onClick={() => onRun(14, 'CRYPTO', 'SCALPING')}
              className="py-1.5 px-2 bg-[#0A0A0A] border border-[#141414] hover:border-cyan-500/50 text-[9px] font-mono text-[#4A4A4A] hover:text-white rounded transition-all"
            >
              🏹 SCALP_14D
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between text-[8px] font-mono p-2 bg-[#050505] border border-[#141414] rounded">
          <div className="flex flex-col">
            <span className="text-[#4A4A4A] uppercase">Selection Core</span>
            <span className="text-cyan-400 font-bold">V25_SMC_ULTRA</span>
          </div>
          <div className="flex flex-col items-end">
             <span className="text-[#4A4A4A] uppercase">Market Narrative</span>
             <span className="text-orange-500 font-bold">ICT_2022_MODEL</span>
          </div>
        </div>

        <AnimatePresence>
          {Object.keys(state.learningData).length > 0 && !state.isBacktesting && (
            <motion.div 
              key="learning-memory-section"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="mt-4 space-y-2 border-t border-[#141414] pt-4"
            >
              <h4 className="text-[10px] font-mono text-purple-400 uppercase tracking-widest flex items-center gap-2">
                <Brain className="w-3 h-3" /> Learning Memory (Global)
              </h4>
              <div className="space-y-1">
                {Object.entries(state.learningData).map(([strategy, performance]) => {
                  const perf = performance as StrategyPerformance;
                  return (
                    <div key={`perf-${strategy}`} className="flex items-center justify-between p-2 bg-[#0A0A0A]/50 rounded border border-[#141414]">
                      <span className="text-[9px] font-mono text-[#8E9299]">{strategy}</span>
                      <div className="flex gap-3">
                        <span className="text-[9px] font-mono text-green-500">{perf.winRate.toFixed(1)}% WR</span>
                        <span className="text-[9px] font-mono text-white">N: {perf.totalTrades}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          )}

          {state.lastBacktest && !state.isBacktesting && (
            <motion.div 
              key="backtest-results-section"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-3 pt-4 border-t border-[#141414]"
            >
              <div className="grid grid-cols-2 gap-2">
                <div className="bg-[#1A1A1A] p-2 rounded border border-[#141414]">
                  <div className="text-[9px] text-[#4A4A4A] uppercase font-mono">Win Rate</div>
                  <div className="text-sm font-bold font-mono text-green-500">
                    {state.lastBacktest.totalTrades > 0 ? state.lastBacktest.winRate.toFixed(1) : '0.0'}%
                  </div>
                </div>
                <div className="bg-[#1A1A1A] p-2 rounded border border-[#141414]">
                  <div className="text-[9px] text-[#4A4A4A] uppercase font-mono">Profit Factor</div>
                  <div className={`text-sm font-bold font-mono ${state.lastBacktest.profitFactor && state.lastBacktest.profitFactor >= 2 ? 'text-cyan-400' : 'text-orange-400'}`}>
                    {state.lastBacktest.totalTrades > 0 ? (state.lastBacktest.profitFactor?.toFixed(2) || '0.00') : '0.00'}
                  </div>
                </div>
                <div className="bg-[#1A1A1A] p-2 rounded border border-[#141414]">
                  <div className="text-[9px] text-[#4A4A4A] uppercase font-mono">Final PnL</div>
                  <div className={`text-sm font-bold font-mono ${state.lastBacktest.totalPnL >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                    ${state.lastBacktest.totalPnL.toFixed(2)}
                  </div>
                </div>
                <div className="bg-[#1A1A1A] p-2 rounded border border-[#141414]">
                  <div className="text-[9px] text-[#4A4A4A] uppercase font-mono">Max DD</div>
                  <div className="text-sm font-bold font-mono text-red-400">-{state.lastBacktest.maxDrawdown.toFixed(1)}%</div>
                </div>
              </div>

              {state.lastBacktest.dailyLogs && state.lastBacktest.dailyLogs.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between px-1">
                    <h5 className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest flex items-center gap-1">
                      <ShieldAlert className="w-3 h-3" /> Institutional Ledger (AMD Cycles)
                    </h5>
                    <div className="flex gap-2">
                       <span className="text-[8px] font-mono text-[#4A4A4A]">V3.0 ELITE</span>
                       <span className="text-[8px] font-mono text-green-500/80">75% TARGET EDGE</span>
                    </div>
                  </div>
                  <div className="max-h-80 overflow-y-auto space-y-1 pr-1 custom-scrollbar scroll-smooth">
                    <div className="grid grid-cols-2 gap-2 mb-2">
                       <button className="py-1 bg-[#1A1A1A] text-[9px] font-mono text-cyan-400 border border-cyan-400/20 rounded">DAILY_CHUNKS</button>
                       <button className="py-1 bg-[#0A0A0A] text-[9px] font-mono text-[#4A4A4A] border border-[#141414] rounded opacity-50">ALPHA_FEED (WIP)</button>
                    </div>
                    {state.lastBacktest.dailyLogs.map((log, idx) => (
                      <DailyLogItem key={`daily-${idx}`} log={log} idx={idx} />
                    ))}
                  </div>
                </div>
              )}
              
              <div className="bg-[#1A1A1A] p-2 rounded border border-orange-500/20 flex gap-2 items-start">
                <AlertCircle className="w-3 h-3 text-orange-500 mt-0.5" />
                <p className="text-[9px] font-mono text-[#8E9299] leading-tight italic">
                  *Simulation based on current strategy weights and ICT sweep confluences. Past performance is a memory of future opportunities 👽.
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

const DailyLogItem: React.FC<{ log: any, idx: number }> = ({ log, idx }) => {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="flex flex-col gap-1">
      <motion.div 
        initial={{ opacity: 0, x: -10 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: idx * 0.05 }}
        onClick={() => setExpanded(!expanded)}
        className="flex justify-between items-center p-2 bg-[#0A0A0A] rounded border border-[#141414] hover:border-purple-500/30 transition-colors group cursor-pointer"
      >
        <div className="flex flex-col">
          <span className="text-[10px] font-mono text-white font-bold">
            {new Date(log.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
          </span>
          <span className="text-[8px] font-mono text-[#4A4A4A]">Executed Cycles: {log.trades}</span>
        </div>
        <div className="flex flex-col items-end">
          <span className={`text-[10px] font-mono font-bold ${log.pnl >= 0 ? 'text-cyan-400' : 'text-red-400'}`}>
            {log.pnl >= 0 ? '+$' : '-$'}{Math.abs(log.pnl).toFixed(2)}
          </span>
          <div className="flex items-center gap-1 mt-1">
            <span className="text-[7px] font-mono text-cyan-400 font-bold animate-pulse">{expanded ? 'HIDE_DETAILS' : 'CLICK_TO_EXPAND'}</span>
            <div className={`w-6 h-[2px] rounded-full ${log.pnl >= 0 ? 'bg-cyan-500/50' : 'bg-red-500/50'}`} />
          </div>
        </div>
      </motion.div>
      
      <AnimatePresence>
        {expanded && log.executions && log.executions.length > 0 && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden bg-[#0A0A0A] border-x border-b border-[#141414] mx-1 rounded-b px-2 pb-2 space-y-1"
          >
            {log.executions.map((exec: any, i: number) => (
              <div key={i} className="flex items-center justify-between py-1.5 border-b border-[#141414] last:border-0">
                <div className="flex items-center gap-2">
                  <div className={`w-1 h-3 rounded-full ${exec.type === 'LONG' ? 'bg-green-500' : 'bg-red-500'}`} />
                  <div className="flex flex-col">
                    <span className="text-[8px] font-mono text-white font-bold">{exec.type} @ {exec.entry.toFixed(2)}</span>
                    <span className="text-[6px] font-mono text-[#4A4A4A] uppercase italic truncate max-w-[120px]">{exec.reason}</span>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <span className={`text-[9px] font-mono font-bold ${exec.profit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {exec.profit >= 0 ? '+' : ''}${exec.profit?.toFixed(2)}
                  </span>
                  <span className="text-[6px] font-mono text-[#4A4A4A]">R:R {(Math.abs(exec.tp - exec.entry) / Math.abs(exec.entry - exec.sl)).toFixed(1)}</span>
                </div>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

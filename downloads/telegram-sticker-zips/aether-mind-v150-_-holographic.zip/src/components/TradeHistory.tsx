/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Trade } from '../types';
import { ArrowUpRight, ArrowDownRight, Clock } from 'lucide-react';

interface Props {
  trades: Trade[];
}

export const TradeHistory: React.FC<Props> = ({ trades }) => {
  return (
    <div className="bg-[#0A0A0A] border border-[#1A1B1E] h-full flex flex-col shadow-2xl">
      <div className="p-2 border-b border-[#1A1B1E] bg-[#111] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Clock className="w-3 h-3 text-[#4A4A4A]" />
          <span className="text-[8px] font-mono font-bold text-[#4A4A4A] uppercase tracking-[0.2em]">Transaction Ledger</span>
        </div>
        <span className="text-[7px] font-mono text-[#333]">ID: 0x82...FA</span>
      </div>
      
      <div className="flex-1 overflow-y-auto scrollbar-none">
        <table className="w-full text-left border-collapse">
          <thead className="sticky top-0 bg-[#0A0A0A] z-10">
            <tr className="border-b border-[#1A1B1E]">
              <th className="p-2 text-[8px] font-mono text-[#4A4A4A] uppercase font-black">Mkt_Dir</th>
              <th className="p-2 text-[8px] font-mono text-[#4A4A4A] uppercase font-black text-right">Basis</th>
              <th className="p-2 text-[8px] font-mono text-[#4A4A4A] uppercase font-black text-right">Cost_Base</th>
              <th className="p-2 text-[8px] font-mono text-[#4A4A4A] uppercase font-black text-right">Delta</th>
              <th className="p-2 text-[8px] font-mono text-[#4A4A4A] uppercase font-black text-center">Core_Res</th>
            </tr>
          </thead>
          <tbody>
            {trades.length === 0 ? (
              <tr key="empty-trades">
                <td colSpan={5} className="p-8 text-center text-[9px] font-mono text-[#333] uppercase tracking-widest">
                  Scanning for high-alpha entries...
                </td>
              </tr>
            ) : (
              trades.slice().reverse().map((trade) => (
                <React.Fragment key={trade.id}>
                  <tr className="border-b border-[#1A1B1E] hover:bg-[#111] transition-colors group h-10">
                    <td className="p-2 pl-4">
                      <div className={`flex items-center gap-1 text-[10px] font-black ${trade.type === 'LONG' ? 'text-green-500' : 'text-red-500'}`}>
                        {trade.type === 'LONG' ? '↗ LONG' : '↘ SHORT'}
                      </div>
                    </td>
                    <td className="p-2 text-right">
                      <div className="flex flex-col items-end">
                        <span className="text-[10px] font-mono font-bold text-white tabular-nums">{trade.entry.toFixed(2)}</span>
                        <span className="text-[7px] font-mono text-[#4A4A4A]">SZ: 0.08U</span>
                      </div>
                    </td>
                    <td className="p-2 text-right">
                      <div className="text-[9px] font-mono text-gray-500 tabular-nums">${((trade.fee || 0) + (trade.slippage || 0)).toFixed(3)}</div>
                    </td>
                    <td className="p-2 text-right">
                      <span className={`text-[10px] font-mono font-bold tabular-nums ${trade.profit && trade.profit > 0 ? 'text-green-500' : trade.profit && trade.profit < 0 ? 'text-red-500' : 'text-[#4A4A4A]'}`}>
                        {trade.profit ? (trade.profit > 0 ? `+${trade.profit.toFixed(1)}` : trade.profit.toFixed(1)) : '0.0'}
                      </span>
                    </td>
                    <td className="p-2 text-center pr-4">
                      <span className={`text-[8px] font-mono font-black italic px-2 py-0.5 rounded-sm border ${
                        trade.status === 'OPEN' 
                          ? 'bg-orange-500/10 text-orange-500 border-orange-500/20' 
                          : (trade.result === 'WIN' 
                              ? 'bg-green-600/30 text-green-400 border-green-500/20 px-2' 
                              : 'bg-red-600/30 text-red-400 border-red-500/20 px-2')
                      }`}>
                        {trade.status === 'OPEN' ? 'EX_ACTIVE' : trade.result === 'WIN' ? 'WIN' : 'LOSS'}
                      </span>
                    </td>
                  </tr>
                  {trade.reasoning_chain && trade.reasoning_chain.length > 0 && (
                    <tr key={`${trade.id}-reasoning`} className="bg-[#050505]">
                      <td colSpan={5} className="p-2 px-4 border-b border-[#1A1B1E]">
                        <div className="flex flex-wrap gap-x-4 gap-y-1">
                          {trade.reasoning_chain.map((r, idx) => (
                            <span key={idx} className="text-[7px] font-mono text-[#4A4A4A] italic flex items-center gap-1">
                              <span className="text-[#333]">[{idx+1}]</span> {r}
                            </span>
                          ))}
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { BotState, Candle } from '../types';
import { Shield, Loader2, CheckCircle, XCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { analyzeTradeWithGemini } from '../services/geminiService';

interface Props {
  state: BotState;
  lastCandle: Candle;
  onDecision: (valid: boolean, confidence: number) => void;
}

export const AIValidationPanel: React.FC<Props> = ({ state, lastCandle, onDecision }) => {
  const [loading, setLoading] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);

  const performAIAnalysis = async () => {
    if (state.aiValidation !== 'PENDING' || loading) return;

    setLoading(true);
    setAiAnalysis(null);
    
    try {
      const result = await analyzeTradeWithGemini({
        marketContext: state.environment,
        strategy: state.activeStrategy || 'UNKNOWN',
        score: state.score,
        delta: (lastCandle.close - lastCandle.open).toFixed(2),
        wickUpper: lastCandle.wickUpper.toFixed(2),
        wickLower: lastCandle.wickLower.toFixed(2),
      });

      setAiAnalysis(result.reason);
      onDecision(result.valid, result.confidence || 0);
    } catch (error: any) {
      console.error("AI Validation Error:", error);
      const errorMsg = error.message || "Unknown error";
      setAiAnalysis(`FAILED: ${errorMsg}`);
      onDecision(false, `Neural Interface Dropout: ${errorMsg}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (state.aiValidation === 'PENDING') {
      performAIAnalysis();
    }
  }, [state.aiValidation]);

  return (
    <div className="bg-[#0A0A0A] rounded border border-[#1A1B1E] overflow-hidden shadow-2xl">
      <div className="bg-[#111] p-3 border-b border-[#1A1B1E] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className={`w-4 h-4 ${loading ? 'text-blue-500 animate-pulse' : 'text-orange-500'}`} />
          <span className="text-[10px] font-mono font-bold tracking-widest text-white uppercase">Neural Validator v3</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[8px] font-mono text-[#4A4A4A]">MODEL: GEMINI_3_FLASH</span>
          {loading && <Loader2 className="w-3 h-3 text-blue-500 animate-spin" />}
        </div>
      </div>
      
      <div className="p-4 space-y-4">
        {state.aiValidation === 'IDLE' ? (
          <div className="text-[9px] font-mono text-[#4A4A4A] italic flex items-center gap-2">
            <div className="w-1 h-1 rounded-full bg-[#333]" />
            Standing by for synaptic trigger...
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-ping" />
              <span className="text-[9px] font-mono text-blue-400 font-bold uppercase tracking-widest">Processing Quantum Data</span>
            </div>
            
            {aiAnalysis && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-[#111] p-3 rounded border border-[#1A1B1E]"
              >
                <div className="text-[10px] font-mono text-[#8E9299] mb-4 leading-relaxed border-l border-blue-500/30 pl-2">
                  {aiAnalysis}
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {state.aiValidation === 'VALID' ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : (
                      <XCircle className="w-4 h-4 text-red-500" />
                    )}
                    <span className={`text-[10px] font-mono font-bold ${state.aiValidation === 'VALID' ? 'text-green-500' : 'text-red-500'}`}>
                      {state.aiValidation === 'VALID' ? 'SYNAPSE_CONFIRMED' : 'SYNAPSE_REJECTED'}
                    </span>
                  </div>
                  <div className="text-[8px] font-mono text-[#4A4A4A]">CONFIDENCE: 98.4%</div>
                </div>
              </motion.div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BotState } from '../types';
import { Target, TrendingUp, TrendingDown, Layers, Zap, ShieldCheck, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface Props {
  state: BotState;
}

export const GoldSMCPanel: React.FC<Props> = ({ state }) => {
  const gold = state.goldNeuralState;
  if (!gold) return null;

  return (
    <div className="bg-[#0A0A0A] rounded border border-[#1A1B1E] flex flex-col overflow-hidden shadow-2xl">
      <div className="p-3 border-b border-[#1A1B1E] bg-[#111] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-yellow-500" />
          <span className="text-[10px] font-mono font-black uppercase tracking-[0.2em] text-white">SMC Institutional Alignment (GOLD)</span>
        </div>
        <div className={`px-2 py-0.5 rounded text-[8px] font-mono font-bold ${gold.alignment ? 'bg-green-500/10 text-green-500 border border-green-500/20' : 'bg-red-500/10 text-red-500 border border-red-500/20'}`}>
          {gold.alignment ? 'ALIGNMENT_CONFIRMED' : 'RETAIL_NOISE_DETECTED'}
        </div>
      </div>

      <div className="p-4 grid grid-cols-2 gap-3">
        {/* H1 Trend Node */}
        <div className="p-3 bg-[#050505] border border-[#1A1B1E] rounded flex flex-col gap-2 relative overflow-hidden group">
          <div className="flex items-center justify-between z-10">
            <span className="text-[8px] font-mono text-[#4A4A4A] uppercase tracking-widest font-bold">Trend_Node (H1)</span>
            {gold.h1Trend === 'BULLISH' ? <TrendingUp className="w-3 h-3 text-green-500" /> : <TrendingDown className="w-3 h-3 text-red-500" />}
          </div>
          <div className={`text-sm font-mono font-bold ${gold.h1Trend === 'BULLISH' ? 'text-green-500' : 'text-red-500'} z-10`}>
            {gold.h1Trend}
          </div>
          <div className="absolute -bottom-2 -right-2 opacity-10 group-hover:opacity-20 transition-opacity">
            <Target className="w-12 h-12 text-white" />
          </div>
        </div>

        {/* Institutional Nodes */}
        <div className="flex flex-col gap-2">
           <div className={`p-2 rounded border flex items-center justify-between ${gold.obDetected ? 'bg-green-500/5 border-green-500/20 text-green-500' : 'bg-[#050505] border-[#1A1B1E] text-[#4A4A4A]'}`}>
             <span className="text-[8px] font-mono font-bold uppercase">Order_Block</span>
             {gold.obDetected ? <ShieldCheck className="w-3 h-3" /> : <div className="w-2 h-2 rounded-full bg-[#1A1B1E]" />}
           </div>
           <div className={`p-2 rounded border flex items-center justify-between ${gold.fvgDetected ? 'bg-blue-500/5 border-blue-500/20 text-blue-400' : 'bg-[#050505] border-[#1A1B1E] text-[#4A4A4A]'}`}>
             <span className="text-[8px] font-mono font-bold uppercase">Fair_Value_Gap</span>
             {gold.fvgDetected ? <Zap className="w-3 h-3" /> : <div className="w-2 h-2 rounded-full bg-[#1A1B1E]" />}
           </div>
        </div>

        {/* CHoCH confirmation (M15) */}
        <div className="col-span-2 p-3 bg-[#050505] border border-[#1A1B1E] rounded flex items-center justify-between">
           <div className="flex flex-col">
              <span className="text-[8px] font-mono text-[#4A4A4A] uppercase font-bold">M15_Change_Of_Character</span>
              <span className={`text-[10px] font-mono ${gold.m15Choch ? 'text-cyan-400 font-bold' : 'text-[#333]'}`}>
                {gold.m15Choch ? 'CHoCH_TRIGGER_ACTIVE >> INITIATING ENTRY' : 'Waiting for structure break...'}
              </span>
           </div>
           {gold.m15Choch && (
             <motion.div 
               animate={{ scale: [1, 1.2, 1] }} 
               transition={{ repeat: Infinity, duration: 1 }}
               className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.5)]" 
             />
           )}
        </div>
      </div>

      {!gold.alignment && (
        <div className="px-4 py-2 bg-red-500/5 border-t border-red-500/10 flex items-center gap-2">
          <AlertCircle className="w-3 h-3 text-red-500" />
          <span className="text-[8px] font-mono text-red-500 uppercase tracking-widest italic">
            Avoid fake zones: Stay out until Alignment confirmed 💀
          </span>
        </div>
      )}
    </div>
  );
};

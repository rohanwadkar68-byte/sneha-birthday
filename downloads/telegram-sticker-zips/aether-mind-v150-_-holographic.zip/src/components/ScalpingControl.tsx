import React from 'react';
import { BotState } from '../types';
import { Zap, Activity, Power } from 'lucide-react';
import { motion } from 'motion/react';

interface Props {
  state: BotState;
  onToggle: (enabled: boolean) => void;
  onTrigger: () => void;
}

export const ScalpingControl: React.FC<Props> = ({ state, onToggle, onTrigger }) => {
  return (
    <div className="bg-[#151619] rounded-xl border border-[#141414] overflow-hidden shadow-2xl">
      <div className="bg-[#1A1A1A] p-3 border-b border-[#141414] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Zap className={`w-4 h-4 ${state.isScalpingEnabled ? 'text-yellow-500 animate-pulse' : 'text-[#4A4A4A]'}`} />
          <span className="text-[10px] font-mono font-bold text-white tracking-widest uppercase">Scalping Interface</span>
        </div>
        <button 
          onClick={() => onToggle(!state.isScalpingEnabled)}
          className={`px-3 py-1 rounded-md text-[9px] font-mono transition-all duration-300 flex items-center gap-2 border ${
            state.isScalpingEnabled 
              ? 'bg-yellow-500/10 border-yellow-500/50 text-yellow-500 shadow-[0_0_10px_rgba(234,179,8,0.2)]' 
              : 'bg-[#0A0A0A] border-[#333] text-[#4A4A4A] hover:border-[#555]'
          }`}
        >
          <Power className="w-3 h-3" />
          {state.isScalpingEnabled ? 'ENGAGED' : 'DISENGAGED'}
        </button>
      </div>
      
      <div className="p-4 space-y-4">
        <div className="grid grid-cols-2 gap-2">
          <div className="p-2 bg-[#0A0A0A] rounded border border-[#141414]">
            <div className="text-[8px] uppercase text-[#4A4A4A] font-mono mb-1">Risk Mode</div>
            <div className="text-[10px] text-yellow-500 font-mono">ULTRA_AGGRESSIVE</div>
          </div>
          <div className="p-2 bg-[#0A0A0A] rounded border border-[#141414]">
            <div className="text-[8px] uppercase text-[#4A4A4A] font-mono mb-1">Neural Latency</div>
            <div className="text-[10px] text-green-500 font-mono">0.02ms</div>
          </div>
        </div>

        <button
          disabled={!state.isScalpingEnabled}
          onClick={onTrigger}
          className={`w-full py-4 rounded-lg font-mono text-xs uppercase tracking-[0.2em] transition-all duration-300 relative overflow-hidden group ${
            state.isScalpingEnabled
              ? 'bg-white text-black hover:bg-yellow-500 active:scale-95 cursor-pointer'
              : 'bg-[#1A1A1A] text-[#333] cursor-not-allowed opacity-50'
          }`}
        >
          <div className="relative z-10 flex items-center justify-center gap-2">
            <Activity className={`w-4 h-4 ${state.isScalpingEnabled ? 'animate-bounce' : ''}`} />
            Execute HFT Scalp
          </div>
          {state.isScalpingEnabled && (
            <motion.div 
              initial={{ x: '-100%' }}
              animate={{ x: '200%' }}
              transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/50 to-transparent skew-x-[-20deg]"
            />
          )}
        </button>
        
        <div className="text-[8px] font-mono text-[#4A4A4A] italic text-center leading-tight">
          Warning: Manual scalp bypasses AI safety filters. <br/>
          Use only for high-liquidity session bursts.
        </div>
      </div>
    </div>
  );
};

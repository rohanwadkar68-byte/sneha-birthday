/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { NeuralMemory } from '../types';
import { Brain, Database, Zap, ShieldAlert, History } from 'lucide-react';
import { motion } from 'motion/react';

interface Props {
  memory: NeuralMemory;
}

export const NeuralMemoryPanel: React.FC<Props> = ({ memory }) => {
  return (
    <div className="bg-[#151619] rounded-xl border border-[#141414] overflow-hidden flex flex-col">
      <div className="bg-[#1A1A1A] p-3 border-b border-[#141414] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Database className="w-4 h-4 text-orange-500" />
          <span className="text-xs font-mono text-white">NEURAL_SYNAPSE_STORAGE 🧠</span>
        </div>
        <span className="text-[8px] font-mono text-[#4A4A4A] uppercase tracking-tighter">Capacity: Unlimited</span>
      </div>
      
      <div className="p-4 space-y-4">
        <div className="grid grid-cols-2 gap-2">
          <div className="bg-[#0A0A0A] p-2 rounded border border-[#141414]">
            <div className="text-[8px] text-[#4A4A4A] uppercase font-mono mb-1">Human Lessons</div>
            <div className="text-sm font-bold font-mono text-orange-500 flex items-center gap-1">
              <Zap className="w-3 h-3" /> {memory.totalLessons}
            </div>
          </div>
          <div className="bg-[#0A0A0A] p-2 rounded border border-[#141414]">
            <div className="text-[8px] text-[#4A4A4A] uppercase font-mono mb-1">Last Sync</div>
            <div className="text-[10px] font-mono text-white truncate">
              {new Date(memory.lastSync).toLocaleTimeString()}
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <h4 className="text-[9px] font-mono text-[#8E9299] uppercase tracking-widest flex items-center gap-1">
              <History className="w-3 h-3" /> Strategy Weights
            </h4>
            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1 custom-scrollbar">
              {Object.entries(memory.strategyWeights).length === 0 ? (
                <div className="p-3 text-center bg-[#0A0A0A]/50 rounded border border-dashed border-[#141414]">
                  <p className="text-[10px] font-mono text-[#4A4A4A]">Awaiting weights...</p>
                </div>
              ) : (
                Object.entries(memory.strategyWeights).map(([strategy, weight]) => (
                  <motion.div 
                    key={strategy}
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    className="p-2 bg-[#0A0A0A]/80 rounded border border-[#141414] space-y-1"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[8px] font-mono font-bold text-cyan-400 bg-cyan-400/10 px-1 rounded uppercase">
                        {strategy}
                      </span>
                      <span className="text-[10px] font-mono text-white font-bold">{(weight as number).toFixed(2)}x</span>
                    </div>
                    <div className="w-full h-[2px] bg-white/5 rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-700 ${(weight as number) >= 1.0 ? 'bg-cyan-500' : 'bg-red-500'}`}
                        style={{ width: `${Math.min(100, (weight as number) * 50)}%` }} 
                      />
                    </div>
                  </motion.div>
                ))
              )}
            </div>
          </div>
 
          <div className="space-y-2 pt-2 border-t border-white/5">
            <h4 className="text-[9px] font-mono text-[#8E9299] uppercase tracking-widest">Environment Alignment</h4>
            <div className="grid grid-cols-1 gap-2">
              {Object.entries(memory.environmentPerformance).map(([env, perf]) => (
                <div key={env} className="flex flex-col gap-1">
                  <div className="flex justify-between items-center text-[8px] font-mono uppercase text-[#4A4A4A]">
                    <span>{env}</span>
                    <span className="text-white">{((perf as number) * 100).toFixed(0)}%</span>
                  </div>
                  <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.3)]" style={{ width: `${(perf as number) * 100}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

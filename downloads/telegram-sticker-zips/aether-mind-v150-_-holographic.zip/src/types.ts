/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type MarketEnvironment = 'TRENDING' | 'RANGING' | 'VOLATILE' | 'INSTITUTIONAL' | 'DISPLACEMENT';

export type AssetType = 'CRYPTO' | 'GOLD' | 'FOREX';

export type StrategyType = 
  | 'STRATEGY_1_SMC_OTE'
  | 'STRATEGY_2_LIQUIDITY_REVERSAL'
  | 'STRATEGY_3_BREAKOUT_RETEST'
  | 'STRATEGY_5_EMA_RSI'
  | 'STRATEGY_6_TRENDLINE_SCALP'
  | 'STRATEGY_7_SR_ENGULFING'
  | 'SMC_SUPERHUMAN'
  | 'BREAKOUT' 
  | 'PULLBACK' 
  | 'TREND_FOLLOW' 
  | 'SR_BOUNCE' 
  | 'SWEEP' 
  | 'REVERSAL' 
  | 'LIQUIDITY_TRAP' 
  | 'FAKE_BREAKOUT'
  | 'SCALPING'
  | 'SMC_GOLD'
  | 'MSS_CHOC'
  | 'SYSTEM_X'
  | 'SCALP_MOM_V2'
  | 'SILVER_BULLET_V5'
  | 'AMD_SMC_V5'
  | 'MSS_ELITE_V5'
  | 'SILVER_BULLET_V14'
  | 'SMC_OB_V14'
  | 'MSS_ELITE_V14'
  | 'PO3_AMD_V2'
  | 'MSS_ELITE_V6'
  | 'SILVER_BULLET_V15'
  | 'SMC_OB_V15'
  | 'MSS_STEALTH_V15'
  | string;

export interface GoldNeuralState {
  h1Trend: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  m15Choch: boolean;
  obDetected: boolean;
  fvgDetected: boolean;
  alignment: boolean;
}

export interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  wickUpper: number;
  wickLower: number;
  bodySize: number;
}

export interface Trade {
  id: string;
  time: number;
  type: 'LONG' | 'SHORT';
  entry: number;
  sl: number;
  initialSL?: number;
  tp: number;
  tp2?: number;
  tp3?: number;
  status: 'OPEN' | 'CLOSED' | 'PENDING' | 'CANCELLED' | 'COMPLETED';
  result?: 'WIN' | 'LOSS';
  profit?: number;
  fee?: number;
  units?: number;
  slippage?: number;
  strategy: StrategyType;
  environment: MarketEnvironment | string;
  reason: string;
  reasoning_chain?: string[];
  alpha_confidence?: number;
  conviction?: 'NORMAL' | 'HIGH' | 'SOVEREIGN';
  partialTaken?: boolean;
  partialTaken2?: boolean;
  beMoved?: boolean;
}

export type MarketRegime = 'INSTITUTIONAL_TREND' | 'LIQUIDITY_EXPANSION' | 'MEAN_REVERSION' | 'VOLATILITY_CRUSH';

export interface TradingMetrics {
  sharpeRatio: number;
  profitFactor: number;
  maxDrawdown: number;
  avgWin: number;
  avgLoss: number;
  winRate: number;
}

export interface DailyPnL {
  date: string;
  pnl: number;
  trades: number;
  executions?: Trade[];
}

export interface BacktestResult {
  totalTrades: number;
  winRate: number;
  totalPnL: number;
  maxDrawdown: number;
  trades: Trade[];
  allTrades?: Trade[];
  dailyLogs?: DailyPnL[];
  profitFactor?: number;
}

export interface StrategyPerformance {
  winRate: number;
  totalTrades: number;
  profit: number;
}

export interface LogEntry {
  id: string;
  message: string;
  time: string;
}

export interface MarketInsight {
  pattern: string;
  successRate: number;
  environment: MarketEnvironment;
  lastObserved: number;
  lesson: string;
}

export interface NeuralMemory {
  totalLessons: number;
  accuracy: number;
  strategyWeights: Record<string, number>;
  environmentPerformance: {
    Trending: number;
    Ranging: number;
    Volatile: number;
  };
  lastSync: string;
}

export interface BotState {
  environment: MarketEnvironment;
  activeStrategy: StrategyType | null;
  mode: 'INSTITUTIONAL' | 'SCALPING';
  currentAsset: AssetType;
  setupFound: boolean;
  score: number;
  bias: 'LONG' | 'SHORT' | 'NEUTRAL';
  htfBias: 'BULLISH' | 'BEARISH' | 'RANGING' | 'NEUTRAL';
  liquidityMap: {
    buyside: number;
    sellside: number;
    unmitigatedOB: number | null;
  };
  v15Metrics?: {
    rvi: number;
    volStrength: number;
    isNearPOV: boolean;
  };
  marketPhase?: 'ACCUMULATION' | 'TRENDING' | 'DISTRIBUTION' | 'VOLATILE';
  aiValidation: 'IDLE' | 'PENDING' | 'VALID' | 'REJECTED' | 'ZEN_PAUSE' | 'MACRO_PAUSE';
  tradingPlan: string;
  currentRegime?: MarketRegime;
  nexusNodes?: {
    smc: number;
    momentum: number;
    context: number;
  };
  strategyPerformance: Record<string, { wins: number, losses: number, totalProfit: number }>;
  logs: LogEntry[];
  trades: Trade[];
  balance: number;
  isBacktesting: boolean;
  isScalpingEnabled: boolean;
  scalpingActive?: boolean;
  totalFees: number;
  totalSlippage: number;
  lastBacktest: BacktestResult | null;
  dailyLoss: number;
  dailyLossLimit: number;
  dailyProfit: number;
  dailyProfitTarget: number;
  monthlyPnl: number;
  monthlyWinRate: number;
  learningData: {
    [key in StrategyType]?: StrategyPerformance;
  };
  insights: MarketInsight[];
  neuralMemory: NeuralMemory;
  goldNeuralState?: GoldNeuralState;
  backtestProgress?: number;
  metrics: TradingMetrics;
}

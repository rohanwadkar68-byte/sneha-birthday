import React, { useState, useEffect, useCallback } from 'react';
import { market } from './lib/marketEngine';
import { brain } from './lib/botBrain';
import { BotState, Candle } from './types';
import { TradingChart } from './components/TradingChart';
import { BotBrainFlow } from './components/BotBrainFlow';
import { AIValidationPanel } from './components/AIValidationPanel';
import { TradeHistory } from './components/TradeHistory';
import { AetherMarketReport } from './components/AetherMarketReport';
import { BacktestPanel } from './components/BacktestPanel';
import { ScalpingControl } from './components/ScalpingControl';
import { NeuralMemoryPanel } from './components/NeuralMemoryPanel';
import { GoldSMCPanel } from './components/GoldSMCPanel';
import { InstitutionalPanel } from './components/InstitutionalPanel';
import { PerformanceStats } from './components/PerformanceStats';
import { NeuralInsights } from './components/NeuralInsights';
import { Terminal, Shield, Activity, Cpu, Database, ChevronRight, Lock, Satellite, Coins, Landmark } from 'lucide-react';

export default function App() {
  const [candles, setCandles] = useState<Candle[]>(market.getCandles());
  const [botState, setBotState] = useState<BotState>(brain.getState());
  const [lastTick, setLastTick] = useState(Date.now());

  const tick = useCallback(async () => {
    if (brain.getState().isBacktesting) return;
    await brain.update();
    setCandles([...market.getCandles()]);
    setBotState({ ...brain.getState() });
    setLastTick(Date.now());
  }, []);

  useEffect(() => {
    const interval = setInterval(tick, 1000); // 1s tick for faster action
    return () => clearInterval(interval);
  }, [tick]);

  const handleAIDecision = (valid: boolean, confidence: number) => {
    brain.executeTrade(valid, confidence);
    setBotState({ ...brain.getState() });
  };

  const handleRunBacktest = async (days: number, customAsset?: any, customMode?: any) => {
    await brain.startBacktest(days, customAsset, customMode);
    setBotState({ ...brain.getState() });
  };

  const handleToggleScalping = (enabled: boolean) => {
    brain.setScalpingMode(enabled);
    setBotState({ ...brain.getState() });
  };

  const handleTriggerScalp = () => {
    brain.triggerScalp();
    setBotState({ ...brain.getState() });
  };

  const handleSetAsset = (asset: 'CRYPTO' | 'GOLD') => {
    brain.setAsset(asset);
    setBotState({ ...brain.getState() });
  };

  const totalPnL = botState.trades.reduce((acc, t) => acc + (t.profit || 0), 0);
  const balance = botState.balance;

  return (
    <div className="min-h-screen bg-[#050505] text-[#E4E3E3] p-4 font-sans selection:bg-orange-500/30">
      {/* Structural Grid Layout - CELEBRATING THE GRID */}
      <header className="fixed top-0 left-0 right-0 h-14 bg-[#050505]/80 backdrop-blur-xl border-b border-[#1A1B1E] z-50 px-6 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded flex items-center justify-center shadow-[0_0_20px_rgba(255,255,255,0.1)]">
              <Activity className="w-6 h-6 text-black" />
            </div>
            <div>
              <h1 className="text-sm font-black uppercase tracking-[0.2em] text-white">
                Alpha_Core <span className="text-[#4A4A4A] font-mono text-[10px] ml-1 not-italic font-medium">V1.2.0-ELITE</span>
              </h1>
              <div className="flex items-center gap-2 -mt-1">
                <div className="w-1 h-1 rounded-full bg-green-500 animate-pulse" />
                <span className="text-[8px] font-mono text-green-500 uppercase tracking-widest">Neural {botState.currentAsset} Bridge Synchronized</span>
              </div>
            </div>
          </div>
          
          <div className="h-8 w-px bg-[#1A1B1E]" />
          
          <nav className="flex items-center gap-4">
            <button 
              onClick={() => handleSetAsset('CRYPTO')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded transition-all ${botState.currentAsset === 'CRYPTO' ? 'bg-orange-500 text-white font-bold' : 'text-[#4A4A4A] hover:text-white'}`}
            >
              <Coins className="w-4 h-4" />
              <span className="text-[10px] font-mono uppercase tracking-widest">Crypto_Cortex</span>
            </button>
            <button 
              onClick={() => handleSetAsset('GOLD')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded transition-all ${botState.currentAsset === 'GOLD' ? 'bg-yellow-600 text-white font-bold shadow-[0_0_15px_rgba(202,138,4,0.3)]' : 'text-[#4A4A4A] hover:text-white'}`}
            >
              <Landmark className="w-4 h-4" />
              <span className="text-[10px] font-mono uppercase tracking-widest">Gold_SMC_Terminal</span>
            </button>
          </nav>
        </div>
        
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-4 px-4 py-1.5 bg-[#0A0A0A] border border-[#1A1B1E] rounded">
            <div className="flex flex-col items-end">
              <div className="flex items-center gap-2">
                <span className="text-[8px] uppercase font-mono text-[#4A4A4A] font-bold tracking-widest leading-none">Portfolio_V</span>
                <button 
                  onClick={() => {
                    brain.toggleMode(); 
                    setBotState({ ...brain.getState() });
                  }}
                  className={`px-2 py-0.5 rounded-[2px] text-[7px] font-black uppercase tracking-tighter transition-all border ${
                    botState.mode === 'SCALPING' 
                    ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/50 shadow-[0_0_8px_rgba(6,182,212,0.2)]' 
                    : 'bg-indigo-500/20 text-indigo-400 border-indigo-500/50'
                  }`}
                >
                  ENGINE: {botState.mode}
                </button>
              </div>
              <span className="text-[13px] font-mono text-white tabular-nums leading-none mt-1">{balance.toLocaleString(undefined, { minimumFractionDigits: 2 })} <span className="text-[9px] text-[#4A4A4A]">USDT</span></span>
            </div>
            <div className="w-px h-6 bg-[#1A1B1E]" />
            <div className="flex flex-col items-end">
              <span className="text-[8px] uppercase font-mono text-[#4A4A4A] font-bold tracking-widest leading-none">Session_Δ</span>
              <span className={`text-[13px] font-mono tabular-nums leading-none mt-1 ${totalPnL >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                {totalPnL >= 0 ? '+' : ''}{totalPnL.toFixed(2)}
              </span>
            </div>
          </div>
          <div className="flex flex-col items-center">
            <button 
              onClick={() => handleRunBacktest(100)}
              className="w-10 h-10 rounded-full border border-[#1A1B1E] bg-[#0A0A0A] flex flex-col items-center justify-center hover:border-orange-500/50 group transition-all"
              title="Quick Backtest (100 Candles)"
            >
              <Database className="w-3 h-3 text-[#4A4A4A] group-hover:text-orange-500" />
              <span className="text-[6px] text-[#222] font-black uppercase mt-0.5">Test</span>
            </button>
          </div>
        </div>
      </header>

      <main className="mt-16 grid grid-cols-12 gap-5 h-[calc(100vh-6rem)]">
        {/* Left Control Column - NEURAL CORE */}
        <div className="col-span-12 lg:col-span-3 flex flex-col gap-5 overflow-y-auto pr-2 custom-scrollbar">
          <div className="bg-[#0A0A0A] rounded border border-[#1A1B1E] p-1 flex flex-col h-fit">
             <div className="p-3 border-b border-[#1A1B1E] flex items-center justify-between bg-[#111]">
               <span className="text-[9px] font-mono font-black uppercase tracking-[0.2em] text-white">Neural Synapse</span>
               <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
             </div>
             <div className="p-1">
               <BotBrainFlow state={botState} />
             </div>
          </div>
          
          <ScalpingControl 
            state={botState} 
            onToggle={handleToggleScalping}
            onTrigger={handleTriggerScalp}
          />

          <InstitutionalPanel state={botState} />

          <BacktestPanel state={botState} onRun={handleRunBacktest} />

          {botState.currentAsset === 'GOLD' && (
            <GoldSMCPanel state={botState} />
          )}

          <AIValidationPanel 
            state={botState} 
            lastCandle={candles[candles.length - 1]} 
            onDecision={handleAIDecision} 
          />

          <div className="bg-[#0A0A0A] border border-[#1A1B1E] p-4 rounded shadow-2xl">
            <h3 className="text-[9px] font-mono font-black uppercase tracking-[0.2em] text-[#4A4A4A] mb-4 flex items-center gap-2">
              <Database className="w-3 h-3" />
              Strategy_Learning_Center
            </h3>
            <div className="space-y-3">
              {(Object.entries(botState.learningData) as [string, any][]).length === 0 ? (
                <div className="text-[10px] font-mono text-[#333] italic">No neural data clusters formed.</div>
              ) : (
                (Object.entries(botState.learningData) as [string, any][]).map(([strategy, data]) => (
                  <div key={strategy} className="space-y-1">
                    <div className="flex justify-between text-[10px] font-mono">
                      <span className="text-[#8E9299]">{strategy}</span>
                      <span className={data.winRate >= 70 ? 'text-green-500' : 'text-orange-500'}>{data.winRate.toFixed(1)}%</span>
                    </div>
                    <div className="h-1 bg-[#1A1B1E] rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-1000 ${data.winRate >= 70 ? 'bg-green-500' : 'bg-orange-500'}`} 
                        style={{ width: `${data.winRate}%` }} 
                      />
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Center Column - PRECISION CHARTS */}
        <div className="col-span-12 lg:col-span-6 flex flex-col gap-5">
          <div className="flex-1 bg-[#0A0A0A] rounded border border-[#1A1B1E] relative overflow-hidden flex flex-col">
            <div className="p-3 border-b border-[#1A1B1E] flex items-center justify-between bg-[#111] z-10">
              <div className="flex items-center gap-4">
                <span className="text-[9px] font-mono font-black uppercase tracking-[0.2em] text-white italic">BTC_USDT_PERP</span>
                <span className="text-[10px] font-mono text-green-500">$64,281.42 (+2.1%)</span>
              </div>
              <div className="flex gap-2">
                 {['1M', '5M', '15M', '1H', '4H'].map(tf => (
                   <button key={tf} className={`px-2 py-0.5 rounded text-[9px] font-mono border ${tf === '1M' ? 'bg-white text-black border-white' : 'bg-[#1A1A1A] text-[#4A4A4A] border-[#333]'}`}>{tf}</button>
                 ))}
              </div>
            </div>
            <div className="flex-1">
              <TradingChart 
              data={candles} 
              state={botState}
            />
            </div>
          </div>
          
          <div className="h-44 bg-[#0A0A0A] rounded border border-[#1A1B1E] p-0 flex flex-col overflow-hidden shadow-2xl">
            <div className="p-2 border-b border-[#1A1B1E] bg-[#111] flex items-center justify-between px-4">
              <div className="flex items-center gap-2">
                <Terminal className="w-3 h-3 text-[#4A4A4A]" />
                <span className="text-[8px] font-mono font-bold uppercase tracking-widest text-[#4A4A4A]">Real-Time Market Telemetry & Alpha Metrics</span>
              </div>
              <div className="text-[7px] font-mono text-cyan-500 animate-pulse uppercase tracking-[0.3em]">HFT_STREAMS_ACTIVE</div>
            </div>
            <div className="p-6 flex-1">
              <PerformanceStats metrics={botState.metrics} balance={botState.balance} />
            </div>
          </div>
        </div>

        {/* Right Column - LEDGER & MEMORY */}
        <div className="col-span-12 lg:col-span-3 flex flex-col gap-5 overflow-y-auto pr-2 custom-scrollbar">
           <div className="flex-1 min-h-0">
            <TradeHistory 
              trades={
                botState.isBacktesting 
                  ? [] 
                  : (botState.lastBacktest ? (botState.lastBacktest.allTrades || botState.lastBacktest.trades) : botState.trades)
              } 
            />
           </div>
           
           <div className="flex-1 min-h-0">
             <AetherMarketReport state={botState} />
           </div>
           
           <div className="flex-1 min-h-0">
             <NeuralInsights state={botState} insights={botState.insights} />
           </div>
           
           <NeuralMemoryPanel memory={botState.neuralMemory} />
        </div>
      </main>

      {/* FOOTER - SYSTEM STATUS BAR */}
      <footer className="fixed bottom-0 left-0 right-0 h-8 bg-[#0A0A0A] border-t border-[#1A1B1E] flex items-center justify-between px-6 text-[#4A4A4A] text-[9px] font-mono z-50">
        <div className="flex items-center gap-6">
          <span className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.4)]" /> CORE_STABLE</span>
          <span className="flex items-center gap-2 tracking-widest"><Cpu className="w-3 h-3" /> GEMINI_SYNAPSE: ENABLED</span>
          <span className="tracking-tighter">TICKS: {lastTick}</span>
        </div>
        <div className="flex items-center gap-6 font-bold">
          <span className="hover:text-white transition-colors cursor-help">RECORDS_LOCKED</span>
          <span className="text-white/20 italic">ALPHA_CORE_V1.0.4 👽💀</span>
        </div>
      </footer>
    </div>
  );
}


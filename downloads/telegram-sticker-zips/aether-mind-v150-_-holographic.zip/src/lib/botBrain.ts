/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BotState, Candle, MarketEnvironment, StrategyType, Trade, AssetType, MarketInsight } from '../types';
import { market } from './marketEngine';
import { detectLiquiditySweep, detectOrderBlock, detectFVG, calculateEMA, getHTFBias, getDealingRangeInfo, detectChoCh, isInKillzone, detectDisplacement, isInSilverBullet, detectWickRejection, detectVolumeCluster, calculateRVI, detectMarketPhase, detectCandlestickPattern, detectDivergence, calculateRSI, calculateMomentum, calculateATR, calculateStochRSI, getSessionStats, calculateSqueeze, findEliteZones, detectBreakerBlock, detectMacroImpact, detectSMTDivergence, getSessionLevels, calculateAdaptiveSL, calculateSuperhumanScore, detectInducement, getNeuralWeighting, calculateMPI } from './strategies';
import { sendTelegramAlert } from '../services/telegramService';
import { fetchRealHistoricalData, fetchHTFData } from '../services/marketDataService';

export class BotBrain {
  private state: BotState = {
    environment: 'RANGING',
    activeStrategy: null,
    mode: 'INSTITUTIONAL',
    currentAsset: 'CRYPTO',
    setupFound: false,
    score: 0,
    bias: 'NEUTRAL',
    htfBias: 'RANGING',
    liquidityMap: {
      buyside: 0,
      sellside: 0,
      unmitigatedOB: null
    },
    aiValidation: 'IDLE',
    tradingPlan: 'Scanning Liquidity Pools...',
    currentRegime: 'MEAN_REVERSION',
    strategyPerformance: {
      'SMC_SUPERHUMAN': { wins: 0, losses: 0, totalProfit: 0 },
      'INSTITUTIONAL': { wins: 0, losses: 0, totalProfit: 0 },
      'SCALPING': { wins: 0, losses: 0, totalProfit: 0 }
    },
    logs: [],
    trades: [],
    isBacktesting: false,
    balance: 50,
    totalFees: 0,
    totalSlippage: 0,
    dailyLoss: 0,
    dailyLossLimit: 1.0, 
    dailyProfit: 0,
    dailyProfitTarget: 2.5, // 5% profit target per day
    monthlyPnl: 0,
    monthlyWinRate: 0,
    isScalpingEnabled: false,
    lastBacktest: null,
    learningData: {},
    insights: [],
    neuralMemory: {
      totalLessons: 0,
      accuracy: 0,
      strategyWeights: {
        'SMC_SWEEP': 1.0,
        'SMC_OB': 1.0,
        'SMC_FVG': 1.0,
        'SCALP_VOL': 1.0,
        'SCALP_MOM': 1.0,
        'SWEEP': 1.0,
        'LIQUIDITY_TRAP': 1.0,
        'PULLBACK': 1.0,
        'SCALPING': 1.0,
        'MOMENTUM_SCALP': 1.0,
        'SMC_INSTITUTIONAL': 1.0
      },
      environmentPerformance: {
        Trending: 0.5,
        Ranging: 0.5,
        Volatile: 0.5
      },
      lastSync: new Date().toISOString()
    },
    goldNeuralState: {
      h1Trend: 'NEUTRAL',
      m15Choch: false,
      obDetected: false,
      fvgDetected: false,
      alignment: false
    },
    metrics: {
      sharpeRatio: 0,
      profitFactor: 0,
      maxDrawdown: 0,
      avgWin: 0,
      avgLoss: 0,
      winRate: 0
    }
  };

  constructor() {
    this.loadFromMemory();
  }

  private saveToMemory() {
    try {
      localStorage.setItem('ALPHA_CORE_LEARNING', JSON.stringify({
        data: this.state.learningData,
        memory: this.state.neuralMemory,
        time: Date.now()
      }));
    } catch (e) {
      console.error("Neural Save Error:", e);
    }
  }

  private loadFromMemory() {
    try {
      const saved = localStorage.getItem('ALPHA_CORE_LEARNING');
      if (saved) {
        const parsed = JSON.parse(saved);
        this.state.learningData = parsed.data || {};
        
        // Deep merge for neuralMemory to avoid missing keys
        const savedMemory = parsed.memory || {};
        this.state.neuralMemory = {
          ...this.state.neuralMemory,
          ...savedMemory,
          strategyWeights: {
            ...this.state.neuralMemory.strategyWeights,
            ...(savedMemory.strategyWeights || {})
          },
          environmentPerformance: {
            ...this.state.neuralMemory.environmentPerformance,
            ...(savedMemory.environmentPerformance || {})
          }
        };

        this.log(`🧠 NEURAL EXPERIENCE LOADED: Re-establishing consciousness from ${new Date(parsed.time).toLocaleTimeString()}... 👽`);
        this.log(`MEMORY: Recovered experience for ${Object.keys(this.state.learningData).length} strategy vectors and ${this.state.neuralMemory.totalLessons} deep lessons.`);
      }
    } catch (e) {
      this.log(`⚠️ MEMORY_RESET: Starting fresh institutional training node.`);
    }
  }

  public async startBacktest(days: number, customAsset?: AssetType, customMode?: 'INSTITUTIONAL' | 'SCALPING') {
    this.state.isBacktesting = true;
    this.state.lastBacktest = null; 
    const targetAsset = customAsset || this.state.currentAsset;
    const symbol = targetAsset === 'GOLD' ? 'PAXGUSDT' : (targetAsset === 'FOREX' ? 'EURUSDT' : 'BTCUSDT');
    
    this.log(`🚀 [BACKTEST_ENGINE]: INITIATING SIMULATION ON ${targetAsset} FOR ${days} DAYS... 📡`);
    
    const realCandles = await fetchRealHistoricalData(symbol, '1h', days * 24);
    
    if (realCandles.length === 0) {
      this.log(`⚠️ [DATA_WARNING]: Exchange sync failed. Using synthetic institutional fractal data for simulation.`);
    } else {
      this.log(`✅ [DATA_SYNC]: Successfully synchronized ${realCandles.length} real market candles for ${targetAsset}.`);
    }

    const { BacktestEngine } = await import('./backtestEngine');
    const currentPrice = market.getCandles().slice(-1)[0]?.close || 0;
    const result = BacktestEngine.simulate(days, currentPrice, realCandles, targetAsset, customMode || this.state.mode, this.state.balance);
    
    this.state.lastBacktest = result;
    this.state.isBacktesting = false;
    
    this.log(`📊 [RECORDS_CONSOLIDATED]: Backtest complete over ${days} days. PnL: $${result.totalPnL.toFixed(2)} | Success: ${result.winRate.toFixed(1)}% | PF: ${result.profitFactor.toFixed(2)}`);
    
    result.trades.forEach(t => this.generateNeuralLesson(t));
    this.updateLearningMemory(result.trades);
    
    const summary = `🧠 [SIGNAL_AUDIT]\n━━━━━━━━━━━━━━━━━━\n✅ SIMULATION STACKED: PnL ${result.totalPnL >= 0 ? '+' : ''}$${result.totalPnL.toFixed(2)} | Edge: ${(result.winRate).toFixed(1)}% | DD: ${result.maxDrawdown.toFixed(2)}%\n━━━━━━━━━━━━━━━━━━\n📡 CORE_STATUS: INSTITUTIONAL\n🧠 ALPHA: ${((result.profitFactor || 1) * 10).toFixed(1)} SRC\n🕒 ${new Date().toLocaleTimeString()}`;
    sendTelegramAlert(summary);
 
    // Send Detailed Telegram Backtest Report in Split Messages
    const allTrades = result.allTrades || [];
    const wins = allTrades.filter(t => (t.profit || 0) > 0).length;
    const accuracy = allTrades.length > 0 ? (wins / allTrades.length) * 100 : 0;
    
    const activeExecs = allTrades.map(t => {
      const typeStr = t.type === 'LONG' ? '🔼' : '🔽';
      const profStr = (t.profit || 0) > 0 ? '🟢' : (t.profit || 0) === 0 ? '⚪' : '🔴';
      const riskDist = Math.abs(t.entry - (t.initialSL || t.sl)) || 1;
      const rrCalculated = Math.abs(t.tp - t.entry) / riskDist;
      return `${profStr} ${typeStr} <b>${t.entry.toFixed(1)}</b> | ${(t.profit || 0) >= 0 ? '+' : ''}$${(t.profit || 0).toFixed(2)} | RR:<b>${rrCalculated.toFixed(1)}</b>`;
    });
 
    const header = `
🛸 <b>AETHER MIND QUANT LAB REPORT (V161)</b>
━━━━━━━━━━━━━━━━━━
📊 <b>EXECUTIVE SUMMARY</b>
• <b>Net PnL:</b> <code>${result.totalPnL >= 0 ? '+' : ''}$${result.totalPnL.toFixed(2)}</code>
• <b>Accuracy:</b> <code>${accuracy.toFixed(1)}%</code>
• <b>Efficiency:</b> <code>${(result.profitFactor || 0).toFixed(2)} PF</code>
• <b>Drawdown:</b> <code>${result.maxDrawdown.toFixed(2)}%</code>
• <b>Operations:</b> <code>${allTrades.length} Trades</code>
`.trim();

    sendTelegramAlert(header);

    // Send individual trade logs in chunks (35 trades per message for better readability)
    const CHUNK_SIZE = 35;
    for (let i = 0; i < activeExecs.length; i += CHUNK_SIZE) {
        const chunk = activeExecs.slice(i, i + CHUNK_SIZE);
        const msg = `
📝 <b>BATCH EXECUTIONS (${Math.floor(i/CHUNK_SIZE) + 1})</b>
${chunk.join('\n')}
        `.trim();
        sendTelegramAlert(msg);
    }

    // Professional Analysis based on PnL
    let proAnalysis = "";
    if (result.totalPnL < 0) {
      proAnalysis = "⚠️ <b>RISK AUDIT:</b> High fee drag detected. Alpha V40 will prioritize 'Fee-Plus' exits to protect the principal balance.";
    } else if (accuracy < 35) {
      proAnalysis = "📈 <b>EDGE DETECTED:</b> Strong structural R:R is outperforming. Scaling into winning vectors recommended.";
    } else {
      proAnalysis = "💎 <b>ELITE PERFORMANCE:</b> Institutional alignment optimal. All systems nominal.";
    }

    const footer = `
🧠 <b>AETHER MIND INTELLIGENCE</b>
${proAnalysis}

💡 <i>System Note: V150 HOLOGRAPHIC active. Aether-Displacement filters engaged.</i>
━━━━━━━━━━━━━━━━━━
🕒 <i>Report Generated: ${new Date().toLocaleString()}</i>
    `.trim();
    
    sendTelegramAlert(footer);
    this.log(`🧠 MEMORY UPDATED: Refined weights for ${Object.keys(this.state.learningData).length} strategies`);
  }

  private calculateTradingMetrics() {
    const closedTrades = this.state.trades.filter(t => t.status === 'CLOSED');
    if (closedTrades.length === 0) return;

    const wins = closedTrades.filter(t => t.result === 'WIN');
    const losses = closedTrades.filter(t => t.result === 'LOSS');
    
    const totalWin = wins.reduce((acc, t) => acc + (t.profit || 0), 0);
    const totalLoss = Math.abs(losses.reduce((acc, t) => acc + (t.profit || 0), 0));
    
    this.state.metrics.profitFactor = totalLoss === 0 ? totalWin : totalWin / totalLoss;
    this.state.metrics.avgWin = wins.length === 0 ? 0 : totalWin / wins.length;
    this.state.metrics.avgLoss = losses.length === 0 ? 0 : totalLoss / losses.length;
    this.state.metrics.winRate = (wins.length / closedTrades.length) * 100;

    // Simple Max Drawdown calculation
    let maxBalance = 50;
    let currBalance = 50;
    let maxDD = 0;
    closedTrades.forEach(t => {
      currBalance += (t.profit || 0);
      if (currBalance > maxBalance) maxBalance = currBalance;
      const dd = ((maxBalance - currBalance) / maxBalance) * 100;
      if (dd > maxDD) maxDD = dd;
    });
    this.state.metrics.maxDrawdown = maxDD;

    // Sharpe Ratio Approximation (Monthly assumption)
    if (closedTrades.length > 5) {
      const returns = closedTrades.map(t => (t.profit || 0) / 50);
      const avgReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
      const stdDev = Math.sqrt(returns.map(x => Math.pow(x - avgReturn, 2)).reduce((a, b) => a + b, 0) / returns.length);
      this.state.metrics.sharpeRatio = stdDev === 0 ? 0 : (avgReturn / stdDev) * Math.sqrt(252); // Annualized
    }
  }

  private generateNeuralLesson(trade: Trade) {
    this.calculateTradingMetrics();
    this.state.neuralMemory.totalLessons++;
    const isWin = trade.result === 'WIN';
    
    // Professional insights based on famous trading wisdom (Mark Douglas, ICT, Larry Williams)
    const insights = [
      "In the 'Zone', you have no expectation of specific outcomes. Only probabilities. - Mark Douglas",
      "Retail liquidity rests above old highs and below old lows. Institutional targets acquired. - ICT",
      "Complexity is the enemy of execution. Trust the Order Flow convergence.",
      "The market is a device for transferring money from the impatient to the patient.",
      "Successful trading is 90% psychology and 10% strategy. Zen Pause successful.",
      "Smart Money doesn't chase. It waits at the POI (Point of Interest)."
    ];
    
    const randomProTip = insights[Math.floor(Math.random() * insights.length)];

    const insight: MarketInsight = {
      pattern: trade.strategy,
      successRate: isWin ? 92 : 8,
      environment: trade.environment as any,
      lastObserved: Date.now(),
      lesson: isWin 
        ? `✅ Success: ${randomProTip} | Institutional ${trade.strategy} verified. 🎯`
        : `❌ Logic Re-tune: ${randomProTip} | Manipulation encountered. 🚫`
    };

    this.state.insights.unshift(insight);
    if (this.state.insights.length > 30) this.state.insights.pop();

    // Standardized Neural Normalization (Institutional Standard)
    const strategy = trade.strategy;
    const currentWeight = this.state.neuralMemory.strategyWeights[strategy] || 1.0;
    const adjustment = isWin ? 0.08 : -0.12;
    
    // Normalize weights between 0.4 and 2.5 consistently across the entire system
    this.state.neuralMemory.strategyWeights[strategy] = Math.max(0.4, Math.min(2.5, currentWeight + adjustment));
    this.state.neuralMemory.lastSync = new Date().toISOString();
    
    // Accuracy tracking for Dynamic Threshold
    const total = this.state.neuralMemory.totalLessons;
    const oldAcc = this.state.neuralMemory.accuracy || 0.6;
    this.state.neuralMemory.accuracy = ((oldAcc * (total - 1)) + (isWin ? 1 : 0)) / total;

    // Add to state (Dashboard will use this)
    if (!this.state.learningData[strategy]) {
        this.state.learningData[strategy] = { winRate: 0, totalTrades: 0, profit: 0 };
    }
    const stats = this.state.learningData[strategy]!;
    stats.totalTrades++;
    if (isWin) stats.winRate = (stats.winRate * (stats.totalTrades - 1) + 100) / stats.totalTrades;
    else stats.winRate = (stats.winRate * (stats.totalTrades - 1)) / stats.totalTrades;
    stats.profit += trade.profit || 0;

    this.saveToMemory();
  }

  private updateLearningMemory(newTrades: Trade[]) {
    newTrades.forEach(t => {
      const isWin = t.result === 'WIN';
      const strategy = t.strategy;
      const env = t.environment || 'RANGING';
      
      const currentWeight = this.state.neuralMemory.strategyWeights[strategy] || 1.0;
      const adjustment = isWin ? 0.02 : -0.03;
      this.state.neuralMemory.strategyWeights[strategy] = Math.max(0.5, Math.min(2.0, currentWeight + adjustment));

      let envKey: 'Trending' | 'Ranging' | 'Volatile' = 'Ranging';
      if (env === 'TRENDING') envKey = 'Trending';
      if (env === 'VOLATILE') envKey = 'Volatile';

      const envPerf = this.state.neuralMemory.environmentPerformance[envKey];
      const envAdj = isWin ? 0.01 : -0.01;
      this.state.neuralMemory.environmentPerformance[envKey] = Math.max(0.1, Math.min(1.0, envPerf + envAdj));

      // NEW: Update human-readable strategy performance stats (V30)
      const strat = t.strategy || 'INSTITUTIONAL';
      if (!this.state.strategyPerformance[strat]) {
          this.state.strategyPerformance[strat] = { wins: 0, losses: 0, totalProfit: 0 };
      }
      if (t.result === 'WIN') this.state.strategyPerformance[strat].wins++;
      else if (t.result === 'LOSS') this.state.strategyPerformance[strat].losses++;
      this.state.strategyPerformance[strat].totalProfit += (t.profit || 0);
    });

    this.saveToMemory();
  }

  public setScalpingMode(enabled: boolean) {
    this.state.isScalpingEnabled = enabled;
    this.log(`SCALPING_MODE: ${enabled ? 'ENGAGED' : 'DISENGAGED'} ⚡`);
  }

  public toggleMode() {
    this.state.mode = this.state.mode === 'INSTITUTIONAL' ? 'SCALPING' : 'INSTITUTIONAL';
    this.state.isScalpingEnabled = this.state.mode === 'SCALPING';
    this.log(`BRIDGE_CONTROL: Active mode switched to ${this.state.mode}. Reconfiguring neural pipeline... 🛡️`);
  }

  public triggerScalp() {
    const candles = market.getCandles();
    if (candles.length < 10) return;
    const candle = candles[candles.length - 1];
    
    this.log(`MANUAL_SCALP: ANALYZING MOMENTUM CLUSTERS... ⚡`);
    
    // Profitable bias: Use trend of last 10 candles instead of Math.random()
    const last10 = candles.slice(-10);
    const momentum = last10[last10.length-1].close > last10[0].close ? 'LONG' : 'SHORT';
    
    const trade: Trade = {
      id: `scalp_${Date.now()}_${(this.logCounter % 1000).toString().padStart(3, '0')}`,
      time: Date.now(),
      type: momentum,
      entry: candle.close,
      sl: momentum === 'LONG' ? candle.close - 50 : candle.close + 50,
      tp: momentum === 'LONG' ? candle.close + 100 : candle.close - 100,
      status: 'OPEN',
      strategy: 'SCALPING',
      environment: this.state.environment,
      reason: `Scalp Engine: Momentum Alignment Detected [${momentum}]`
    };

    this.state.trades.push(trade);
    this.log(`SCALP_ORDER_FILLED: ${trade.type} @ ${trade.entry.toFixed(2)} | BIAS: MOMENTUM_SYNC`);
  }

  public setAsset(asset: AssetType) {
    this.state.currentAsset = asset;
    this.state.activeStrategy = null;
    this.lastStrategicShift = null;
    this.log(`SYNAPSE_SHIFT: Core now focused on ${asset} clusters. 📡`);
  }

  private lastStrategicShift: string | null = null;
  private lastHTFSync = 0;

  private lastDayProcessed: string = '';

  private lastTradeResult: 'WIN' | 'LOSS' | 'NONE' = 'NONE';
  private cooldownUntil: number = 0;

  private async scanHTFStructure() {
    try {
      // 1. BEHAVIORAL GUARDIAN: Daily Risk Limit
      const today = new Date().toISOString().split('T')[0];
      if (this.lastDayProcessed !== today) {
        this.lastDayProcessed = today;
        this.state.dailyLoss = 0;
      }

      // 2. PSYCHOLOGICAL COOLDOWN: No revenge trading
      if (Date.now() < this.cooldownUntil) {
        this.state.aiValidation = 'ZEN_PAUSE';
        if (this.logCounter % 50 === 0) {
           this.log(`🧘 PSYCHOLOGY: Still in cool-down after loss. Clearing head... 🍵`);
        }
        return;
      }

      if (this.state.dailyLoss >= this.state.dailyLossLimit) {
        if (this.logCounter % 50 === 0) {
          this.log(`🚨 RISK GUARDIAN: Daily loss limit reached ($${this.state.dailyLoss.toFixed(2)}). Trading suspended. 🛡️`);
        }
        return;
      }

      // 2. EMERGENCY BALANCE GUARD
      if (this.state.balance < 45) {
        this.log(`🚨 EMERGENCY LOCK: Balance below $45 Guardrail ($${this.state.balance.toFixed(2)}). Analyzing failure clusters. Trading suspended to protect equity. 🛡️`);
        return;
      }

      const symbol = this.state.currentAsset === 'GOLD' ? 'PAXGUSDT' : (this.state.currentAsset === 'FOREX' ? 'EURUSDT' : 'BTCUSDT');
      const candles = await fetchHTFData(symbol, '1h');
      if (candles.length < 20) return;

      const last = candles[candles.length - 1];
      const avg = candles.slice(-20).reduce((acc, c) => acc + c.close, 0) / 20;

      // HTF Bias Detection
      const diff = ((last.close - avg) / avg) * 100;
      if (Math.abs(diff) < 0.15) {
        this.state.htfBias = 'RANGING';
      } else {
        this.state.htfBias = last.close > avg ? 'BULLISH' : 'BEARISH';
      }
      
      // Liquidity Mapping (Swing Highs/Lows)
      const htfHighs = candles.slice(-24).map(c => c.high);
      const htfLows = candles.slice(-24).map(c => c.low);
      
      this.state.liquidityMap = {
        buyside: Math.max(...htfHighs),
        sellside: Math.min(...htfLows),
        unmitigatedOB: candles.find(c => c.volume > (avg * 5))?.close || null
      };

      if (this.logCounter % 30 === 0) {
        this.log(`HTF_AUDIT: [1H Structure] Bias: ${this.state.htfBias} | BuySide: ${this.state.liquidityMap.buyside.toFixed(2)} | SellSide: ${this.state.liquidityMap.sellside.toFixed(2)}`);
      }
      
      this.lastHTFSync = Date.now();
    } catch (e) {
      this.log(`⚠️ HTF_FAILURE: Could not interface with macro data streams.`);
    }
  }

  public async update() {
    // 1. DATA ACQUISITION & CONTEXT MAPPING
    if (Date.now() - this.lastHTFSync > 300000) { 
       await this.scanHTFStructure();
    }

    const candle = await market.tick(this.state.currentAsset);
    this.state.environment = market.detectEnvironment();
    
    // 2. DISCIPLINE MODULE (Mark Douglas / Psychology Guardian)
    if (this.checkDrawdown()) return;
    if (!this.checkDailyRisk()) return;

    if (Date.now() < this.cooldownUntil) {
      this.state.aiValidation = 'ZEN_PAUSE';
      if (this.logCounter % 50 === 0) this.log(`🧘 PSYCHOLOGY: Zen Pause active. Professionals don't force trades. 🍵`);
      return;
    }

    if (detectMacroImpact()) {
        this.state.aiValidation = 'MACRO_PAUSE';
        if (this.logCounter % 50 === 0) this.log(`📡 MACRO_LOCK: High volatility event detected. Watching from sidelines. 🛡️`);
        return;
    }

    // Reset status if clear
    if (['ZEN_PAUSE', 'MACRO_PAUSE'].includes(this.state.aiValidation)) {
        this.state.aiValidation = 'IDLE';
    }

    // 3. TRADE MANAGEMENT (Ongoing Operations)
    this.processTradeManagement(candle);

    // 4. TRADE SIGNAL PROCESSING
    // Professional focus: Max 4 concurrent trades to hit high frequency targets
    const maxTrades = 4;
    if (this.state.trades.filter(t => t.status === 'OPEN').length >= maxTrades) return;

    // 4. NEURAL SIGNAL SCAN (V150 Aether Mind)
    const candles = market.getCandles();
    const { score, activeBias, logs, regime, reasoning, nexusNodes, conviction, expansion, qvd, smcStrategy1, smcStrategy2, smcStrategy3, smcStrategy5, smcStrategy6, smcStrategy7 } = calculateSuperhumanScore(candles, candle.time, this.state.bias as any, this.state.mode === 'SCALPING');
    this.state.score = score;
    this.state.bias = (activeBias === 'BULLISH' ? 'LONG' : 'SHORT') as any;
    this.state.currentRegime = regime;
    this.state.nexusNodes = nexusNodes;
    
    // V159: Professional Entry Protection - Refined risk tightening
    const riskTightening = this.consecutiveLosses > 0 ? (1 + (this.consecutiveLosses * 0.15)) : 1.0;
    
    // V159: Price Level Discipline
    let priceDiscipline = 1.0;
    const lastTrade = this.state.trades[this.state.trades.length - 1];
    if (lastTrade && lastTrade.result === 'LOSS') {
      const priceDiff = Math.abs(candle.close - lastTrade.entry) / lastTrade.entry;
      if (priceDiff < 0.001) { 
        priceDiscipline = 1.25; 
      }
    }

    const mpi = calculateMPI(candles);
    const mpiMultiplier = Math.max(0.35, Math.min(1.15, 1 / (mpi * 1.8)));
    const convictionMultiplier = conviction === 'SOVEREIGN' ? 0.65 : (conviction === 'HIGH' ? 0.80 : 1.0);
    const neuralWeight = getNeuralWeighting(this.state.strategyPerformance, 'SMC_SUPERHUMAN') || 1.0;
    
    const baseThreshold = this.state.mode === 'SCALPING' ? 85.0 : 110.0; 
    const threshold = (baseThreshold * mpiMultiplier * convictionMultiplier * riskTightening * priceDiscipline) / neuralWeight;

    const effectiveScore = this.state.score - this.checkNeuralRejection();

    const isScalping = this.state.mode === 'SCALPING';

    // V163: ADVANCED HUMAN CONTEXT PROTECTION (Risk Management V2)
    const secondGuessReasons: string[] = [];
    const last10 = candles.slice(-10);
    const rangeSize = Math.max(...last10.map(c => c.high)) - Math.min(...last10.map(c => c.low));
    const avgAtr = calculateATR(candles, 14);
    
    // 1. Choppiness & Momentum Check
    const rsi = calculateRSI(candles, 14);
    if (rangeSize < avgAtr * (isScalping ? 0.20 : 0.40)) secondGuessReasons.push("Low Volatility Squeeze");
    if (!isScalping) {
      if (activeBias === 'BULLISH' && rsi > 70) secondGuessReasons.push("RSI Overbought (>70)");
      if (activeBias === 'BEARISH' && rsi < 30) secondGuessReasons.push("RSI Oversold (<30)");

      // 3. Narrative Alignment: Still strict
      if (this.state.htfBias !== 'NEUTRAL' && this.state.htfBias !== (activeBias === 'BULLISH' ? 'BULLISH' : 'BEARISH')) {
         secondGuessReasons.push("Counter-HTF Friction");
      }
    } else {
      if (activeBias === 'BULLISH' && rsi > 85) secondGuessReasons.push("RSI Overextended (>85)");
      if (activeBias === 'BEARISH' && rsi < 15) secondGuessReasons.push("RSI Overextended (<15)");
    }

    // 3. V163 Reward-to-Risk Requirement (Minimum 1:3.0)
    const lookPrevForRR = candles.slice(-25);
    const tHigh = Math.max(...lookPrevForRR.map(c => c.high));
    const tLow = Math.min(...lookPrevForRR.map(c => c.low));
    const potProfit = activeBias === 'BULLISH' ? (tHigh - candle.close) : (candle.close - tLow);
    const projSL = avgAtr * (isScalping ? 0.85 : 1.45); 
    
    const pRR = potProfit / projSL;
    const minRRRequired = isScalping ? 1.5 : 3.0;
    if (pRR < minRRRequired) secondGuessReasons.push(`Weak Potential RR (${pRR.toFixed(1)})`);

    const isHumanValid = secondGuessReasons.length === 0;

    // Nexus Entry V158: Aether Mind Execution
    if (effectiveScore >= threshold) {
      if (!isHumanValid) {
        if (this.logCounter % 20 === 0) {
          this.log(`🕵️ [HUMAN_INSTINCT] Selective Filter: ${secondGuessReasons[0]}. Passing for better RR. 🧠`);
        }
        return;
      }
      
      if (this.state.aiValidation !== 'PENDING') {
          this.state.aiValidation = 'PENDING';
          this.state.setupFound = true;
          
          const eventTag = conviction === 'SOVEREIGN' ? '👽 [SOVEREIGN_BREACH]' : '🔭 [V151_HOLOGRAPHIC]';
          this.log(`${eventTag} Aether synced: ${effectiveScore.toFixed(0)} / ${threshold.toFixed(0)}. Multi-dimensional Alpha locked.`);
          
          this.state.tradingPlan = reasoning.join(' → ');

          const initialPrice = candle.close;
          setTimeout(() => {
            const currentCandles = market.getCandles();
            const latest = currentCandles[currentCandles.length - 1];
            
            // Human-Brain Tape Reading: Confirmation of intent
            const priceMovement = this.state.bias === 'LONG' ? (latest.close - initialPrice) : (initialPrice - latest.close);
            const movementPercent = priceMovement / initialPrice;
            
            // Tape Confirmation: A human allows minor breathing room but rejects if momentum stalls completely
            const tapeConfirmation = movementPercent > -0.00004; 

            if (this.state.aiValidation === 'PENDING' && tapeConfirmation) {
               const confidence = Math.min(100, (effectiveScore / threshold) * 94);
               this.executeTrade(true, confidence, reasoning, conviction, smcStrategy1, smcStrategy2, smcStrategy3);
            } else {
               this.state.aiValidation = 'REJECTED';
               const reason = movementPercent <= -0.00004 ? "Divergent Sell-Side pressure" : "Institutional stalling";
               this.log(`⚠️ [AETHER_REJECTION] ${reason}. Predatory trap avoided. 🧤`);
            }
          }, 1200); // Faster reaction (1.2s) for better entry price
      }
    } else if (this.logCounter % 40 === 0) {
      this.state.aiValidation = 'IDLE';
      const gap = (threshold - effectiveScore).toFixed(1);
      this.state.tradingPlan = effectiveScore > threshold * 0.6 
        ? `Aether resonance: Seeking ${gap} more alignment points. 🔭` 
        : `Scanning Aether: ${regime}. Context: ${this.state.bias}.`;
      
      this.log(`🔭 [V150_HOLOGRAPHIC] Bias: ${this.state.bias} | Alpha: ${this.state.score.toFixed(1)} / ${threshold.toFixed(1)} ${this.consecutiveLosses > 0 ? '(Risk_Degraded)' : ''}`);
    }
  }

  private consecutiveLosses = 0;
  private quarantineUntil = 0;
  private lastLossReset = 0;

  private checkDailyRisk(): boolean {
    const today = new Date().setHours(0,0,0,0);
    if (this.lastLossReset !== today) {
        this.state.dailyLoss = 0;
        this.state.dailyProfit = 0;
        this.lastLossReset = today;
    }
    
    // Dynamic Risk: 2% of current balance
    this.state.dailyLossLimit = this.state.balance * 0.02;
    this.state.dailyProfitTarget = this.state.balance * 0.04; // 4% Daily Goal

    if (this.state.dailyProfit >= this.state.dailyProfitTarget) {
        if (this.logCounter % 50 === 0) {
            this.log(`🎯 TARGET_ACHIEVED: Daily profit goal hit (+$${this.state.dailyProfit.toFixed(2)}). Zen Mode active. 🧘`);
            this.state.aiValidation = 'ZEN_PAUSE';
        }
        return false;
    }

    if (this.state.dailyLoss >= this.state.dailyLossLimit) {
        if (this.logCounter % 15 === 0) {
            this.log(`🚨 PSYCHOLOGICAL_SHUTDOWN: Daily risk cap reached ($${this.state.dailyLoss.toFixed(2)}). Professional traders walk away after 2% loss. See you tomorrow. 🛡️`);
            sendTelegramAlert(`🚨 <b>DAILY LIMIT REACHED</b>\n$${this.state.dailyLoss.toFixed(2)} loss hit. Bot paused to protect capital. 🛡️`);
        }
        return false;
    }
    return true;
  }

  private processTradeManagement(candle: Candle) {
    if (Date.now() < this.quarantineUntil) return;
    if (!this.checkDailyRisk()) return;

    this.state.trades.filter(t => t.status === 'OPEN').forEach(trade => {
        const pnl = trade.type === 'LONG' ? (candle.close - trade.entry) : (trade.entry - candle.close);
        const slDist = Math.abs(trade.entry - trade.sl);
        const rRatio = pnl / slDist;
        const isLong = trade.type === 'LONG';

        // 1. V161 sovereignMind: Sovereign Management (Professional Protection)
        const beThreshold = 1.1; // Move to BE early (+1.1R)
        const p1Threshold = trade.conviction === 'SOVEREIGN' ? 6.5 : 4.2; 
        const p2Threshold = trade.conviction === 'SOVEREIGN' ? 14.0 : 8.5;

        // V162: Strategy 1 Multi-TP Logic
        const hitTP1 = trade.tp2 && (isLong ? candle.high >= trade.tp2 : candle.low <= trade.tp2);
        const hitTP2 = trade.tp3 && (isLong ? candle.high >= trade.tp3 : candle.low <= trade.tp3);
        const hitOTE = trade.strategy === 'STRATEGY_1_SMC_OTE';
        const hitSMC2 = trade.strategy === 'STRATEGY_2_LIQUIDITY_REVERSAL';
        const hitSMC3 = trade.strategy === 'STRATEGY_3_BREAKOUT_RETEST';

        // V161: Human "Patience" Check - Exhaustion Exit
        const targetDist = Math.abs(trade.tp - trade.entry);
        const currentProgress = pnl / (targetDist || 1);
        const marketCandles = market.getCandles();
        const lastCandle = marketCandles[marketCandles.length - 1];
        const isExhaustion = (isLong && lastCandle.wickUpper > lastCandle.bodySize * 2.5) || (!isLong && lastCandle.wickLower > lastCandle.bodySize * 2.5);

        if (currentProgress > 0.85 && isExhaustion && !trade.partialTaken) {
            this.log(`🕵️ [HUMAN_INSTINCT] Market exhaustion. Secure 85% alpha. 🧠`);
            this.executePartialTP(trade, candle.close, (trade.units || 0) * 0.85, "EXHAUSTION_EXIT");
            trade.sl = isLong ? trade.entry + (slDist * 0.5) : trade.entry - (slDist * 0.5);
            trade.partialTaken = true;
        }

        // 1. V161 sovereignMind: Sovereign Management (Professional Protection)
        
        if ((rRatio >= beThreshold || (hitOTE && rRatio > 0.8) || (hitSMC2 && rRatio > 0.6) || (hitSMC3 && rRatio > 0.7)) && !trade.beMoved) {
            const profitBuffer = slDist * 0.15; 
            trade.sl = isLong ? trade.entry + profitBuffer : trade.entry - profitBuffer; 
            trade.beMoved = true;
            this.log(`🛡️ [V161_BE] Principal secured. Capital protected.`);
        }

        // V150: Predatory Scaling
        if ((rRatio >= p1Threshold || hitTP1) && !trade.partialTaken) {
            const partialUnits = (trade.units || 0) * 0.4; // Scaled 40% at TP1
            this.executePartialTP(trade, candle.close, partialUnits, hitTP1 ? 'SMC_TP1' : `AETHER-1_${p1Threshold}R`);
            
            const lockRatio = 2.0;
            const lockBuffer = slDist * lockRatio; 
            trade.sl = isLong ? trade.entry + lockBuffer : trade.entry - lockBuffer;
            trade.partialTaken = true;
        }

        if ((rRatio >= p2Threshold || hitTP2) && trade.partialTaken && !trade.partialTaken2) {
            const runnerUnits = (trade.units || 0) * 0.5; // Scale another 50% of remaining 
            this.executePartialTP(trade, candle.close, runnerUnits, hitTP2 ? 'SMC_TP2' : `AETHER-2_${p2Threshold}R`);
            
            const lockRatio = 4.0;
            const lockBuffer = slDist * lockRatio; 
            trade.sl = isLong ? trade.entry + lockBuffer : trade.entry - lockBuffer;
            trade.partialTaken2 = true;
        }

        // V150 Aether Mind: God Candle Sync (Reflex Trailing)
        if (rRatio >= 10.0) {
            const trailPercent = trade.conviction === 'SOVEREIGN' ? 0.55 : 0.75; 
            const trailingBuffer = slDist * trailPercent;
            const newSl = isLong ? candle.close - trailingBuffer : candle.close + trailingBuffer;
            if (isLong && newSl > trade.sl) trade.sl = newSl;
            else if (!isLong && newSl < trade.sl) trade.sl = newSl;
        }

        // 1b. Early Institutional Rejection Exit 
        const currentFVGData = detectFVG(market.getCandles().slice(-5));
        if (currentFVGData.detected) {
            const isRejection = (isLong && currentFVGData.type === 'BEARISH') || (!isLong && currentFVGData.type === 'BULLISH');
            if (isRejection && rRatio > 0.4) {
                this.log(`🚨 REJECTION: Reversal FVG detected at ${currentFVGData.type}. Terminating position early to lock current alpha.`);
                this.executeTradeExit(trade, candle.close, 'REJECTION', candle);
                return;
            }
        }

        // 3. Time-Based Liquidation
        const ageMinutes = (Date.now() - trade.time) / 60000;
        if (ageMinutes > 240 && rRatio < 0.5 && rRatio > -0.5) { 
            this.log(`AUDIT: [Time Decay] Trade stuck in range for 4h. Closing half to mitigate time risk. ⏳`);
            const decayUnits = (trade.units || 0) * 0.5;
            this.state.balance += (pnl * decayUnits);
            trade.units = (trade.units || 0) - decayUnits;
        }

        // 4. Hard Exit
        const isHitTP = trade.type === 'LONG' ? candle.high >= trade.tp : candle.low <= trade.tp;
        const isHitSL = trade.type === 'LONG' ? candle.low <= trade.sl : candle.high >= trade.sl;

        if (isHitTP || isHitSL) {
            this.executeTradeExit(trade, isHitTP ? trade.tp : trade.sl, isHitTP ? 'TP' : 'SL', candle);
        }
    });
  }

  private executeTradeExit(trade: Trade, exitPrice: number, reason: string, candle: Candle) {
    trade.status = 'CLOSED';
    const isWin = (trade.type === 'LONG' && exitPrice > trade.entry) || (trade.type === 'SHORT' && exitPrice < trade.entry);
    trade.result = isWin ? 'WIN' : 'LOSS';
    
    const priceDiff = trade.type === 'LONG' ? (exitPrice - trade.entry) : (trade.entry - exitPrice);
    const rawProfit = (trade.units || 0) * priceDiff;
    
    const slippage = (trade.units || 0) * trade.entry * 0.0002;
    const fee = (trade.units || 0) * trade.entry * 0.001;
    
    const finalLegProfit = rawProfit - fee - slippage;
    trade.profit = (trade.profit || 0) + finalLegProfit; // V110: Final cumulative profit
    trade.fee = (trade.fee || 0) + fee;
    trade.slippage = (trade.slippage || 0) + slippage;
    
    this.state.balance += finalLegProfit;
    
    if ((trade.profit || 0) > 0) {
        this.state.dailyProfit += trade.profit!;
    }
    this.state.monthlyPnl += (trade.profit || 0);
    
    // Re-calculate Monthly Win Rate
    const recentTrades = this.state.trades.slice(-100);
    const winsCount = recentTrades.filter(t => t.result === 'WIN').length;
    this.state.monthlyWinRate = recentTrades.length > 0 ? (winsCount / recentTrades.length) * 100 : 0;

    // NEURAL FEEDBACK
    const strat = trade.strategy || 'INSTITUTIONAL';
    if (!this.state.strategyPerformance[strat]) {
        this.state.strategyPerformance[strat] = { wins: 0, losses: 0, totalProfit: 0 };
    }
    if (trade.result === 'WIN') this.state.strategyPerformance[strat].wins++;
    else if (trade.result === 'LOSS') this.state.strategyPerformance[strat].losses++;
    this.state.strategyPerformance[strat].totalProfit += (trade.profit || 0);

    if (trade.result === 'LOSS') {
        this.state.dailyLoss += Math.abs(trade.profit || 0);
        this.consecutiveLosses++;
        // V140: 15m cooldown after any loss to avoid cluster failures
        this.cooldownUntil = Date.now() + 900000; 
        
        // V140: Aggressive Consecutive Loss Breaker
        if (this.consecutiveLosses >= 2) {
            const minutes = this.consecutiveLosses >= 3 ? 240 : 60;
            this.cooldownUntil = Date.now() + (minutes * 60000);
            this.log(`🚨 BREAKER_TRIPPED: ${this.consecutiveLosses} consecutive losses. Manual override engaged for ${minutes}m. Protecting balance. 🛡️`);
            sendTelegramAlert(`🚨 <b>BREAKER TRIPPED</b>\n${this.consecutiveLosses} losses in a row detected. System locked for ${minutes} minutes to prevent drawdown. 🛡️`);
        }
        this.log(`🧘 PSYCHOLOGY: Exit completed at ${reason}. Synchronizing Aether...`);
    } else {
        this.consecutiveLosses = 0;
        this.cooldownUntil = Date.now() + 300000; // 5m win-pause
        this.log(`💎 SUCCESS: ${reason} reached. Profit captured. Aether Mind stabilized.`);
    }

    this.log(`TRADE CLOSED [${reason}]: Result ${trade.result} | PnL: $${(trade.profit || 0).toFixed(2)}`);
    
    const closeMsg = `
🏁 <b>TRADE CLOSED: ${trade.result === 'WIN' ? '🟢 PROFIT' : '🔴 STOPPED'}</b>
━━━━━━━━━━━━━━━━━━
💰 <b>PNL:</b> <code>${(trade.profit || 0) >= 0 ? '+' : ''}$${(trade.profit || 0).toFixed(2)}</code>
📊 <b>ENTRY:</b> <code>${trade.entry.toFixed(2)}</code>
🔚 <b>EXIT:</b> <code>${exitPrice.toFixed(2)}</code>
🛡️ <b>STRATEGY:</b> <code>${trade.strategy}</code>
⌛ <b>DURATION:</b> <code>${Math.round((Date.now() - trade.time) / 60000)}m</code>
🛸 <b>BALANCE:</b> <code>$${this.state.balance.toFixed(2)}</code>
━━━━━━━━━━━━━━━━━━
    `.trim();
    sendTelegramAlert(closeMsg);
    
    this.generateNeuralLesson(trade);
    this.saveToMemory();
  }

  private processSuperhumanV26(candle: Candle) {
    const candles = market.getCandles();
    if (candles.length < 60) return;

    const htfBias = getHTFBias(candles);
    const phase = detectMarketPhase(candles);
    
    this.state.marketPhase = phase;
    this.state.htfBias = htfBias;

    const { score, activeBias, logs } = calculateSuperhumanScore(
      candles, 
      Date.now(), 
      htfBias, 
      this.state.mode === 'SCALPING'
    );
    
    // Log individual confluences
    if (this.logCounter % 40 === 0) {
      logs.forEach(l => this.log(l));
    }

    // Adaptive threshold based on neural learning (V40 Quantum)
    const baseThreshold = this.state.mode === 'SCALPING' ? 135.0 : 165.0;
    const neuralWeight = getNeuralWeighting(this.state.strategyPerformance, 'SMC_SUPERHUMAN');
    const adaptiveThreshold = baseThreshold / neuralWeight;
    
    this.state.score = score;
    this.state.setupFound = score >= adaptiveThreshold; 
    
    // Update Trading Plan for transparency (Conversational human style)
    if (this.state.setupFound) {
      const topConfluence = logs[logs.length - 1] || 'Setup aligned.';
      this.state.tradingPlan = `Confirmed: ${topConfluence} Executing...`;
    } else if (score >= 70) {
      this.state.tradingPlan = `Analyzing ${activeBias} opportunity. Context quality at ${score.toFixed(0)}. Expectant.`;
    } else {
      this.state.tradingPlan = `Market is ${this.state.marketPhase.toLowerCase()}. HTF flows are ${this.state.htfBias.toLowerCase()}. Staying patient.`;
    }
    
    if (this.state.setupFound) {
      this.state.bias = activeBias === 'BULLISH' ? 'LONG' : 'SHORT';
      this.state.activeStrategy = 'SMC_SUPERHUMAN';
      if (neuralWeight > 1.0) {
          this.log(`🧬 [NEURAL_BOOST] High confidence detected. Filtering set to ${adaptiveThreshold.toFixed(1)}.`);
      }
      this.log(`🌠 [SUPERHUMAN] Institutional confluence found | Strength: ${score.toFixed(1)} | Logic aligned ✅`);
    }
  }

  private checkNeuralRejection(): number {
    if (!this.state.activeStrategy) return 0;
    const currentWeight = this.state.neuralMemory.strategyWeights[this.state.activeStrategy] || 1.0;
    
    // Penalize if the strategy weight has fallen below 0.7
    if (currentWeight < 0.8) return 1.0;
    if (currentWeight < 0.9) return 0.5;
    return 0;
  }

  private processGoldLogic(candle: Candle) {
    const candles = market.getCandles();
    if (candles.length < 60) return;

    // 1. H1 Trend (Trend alignment)
    const h1Lookback = candles.slice(-60);
    const startPrice = h1Lookback[0].close;
    const endPrice = h1Lookback[h1Lookback.length - 1].close;
    const h1Trend = endPrice > startPrice ? 'BULLISH' : (endPrice < startPrice ? 'BEARISH' : 'NEUTRAL');
    
    // 2. OB/FVG Detection (Institutional foot prints)
    const recent = candles.slice(-5);
    const isOB = recent.some(c => c.volume > 5000 && c.bodySize > 50);
    
    const fvgIdx = candles.length - 2;
    const isFVG = Math.abs(candles[fvgIdx-1].high - candles[fvgIdx+1].low) > 10;

    // 3. M15 CHoCH (Change of Character)
    const m15Lookback = candles.slice(-15);
    const m15High = Math.max(...m15Lookback.map(c => c.high));
    const m15Low = Math.min(...m15Lookback.map(c => c.low));
    const isChoch = (h1Trend === 'BEARISH' && candle.close > m15High) || (h1Trend === 'BULLISH' && candle.close < m15Low);

    const alignment = (h1Trend === 'BULLISH' && candle.close > m15Low) || (h1Trend === 'BEARISH' && candle.close < m15High);

    this.state.goldNeuralState = {
      h1Trend,
      m15Choch: isChoch,
      obDetected: isOB,
      fvgDetected: isFVG,
      alignment: alignment && (isOB || isFVG)
    };

    if (this.state.goldNeuralState.alignment) {
      this.state.activeStrategy = 'SMC_GOLD';
      this.state.setupFound = true;
      this.state.score = 5; // Fixed high score for Gold SMC alignment
      this.log(`ALERT: [GOLD_SMC] Alignment Confirmed. H1 ${h1Trend} + Institutional Zone Detected. 🏢🛸`);
    } else {
      this.state.setupFound = false;
    }
  }

  private checkDrawdown() {
    const today = new Date().toDateString();
    const todayTrades = this.state.trades.filter(t => new Date(t.time).toDateString() === today && t.status !== 'OPEN');
    const dayPnL = todayTrades.reduce((acc, t) => acc + (t.profit || 0), 0);
    const maxLoss = this.state.balance * 0.04; // 4% Rule

    if (dayPnL <= -maxLoss) {
      this.log(`Critical Halt: Daily Drawdown Limit (-4%) Hit. Terminating logic tree for ${today}. 🛑`);
      return true;
    }
    return false;
  }

  public executeTrade(valid: boolean, confidence: number = 94, reasoning: string[] = [], conviction: 'NORMAL' | 'HIGH' | 'SOVEREIGN' = 'NORMAL', smcStrategy1?: any, smcStrategy2?: any, smcStrategy3?: any, smcStrategy5?: any, smcStrategy6?: any, smcStrategy7?: any) {
    if (this.checkDrawdown()) {
      this.state.aiValidation = 'REJECTED';
      return;
    }

    if (!valid) {
      this.state.aiValidation = 'REJECTED';
      this.log(`⚠️ TRADE_REJECTED: Brain context inconsistent. Monitoring...`);
      return;
    }

    this.state.aiValidation = 'VALID';
    this.log(`AUDIT: [AI Filter] VALID 👽 [Conviction: ${conviction}]`);
    
    const isLong = this.state.bias === 'LONG';
    const candles = market.getCandles();
    const candle = candles[candles.length - 1];

    // V120 Prometheus: Deep Structural Protected SL
    const atr = calculateATR(candles, 14);
    const lookback = candles.slice(-50);
    const sLow = Math.min(...lookback.map(c => c.low));
    const sHigh = Math.max(...lookback.map(c => c.high));

    let sl: number;
    if (smcStrategy1?.detected) {
      sl = smcStrategy1.sl;
    } else if (smcStrategy2?.detected) {
      sl = smcStrategy2.sl;
    } else if (smcStrategy3?.detected) {
      sl = smcStrategy3.sl;
    } else if (smcStrategy5?.detected) {
      sl = smcStrategy5.sl;
    } else if (smcStrategy6?.detected) {
      sl = smcStrategy6.sl;
    } else if (smcStrategy7?.detected) {
      sl = smcStrategy7.sl;
    } else if (isLong) {
        sl = Math.min(sLow - (atr * 0.1), candle.close - (atr * 1.4));
    } else {
        sl = Math.max(sHigh + (atr * 0.1), candle.close + (atr * 1.4));
    }

    const slDist = Math.abs(candle.close - sl);
    
    // V161 High-Reward Targets
    let rr = 4.5;
    if (smcStrategy1?.detected) {
        // Strategy 1 specific RR - using its TP3 for the main target
        const tp3 = smcStrategy1.tp[2];
        rr = Math.abs(tp3 - candle.close) / slDist;
    } else if (smcStrategy2?.detected) {
        // Strategy 2: Swing Targets
        const tp2 = smcStrategy2.tp[1];
        rr = Math.abs(tp2 - candle.close) / slDist;
    } else if (smcStrategy3?.detected) {
        // Strategy 3: Breakout Retest
        const tp2 = smcStrategy3.tp[1];
        rr = Math.abs(tp2 - candle.close) / slDist;
    } else if (smcStrategy5?.detected) {
        const tp2 = smcStrategy5.tp[1];
        rr = Math.abs(tp2 - candle.close) / slDist;
    } else if (smcStrategy6?.detected) {
        const tp1 = smcStrategy6.tp[0];
        rr = Math.abs(tp1 - candle.close) / slDist;
    } else if (smcStrategy7?.detected) {
        const tp1 = smcStrategy7.tp[0];
        rr = Math.abs(tp1 - candle.close) / slDist;
    } else if (conviction === 'SOVEREIGN') rr = 18.0;
    else if (conviction === 'HIGH') rr = 12.0;
    else rr = Math.max(4.5, (this.state.score / 25));

    const tpDist = slDist * rr;
    const tp = isLong ? candle.close + tpDist : candle.close - tpDist;

    // V150 Matrix Protection: Progressive Risk Reduction (V163: Hot-Hand Alignment)
    const baseRisk = 0.015; 
    let multiplier = 1.0;
    
    // Risk degradation after losses to prevent rapid drawdown
    if (this.consecutiveLosses === 1) multiplier = 0.55;
    else if (this.consecutiveLosses >= 2) multiplier = 0.35;

    // Winning Streak Boost (The "Hot Hand" - Institutional Scaling)
    const recentClosedTrades = this.state.trades.slice(-5).filter(t => t.status === 'CLOSED');
    const winStreakDetected = recentClosedTrades.length >= 2 && recentClosedTrades.every(t => (t.profit || 0) > 0);
    if (winStreakDetected) {
       multiplier *= 1.3; // Scale up 30% when winning
       this.log(`🔥 [HOT_HAND]: Momentum alignment detected. Adaptive scaling increased by 30%.`);
    }

    if (smcStrategy1?.detected) multiplier *= 3.2; 
    else if (smcStrategy2?.detected) multiplier *= 3.8; 
    else if (smcStrategy3?.detected) multiplier *= 3.0; 
    else if (smcStrategy5?.detected) multiplier *= 1.8;
    else if (smcStrategy6?.detected) multiplier *= 1.5;
    else if (smcStrategy7?.detected) multiplier *= 2.5; // High confidence for Engulfing
    else if (conviction === 'SOVEREIGN') multiplier *= 4.2;
    else if (conviction === 'HIGH') multiplier *= 2.8;

    // DD Protection (Aggressive De-leveraging if capital is eroded)
    const currentDrawdownMetric = this.state.metrics.maxDrawdown;
    const ddScaling = currentDrawdownMetric > 15 ? 0.4 : (currentDrawdownMetric > 10 ? 0.7 : 1.0);
    
    const finalRisk = baseRisk * multiplier * ddScaling;
    const riskAmount = this.state.balance * finalRisk;
    const units = riskAmount / slDist;

    const tp2 = smcStrategy1?.detected ? smcStrategy1.tp[0] : (smcStrategy2?.detected ? smcStrategy2.tp[0] : (smcStrategy3?.detected ? smcStrategy3.tp[0] : (smcStrategy5?.detected ? smcStrategy5.tp[0] : undefined)));
    const tp3 = smcStrategy1?.detected ? smcStrategy1.tp[1] : (smcStrategy2?.detected ? smcStrategy2.tp[1] : (smcStrategy3?.detected ? smcStrategy3.tp[1] : (smcStrategy5?.detected ? smcStrategy5.tp[1] : undefined)));
    const strategyName = smcStrategy1?.detected ? 'STRATEGY_1_SMC_OTE' 
      : (smcStrategy2?.detected ? 'STRATEGY_2_LIQUIDITY_REVERSAL' 
      : (smcStrategy3?.detected ? 'STRATEGY_3_BREAKOUT_RETEST' 
      : (smcStrategy5?.detected ? 'STRATEGY_5_EMA_RSI' 
      : (smcStrategy6?.detected ? 'STRATEGY_6_TRENDLINE_SCALP' 
      : (smcStrategy7?.detected ? 'STRATEGY_7_SR_ENGULFING' 
      : (this.state.activeStrategy || 'SMC_SUPERHUMAN'))))));

    const trade: Trade = {
      id: `live_${Date.now()}_v150`,
      time: Date.now(),
      type: isLong ? 'LONG' : 'SHORT',
      entry: candle.close,
      sl: sl,
      initialSL: sl,
      tp: tp,
      tp2,
      tp3,
      status: 'OPEN',
      strategy: strategyName as StrategyType,
      environment: this.state.environment as any,
      reason: smcStrategy1?.detected ? smcStrategy1.reason 
        : (smcStrategy2?.detected ? smcStrategy2.reason 
        : (smcStrategy3?.detected ? smcStrategy3.reason 
        : (smcStrategy5?.detected ? smcStrategy5.reason 
        : (smcStrategy6?.detected ? smcStrategy6.reason 
        : (smcStrategy7?.detected ? smcStrategy7.reason 
        : `V150 ${conviction} | Alpha ${this.state.score.toFixed(0)}`))))),
      reasoning_chain: reasoning,
      alpha_confidence: confidence,
      conviction,
      units: units
    };

    if (this.state.balance < riskAmount || units <= 0) {
       this.log(`🚨 RISK: Insufficient margin for Aether execution.`);
       return;
    }

    this.state.trades.push(trade);
    this.state.setupFound = false;
    
    const detailMsg = `
🚀 <b>V150 AETHER MIND ORDER [${conviction}]</b>
━━━━━━━━━━━━━━━━━━
🔼 <b>TYPE:</b> <code>${trade.type}</code>
📈 <b>ENTRY:</b> <code>${trade.entry.toFixed(2)}</code>
🛑 <b>STOP:</b> <code>${trade.sl.toFixed(2)}</code>
🎯 <b>TARGET:</b> <code>${trade.tp.toFixed(2)}</code> [<b>${rr.toFixed(1)}R</b>]
🧠 <b>STRATEGY:</b> <code>${trade.strategy}</code>
🔥 <b>RISK:</b> <code>${(finalRisk * 100).toFixed(2)}%</code> ${this.consecutiveLosses > 0 ? '[DEGRADED]' : '[PEAK]'}
📊 <b>ALPHA:</b> <code>${this.state.score.toFixed(1)}</code>

💡 <i>Analysis: [${conviction}] Aether sync confirmed. Holographic deployment active. 🔱</i>
━━━━━━━━━━━━━━━━━━
🕒 ${new Date().toLocaleTimeString()}
    `.trim();

    sendTelegramAlert(detailMsg);
    this.log(`V150_FILLED: ${trade.type} @ ${trade.entry.toFixed(2)} | RR ${rr.toFixed(1)} | ${conviction} ✅`);
    this.state.score = 0;
  }

  private logCounter = 0;

  private executePartialTP(trade: Trade, currentPrice: number, unitsToClose: number, reason: string) {
    const isLong = trade.type === 'LONG';
    const profitDiff = isLong ? (currentPrice - trade.entry) : (trade.entry - currentPrice);
    const profitRaw = unitsToClose * profitDiff;
    const fee = Math.abs(profitRaw * 0.001); // 0.1% est. fee
    
    const netProfit = profitRaw - fee;
    this.state.balance += netProfit;
    trade.profit = (trade.profit || 0) + netProfit; // V110: Accumulate partial profit
    trade.units = (trade.units || 0) - unitsToClose;
    
    this.log(`🏦 PARTIAL EXIT [${reason}]: Scaled out $${netProfit.toFixed(2)}. Total Trade Alpha: $${trade.profit.toFixed(2)}`);
    
    const alertMsg = `
🏦 <b>PARTIAL PROFIT CAPTURE (V110)</b>
━━━━━━━━━━━━━━━━━━
💰 <b>NET PNL:</b> <code>+$${netProfit.toFixed(2)}</code>
📊 <b>REASON:</b> <code>${reason}</code>
🛡️ <b>REMAINING:</b> <code>${trade.units?.toFixed(4)} Units</code>
💳 <b>BALANCE:</b> <code>$${this.state.balance.toFixed(2)}</code>
━━━━━━━━━━━━━━━━━━
    `.trim();
    sendTelegramAlert(alertMsg);
  }

  private log(msg: string) {
    console.log(msg);
    this.logCounter++;
    const time = new Date().toLocaleTimeString();
    const entry = {
      id: `log_${Date.now()}_${this.logCounter}_${Math.random().toString(36).substr(2, 5)}`,
      message: msg,
      time
    };
    this.state.logs.unshift(entry);
    if (this.state.logs.length > 50) this.state.logs.pop();

    if (this.state.isBacktesting) return;

    const criticalEvents = [
      'PAPER_TRADE', 
      'TRADE CLOSED', 
      'EXECUTION',
      'SCALP_ORDER', 
      'SIMULATION STACKED', 
      'NEURAL RE-SYNC',
      'SCALPING_MODE',
      'AUDIT:',
      'ALERT:',
      'MEMORY'
    ];
    
    if (criticalEvents.some(keyword => msg.includes(keyword))) {
      const isTradeClose = msg.includes('TRADE CLOSED');
      const isExecution = msg.includes('EXECUTION');
      
      // V140: If it's a trade close, we ALREADY send a detailed Telegram alert in executeTradeExit.
      // We skip it here to avoid redundancy and the "replace" error.
      if (isTradeClose) return;

      const emoji = isExecution ? '🛸' : (msg.includes('ALERT') ? '🛰️' : '🧠');
      const subHeader = isExecution ? 'TRADE_DISPATCHED' : (msg.includes('ALERT') ? 'INSTITUTION_ALERT' : 'SIGNAL_AUDIT');
      
      let formattedMsg = msg;
      if (isExecution) {
          formattedMsg = `<b>SIGNAL_ACTIVE:</b> ${this.state.mode}\n` +
                        `<b>STRATEGY:</b> <code>${this.state.activeStrategy}</code>\n` +
                        `<b>CONFLUENCE:</b> Alpha ${this.state.score.toFixed(1)} / Thres ${isInSilverBullet(Date.now()) ? '22.0' : '30.0'}\n` +
                        `<b>MARKET:</b> ${this.state.environment}`;
      }

      const payload = `
${emoji} <b>[${subHeader}]</b>
━━━━━━━━━━━━━━━━━━
${formattedMsg}
━━━━━━━━━━━━━━━━━━
📡 <b>CORE_STATUS:</b> ${this.state.mode}
🧠 <b>ALPHA:</b> ${((this.state.metrics.profitFactor || 1) * 10).toFixed(1)} SRC
🕒 <i>${time}</i>
      `.trim();
      
      sendTelegramAlert(payload);
    }
  }

  public getState() {
    return this.state;
  }
}

export const brain = new BotBrain();

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Candle, MarketEnvironment, AssetType } from '../types';
import { fetchInstitutionalLevels, fetchLivePrice } from '../services/marketDataService';

export class MarketEngine {
  private candles: Candle[] = [];
  private basePrice = 65000; // Updated default for BTC
  private volatility = 0.008; // Increased from 0.005

  private pdh = 0;
  private pdl = 0;
  private lastLevelSync = 0;

  constructor() {
    this.generateInitialData(100);
    this.syncWithRealTime();
  }

  private async syncInstitutionalLevels(asset: AssetType) {
    const symbol = asset === 'CRYPTO' ? 'BTCUSDT' : 'PAXGUSDT';
    const levels = await fetchInstitutionalLevels(symbol);
    if (levels) {
      this.pdh = levels.pdh;
      this.pdl = levels.pdl;
      this.lastLevelSync = Date.now();
    }
  }

  private async syncWithRealTime() {
    try {
      const price = await fetchLivePrice('BTCUSDT');
      if (price) {
        this.basePrice = price;
        // Regenerate to ground the price if we are just starting
        if (this.candles.length === 0) {
          this.generateInitialData(100);
        }
      }
    } catch (e) {
      // Fail silently, use simulation
    }
  }

  private generateCandle(prevClose: number): Candle {
    let mode: 'NORMAL' | 'SWEEP' | 'STOP_HUNT' | 'REVERSAL' | 'PUMP' | 'DUMP' | 'MANIPULATION' = 'NORMAL';
    const rand = Math.random();
    
    // Pro-Level Manipulation Probability
    if (rand > 0.98) mode = 'STOP_HUNT';
    else if (rand > 0.96) mode = 'SWEEP';
    
    // Tighter volatility for real feeling (0.01% - 0.05% typical 1s noise)
    const noise = prevClose * 0.0001; 
    let change = noise * (Math.random() - 0.5);
    let volume = 100 + Math.random() * 500; 
    
    if (mode === 'STOP_HUNT') {
      change = (Math.random() > 0.5 ? 1 : -1) * (prevClose * 0.0015);
      volume *= 3;
    } else if (mode === 'SWEEP') {
      change *= 2.5;
      volume *= 2;
    }

    const close = prevClose + change;
    const high = Math.max(prevClose, close) + (Math.random() * (noise * 0.5));
    const low = Math.min(prevClose, close) - (Math.random() * (noise * 0.5));
    
    return {
      time: Date.now(),
      open: prevClose,
      high,
      low,
      close,
      volume,
      wickUpper: high - Math.max(prevClose, close),
      wickLower: Math.min(prevClose, close) - low,
      bodySize: Math.abs(close - prevClose)
    };
  }

  private generateInitialData(count: number) {
    let lastClose = this.basePrice;
    for (let i = 0; i < count; i++) {
      const candle = this.generateCandle(lastClose);
      this.candles.push(candle);
      lastClose = candle.close;
    }
  }

  public async tick(asset: AssetType): Promise<Candle> {
    const symbol = asset === 'CRYPTO' ? 'BTCUSDT' : 'PAXGUSDT'; 
    
    // Auto-sync levels every minute or on asset change
    if (Date.now() - this.lastLevelSync > 60000) {
      this.syncInstitutionalLevels(asset);
    }
    
    const lastCandle = this.candles[this.candles.length - 1];
    let livePrice = lastCandle.close;

    try {
      const price = await fetchLivePrice(symbol);
      if (price) {
        livePrice = price;
      }
    } catch (e) {
      // Fallback to simulation if network flakes, but we prioritize real data
      livePrice = livePrice + (livePrice * 0.0005 * (Math.random() - 0.5));
    }

    const newCandle = this.generateCandle(lastCandle.close);
    
    // Ground the close price to the live exchange price
    newCandle.close = livePrice;
    if (newCandle.high < livePrice) newCandle.high = livePrice + (Math.random() * 5);
    if (newCandle.low > livePrice) newCandle.low = livePrice - (Math.random() * 5);

    this.candles.push(newCandle);
    if (this.candles.length > 500) this.candles.shift();
    return newCandle;
  }

  public getCandles(): Candle[] {
    return this.candles;
  }

  public getHTFCandles(): Candle[] {
    // Return every 15th candle as a simple HTF approximation
    return this.candles.filter((_, i) => i % 15 === 0);
  }

  public getAverageVolume(period: number = 20): number {
    const recent = this.candles.slice(-period);
    if (recent.length === 0) return 0;
    return recent.reduce((sum, c) => sum + c.volume, 0) / recent.length;
  }

  public getVolatility(period: number = 14): number {
    const recent = this.candles.slice(-period - 1);
    if (recent.length < 2) return 0;
    
    let sumTr = 0;
    for (let i = 1; i < recent.length; i++) {
        const h = recent[i].high;
        const l = recent[i].low;
        const pc = recent[i-1].close;
        const tr = Math.max(h - l, Math.abs(h - pc), Math.abs(l - pc));
        sumTr += tr;
    }
    return sumTr / period;
  }

  public detectEnvironment(): MarketEnvironment {
    const recent = this.candles.slice(-20);
    const high = Math.max(...recent.map(c => c.high));
    const low = Math.min(...recent.map(c => c.low));
    const range = high - low;
    const move = Math.abs(recent[0].close - recent[recent.length - 1].close);

    if (move / range > 0.6) return 'TRENDING';
    if (range / recent[0].close > 0.01) return 'VOLATILE';
    return 'RANGING';
  }

  public getInstitutionalLevels() {
    if (this.pdh === 0 || this.pdl === 0) return null;
    
    return {
      pdh: this.pdh,
      pdl: this.pdl,
      mid: (this.pdh + this.pdl) / 2,
      highLiquidity: this.pdh + (this.pdh * 0.0005),
      lowLiquidity: this.pdl - (this.pdl * 0.0005)
    };
  }
}

export const market = new MarketEngine();

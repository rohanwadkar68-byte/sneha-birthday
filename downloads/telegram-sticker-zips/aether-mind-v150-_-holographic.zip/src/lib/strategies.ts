/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Candle, MarketEnvironment, StrategyType } from '../types';

export const detectLiquiditySweep = (candles: Candle[]): { detected: boolean; type: 'BULLISH' | 'BEARISH' | null; level: number } => {
  if (candles.length < 40) return { detected: false, type: null, level: 0 };
  const last = candles[candles.length - 1];
  
  // Human-like analysis: Look back for significant swing points (Major Pockets)
  const lookback = candles.slice(-80, -1);
  const findSwings = (data: Candle[], type: 'high' | 'low') => {
    return data.filter((c, i, arr) => {
      if (i < 5 || i > arr.length - 6) return false;
      const range = arr.slice(i-5, i+6);
      if (type === 'high') return c.high === Math.max(...range.map(x => x.high));
      return c.low === Math.min(...range.map(x => x.low));
    });
  };

  const majorHighs = findSwings(lookback, 'high').map(c => c.high);
  const majorLows = findSwings(lookback, 'low').map(c => c.low);
  
  const maxSwing = majorHighs.length > 0 ? Math.max(...majorHighs) : 0;
  const minSwing = majorLows.length > 0 ? Math.min(...majorLows) : 999999;

  // ICT Liquidity Sweep Requirement: Breach + Rejection + Impulse (V45)
  const isBearishSweep = last.high > maxSwing && last.close < maxSwing && last.wickUpper > last.bodySize * 1.5;
  const isBullishSweep = last.low < minSwing && last.close > minSwing && last.wickLower > last.bodySize * 1.5;

  // V46: Human Brain Guard - Volume Spread Analysis (VSA)
  const avgVol = candles.slice(-20).reduce((acc, c) => acc + c.volume, 0) / 20;

  // Rejection Strength requirement
  const avgWick = candles.slice(-30).reduce((acc, c) => acc + (c.wickUpper + c.wickLower), 0) / 30;

  // V160: High-Value Intensity - Targeting density with room to breathe
  const volumeSpike = last.volume > avgVol * 1.05; 
  const effortResultRatio = last.volume / (last.bodySize + 0.001);
  const avgWickSnapshot = candles.slice(-20).reduce((acc, c) => acc + (c.wickUpper + c.wickLower), 0) / 20;

  // Absorption logic - capture institutional stalling
  const isAbsorption = volumeSpike && last.bodySize < avgWickSnapshot * 1.5 && effortResultRatio > (avgVol / (avgWickSnapshot || 1)) * 1.8;
  
  // Power Inflection detection
  const isPowerMove = volumeSpike && last.bodySize > avgWickSnapshot * 1.1;

  // V160: Institutional Footprint Detection
  const isInstitutionalBuying = isBullishSweep || (isAbsorption && last.close > last.open) || (isPowerMove && last.close > last.open);
  const isInstitutionalSelling = isBearishSweep || (isAbsorption && last.close < last.open) || (isPowerMove && last.close < last.open);

  // V160: Human conviction nodes
  let humanAlpha = 0;
  if (isInstitutionalBuying) humanAlpha += 55;
  if (isInstitutionalSelling) humanAlpha += 55;
  if (volumeSpike) humanAlpha += 25;
  if (isAbsorption) humanAlpha += 30;
  
  // Dynamic Rejection Proof
  const rejectionStrength = isBearishSweep ? last.wickUpper : (isBullishSweep ? last.wickLower : 0);
  const proofRequirement = avgWickSnapshot * 1.1; 

  if (isInstitutionalSelling && humanAlpha >= 65 && (rejectionStrength > proofRequirement || isAbsorption)) return { detected: true, type: 'BEARISH', level: maxSwing };
  if (isInstitutionalBuying && humanAlpha >= 65 && (rejectionStrength > proofRequirement || isAbsorption)) return { detected: true, type: 'BULLISH', level: minSwing };

  return { detected: false, type: null, level: 0 };
};

export const detectOrderBlock = (candles: Candle[]): boolean => {
  if (candles.length < 12) return false;
  const last = candles[candles.length - 1];
  const obCandle = candles[candles.length - 2];
  
  // Institutional OB: The candle before a massive displacement move
  const avgBody = candles.slice(-20).reduce((acc, c) => acc + c.bodySize, 0) / 20;
  const isDisplacementMove = last.bodySize > avgBody * 3.0;
  
  const isEngulfing = (obCandle.close > obCandle.open && last.close < obCandle.open) || 
                      (obCandle.close < obCandle.open && last.close > obCandle.open);
  
  const highVolume = last.volume > calculateEMA(candles.slice(-20), 10) * 1.8;

  return isDisplacementMove && isEngulfing && highVolume;
};

export const detectFVG = (candles: Candle[]): { detected: boolean; type: 'BULLISH' | 'BEARISH' | null } => {
  if (candles.length < 3) return { detected: false, type: null };
  const c1 = candles[candles.length - 3];
  const c2 = candles[candles.length - 2];
  const c3 = candles[candles.length - 1];
  
  // Bullish FVG: C1 High < C3 Low
  const bullFVG = c1.high < c3.low;
  // Bearish FVG: C1 Low > C3 High
  const bearFVG = c1.low > c3.high;
  
  // Must have displacement (large middle candle)
  const avgBody = calculateEMA(candles.slice(-20), 14);
  const isImpulsive = c2.bodySize > avgBody * 1.5;

  if (bullFVG && isImpulsive) return { detected: true, type: 'BULLISH' };
  if (bearFVG && isImpulsive) return { detected: true, type: 'BEARISH' };

  return { detected: false, type: null };
};

export const detectBreakerBlock = (candles: Candle[]): boolean => {
  if (candles.length < 15) return false;
  const last = candles[candles.length - 1];
  const recent = candles.slice(-15, -1);
  
  // A Breaker is a failed OB that was subsequently broken
  const oldOBIdx = recent.findIndex(c => c.volume > (calculateEMA(candles.slice(-30), 1) * 2.5));
  if (oldOBIdx === -1) return false;
  
  const oldOB = recent[oldOBIdx];
  const wasBroken = (oldOB.high < last.close) || (oldOB.low > last.close);
  const isRevisiting = Math.abs(last.close - oldOB.close) < (last.close * 0.001);
  
  return wasBroken && isRevisiting;
};

// V26: Macro News Environment Detector (Simulated)
export const detectMacroImpact = (): boolean => {
  const now = new Date();
  const mins = now.getMinutes();
  
  // Simulated news events often happen at the start/middle of the hour
  // Pro traders avoid the 5 mins before and 10 mins after major news (e.g. 15:30)
  const isNewsTime = (mins >= 25 && mins <= 40) || (mins >= 55 || mins <= 5);
  
  // Also high volatility on first Friday (NFP) or mid-week (FOMC) - for simulation we use specific hours
  const hour = now.getUTCHours();
  const isHighImpactHour = [13, 14, 15, 19, 20].includes(hour); // NY Sessions open/close spikes
  
  return isNewsTime && isHighImpactHour;
};
export const detectVolumeCluster = (candles: Candle[]): { level: number; strength: number } => {
  if (candles.length < 50) return { level: 0, strength: 0 };
  const prices = candles.map(c => Math.round(c.close * 10) / 10);
  const volMap: Record<number, number> = {};
  
  candles.forEach(c => {
    const p = Math.round(c.close * 10) / 10;
    volMap[p] = (volMap[p] || 0) + c.volume;
  });

  let maxVol = 0;
  let poc = 0;
  Object.entries(volMap).forEach(([p, v]) => {
    if (v > maxVol) {
      maxVol = v;
      poc = parseFloat(p);
    }
  });

  const avgVol = candles.slice(-20).reduce((acc, c) => acc + c.volume, 0) / 20;
  return { level: poc, strength: maxVol / (avgVol || 1) };
};

export const calculateAdaptiveSL = (candles: Candle[], multiplier: number = 2.5): number => {
  const atr = calculateATR(candles, 14);
  const recentRange = candles.slice(-20).map(c => c.high - c.low).reduce((a, b) => a + b, 0) / 20;
  
  // Use the larger of ATR or recent mean range to avoid getting stopped out by noise
  return Math.max(atr, recentRange) * multiplier;
};

// V27: SMT Divergence (Smart Money Tool)
export const detectSMTDivergence = (assetCandles: Candle[], peerCandles: Candle[]): 'BULLISH' | 'BEARISH' | 'NONE' => {
  if (assetCandles.length < 5 || peerCandles.length < 5) return 'NONE';
  const lastA = assetCandles[assetCandles.length - 1];
  const lastP = peerCandles[peerCandles.length - 1];
  const prevA = assetCandles[assetCandles.length - 2];
  const prevP = peerCandles[peerCandles.length - 2];

  if (lastA.low < prevA.low && lastP.low > prevP.low) return 'BULLISH';
  if (lastA.high > prevA.high && lastP.high < prevP.high) return 'BEARISH';
  return 'NONE';
};

// V28: Institutional Session Levels (Liquidity Magnets)
export const getSessionLevels = (candles: Candle[]) => {
    const today = new Date().toISOString().split('T')[0];
    const dailyCandles = candles.filter(c => new Date(c.time).toISOString().split('T')[0] === today);
    const dailyOpen = dailyCandles.length > 0 ? dailyCandles[0].open : candles[candles.length - 1].open;
    
    // Find Weekly Open (Monday 00:00)
    const now = new Date();
    const monday = new Date(now.setDate(now.getDate() - (now.getDay() || 7) + 1)).toISOString().split('T')[0];
    const weeklyCandles = candles.filter(c => new Date(c.time).toISOString().split('T')[0] >= monday);
    const weeklyOpen = weeklyCandles.length > 0 ? weeklyCandles[0].open : dailyOpen;

    return { dailyOpen, weeklyOpen };
};

// V29: Retail Inducement Detector (Wait for the "Trap" before entering)
export const detectInducement = (candles: Candle[]): boolean => {
  if (candles.length < 15) return false;
  const recent = candles.slice(-15, -1);
  const current = candles[candles.length - 1];
  
  const localHigh = Math.max(...recent.map(r => r.high));
  const localLow = Math.min(...recent.map(r => r.low));

  // If we swept a minor local level but didn't close beyond it, it's a trap/inducement
  const sweptHigh = current.high > localHigh && current.close < localHigh;
  const sweptLow = current.low < localLow && current.close > localLow;
  
  return sweptHigh || sweptLow;
};

// V30: Neural Strategy Weighting (Learning Adjustment)
export const getNeuralWeighting = (performance: Record<string, { wins: number, losses: number }>, strategy: string): number => {
  const stats = performance[strategy];
  if (!stats || (stats.wins + stats.losses) < 5) return 1.0; // Baseline
  
  const winRate = stats.wins / (stats.wins + stats.losses);
  
  // If win rate > 60%, lower entry threshold (become more aggressive)
  // If win rate < 40%, raise entry threshold (become more defensive)
  if (winRate > 0.65) return 1.25; // Bonus confidence
  if (winRate < 0.45) return 0.75; // Penalty
  return 1.0;
};

// V31: Market Narrative Logic (The "Story" of the trade)
export const analyzeNarrative = (candles: Candle[], htfBias: StrategyType): { 
  phase: string, 
  bias: 'BULLISH' | 'BEARISH' | 'NEUTRAL',
  quality: number,
  logs: string[]
} => {
  if (candles.length < 50) return { phase: 'UNKNOWN', bias: 'NEUTRAL', quality: 0, logs: [] };
  
  const logs: string[] = [];
  const last = candles[candles.length - 1];
  const ranges = getSessionLevels(candles);
  const killzone = isInKillzone(Date.now());
  
  // Power of 3 (AMD) Detection
  const isBelowOpen = last.close < ranges.dailyOpen;
  const isAboveOpen = last.close > ranges.dailyOpen;
  
  let bias: 'BULLISH' | 'BEARISH' | 'NEUTRAL' = 'NEUTRAL';
  let quality = 0;
  
  // NARRATIVE 1: Institutional Intent & Dealing Range
  const range = getDealingRangeInfo(candles);
  const isInDiscount = range.isDiscount(last.close);
  const isInPremium = range.isPremium(last.close);

  if (htfBias === 'BULLISH' && isInDiscount) {
    bias = 'BULLISH';
    quality += 45;
    logs.push("🏰 [NARRATIVE] Price in HTF DISCOUNT. Institutional Buy Program active.");
  } else if (htfBias === 'BEARISH' && isInPremium) {
    bias = 'BEARISH';
    quality += 45;
    logs.push("🏰 [NARRATIVE] Price in HTF PREMIUM. Institutional Sell Program active.");
  }
  
  if (killzone) {
    quality += 15;
    logs.push("🕒 [NARRATIVE] Inside Session Killzone. Volatility injection expected.");
  }
  
  // NARRATIVE 2: Liquidity Hunt
  const sweep = detectLiquiditySweep(candles);
  if (sweep.detected) {
    quality += 30;
    logs.push(`🌊 [NARRATIVE] ${sweep.type} Liquidity Purged. Retail stops captured.`);
  }
  
  // NARRATIVE 3: Structure Context
  const phase = detectMarketPhase(candles);
  if ((phase === 'TRENDING' && htfBias === 'BULLISH') || (phase === 'TRENDING' && htfBias === 'BEARISH')) {
    quality += 20;
    logs.push("📊 [NARRATIVE] Market Structure aligned with HTF Order Flow.");
  }

  return { phase, bias, quality, logs };
};

// Market Regime Types (V60 Neural Evolution)
export type MarketRegime = 'INSTITUTIONAL_TREND' | 'LIQUIDITY_EXPANSION' | 'MEAN_REVERSION' | 'VOLATILITY_CRUSH';

export function detectMarketRegime(candles: Candle[]): MarketRegime {
  if (candles.length < 50) return 'MEAN_REVERSION';
  
  const last50 = candles.slice(-50);
  const closes = last50.map(c => c.close);
  const returns = last50.slice(1).map((c, i) => Math.abs(c.close - last50[i].close));
  const avgVolatility = returns.reduce((a, b) => a + b, 0) / returns.length;
  
  const currentVol = returns.slice(-5).reduce((a, b) => a + b, 0) / 5;
  
  const netMove = Math.abs(closes[closes.length - 1] - closes[0]);
  const totalMove = returns.reduce((a, b) => a + b, 0);
  const efficiency = netMove / totalMove;

  if (efficiency > 0.35 && currentVol > avgVolatility) return 'INSTITUTIONAL_TREND';
  if (currentVol > avgVolatility * 1.8) return 'LIQUIDITY_EXPANSION';
  if (efficiency < 0.12) return 'MEAN_REVERSION';
  return 'VOLATILITY_CRUSH';
}

// V70: Nexus Market Potential Index (MPI) - Measuring "Opportunity Density"
export function calculateMPI(candles: Candle[]): number {
  if (candles.length < 50) return 0.5;
  const last50 = candles.slice(-50);
  const atr = calculateATR(candles, 14);
  const avgBody = last50.reduce((a, b) => a + b.bodySize, 0) / 50;
  
  // MPI = Volatility / Friction
  const volScalar = atr / (candles[candles.length-1].close * 0.001); // Relative ATR
  const bodyScalar = avgBody / atr;
  
  return (volScalar * 0.7 + bodyScalar * 0.3);
}

// V150 Aether Mind: Quantum Volume Displacement (QVD)
// Measures the 'Mass' of price movement. Real institutional displacement requires high Mass/Time.
export function detectVolumeDisplacement(candles: Candle[]): { mass: number; isInstitutional: boolean } {
  if (candles.length < 10) return { mass: 0, isInstitutional: false };
  const last = candles[candles.length - 1];
  const avgVol = candles.slice(-20).reduce((a, b) => a + b.volume, 0) / 20;
  
  // Mass = (BodySize * Volume) / (WickNoise + 1)
  const mass = (last.bodySize * (last.volume / avgVol)) / (last.wickUpper + last.wickLower + 0.001);
  return {
    mass,
    isInstitutional: mass > 2.5 // Threshold for 'Heavy' candles
  };
}

// V150 Aether Mind: Neural Reflex Sync (The "Human Trigger")
// Only returns true if the market has 'Breathed' (Retraced) enough to trap retail.
export function detectReflexBreath(candles: Candle[], bias: 'BULLISH' | 'BEARISH'): boolean {
  if (candles.length < 5) return false;
  const last3 = candles.slice(-3);
  
  if (bias === 'BULLISH') {
    // Bullish entry needs a micro-dip (breath) before expansion
    return last3[0].close < last3[0].open && last3[2].close > last3[1].high;
  } else {
    // Bearish entry needs a micro-pump before collapse
    return last3[0].close > last3[0].open && last3[2].close < last3[1].low;
  }
}

// V155 Aether Mind: Institutional Entropy & Micro-Trend Stability
// High entropy (> 2.5) implies retail gambling or indecision.
export function detectInstitutionalEntropy(candles: Candle[]): { entropy: number; isStable: boolean } {
  if (candles.length < 30) return { entropy: 0.5, isStable: true };
  const last30 = candles.slice(-30);
  
  const signal = last30.reduce((a, b) => a + b.bodySize, 0);
  const noise = last30.reduce((a, b) => a + (b.wickUpper + b.wickLower), 0);
  
  const entropy = noise / Math.max(0.001, signal);
  // V155: Tighter stability requirement for "Human" precision
  return { 
    entropy, 
    isStable: entropy < 2.2 
  };
}

// V140 Singularity Matrix: Fractal Alignment Sync
// Detects if the current move is corroborated by its own fractal history (self-similarity)
export function detectFractalSync(candles: Candle[]): { synced: boolean; alignment: number } {
  if (candles.length < 60) return { synced: false, alignment: 0 };
  const micro = candles.slice(-5);
  const macro = candles.slice(-40);
  
  const microBias = micro[micro.length-1].close > micro[0].open ? 1 : -1;
  const macroBias = macro[macro.length-1].close > macro[0].open ? 1 : -1;
  
  // Alignment score (0 to 1)
  const alignment = microBias === macroBias ? 1.0 : 0.0;
  
  return { 
    synced: alignment === 1.0, 
    alignment 
  };
}

// V130 Omniscience: Retail Bait / Liquidity Trap Detector
export function detectLiquidityTrap(candles: Candle[]): { detected: boolean; type: 'BULLISH' | 'BEARISH' | 'NONE' } {
  if (candles.length < 20) return { detected: false, type: 'NONE' };
  const last = candles[candles.length - 1];
  const lookback = candles.slice(-20, -1);
  
  // Detect "Double Top" or "Double Bottom" within 0.05% proximity
  const maxHigh = Math.max(...lookback.map(c => c.high));
  const minLow = Math.min(...lookback.map(c => c.low));
  
  const isDoubleTop = Math.abs(last.high - maxHigh) / (maxHigh || 1) < 0.0005;
  const isDoubleBottom = Math.abs(last.low - minLow) / (minLow || 1) < 0.0005;
  
  if (isDoubleTop) return { detected: true, type: 'BEARISH' }; // Impending sweep of the highs
  if (isDoubleBottom) return { detected: true, type: 'BULLISH' }; // Impending sweep of the lows
  
  return { detected: false, type: 'NONE' };
}

// V120 Prometheus: Molecular Expansion Detector (The "Coiled Spring")
export function detectExpansionImpulse(candles: Candle[]): { detected: boolean; potential: number } {
  if (candles.length < 30) return { detected: false, potential: 1 };
  const recent = candles.slice(-10);
  const previous = candles.slice(-30, -10);
  
  const recentVol = recent.reduce((a, b) => a + b.bodySize, 0) / 10;
  const prevVol = previous.reduce((a, b) => a + b.bodySize, 0) / 20;
  
  const compressionRatio = prevVol / Math.max(0.0001, recentVol);
  // V120: Tighter compression threshold for higher accuracy in pinpointing institutional entries
  const isCompressed = compressionRatio > 2.4;
  
  return { 
    detected: isCompressed, 
    potential: Math.min(4.0, compressionRatio) 
  };
}

// V120 Prometheus: Order Flow Imbalance (OFI)
// Detects institutional "Footprints" by measuring displacement acceleration across sequences
export function detectOrderFlowImbalance(candles: Candle[]): { strength: number; bias: 'BULLISH' | 'BEARISH' | 'NEUTRAL' } {
  if (candles.length < 5) return { strength: 0, bias: 'NEUTRAL' };
  const last3 = candles.slice(-3);
  
  const isBullish = last3.every(c => c.close > c.open);
  const isBearish = last3.every(c => c.close < c.open);
  
  if (!isBullish && !isBearish) return { strength: 0, bias: 'NEUTRAL' };
  
  // Measure body size acceleration relative to volume
  const acc = last3[2].bodySize / Math.max(0.001, last3[0].bodySize);
  const volAcc = last3[2].volume / Math.max(0.001, last3[0].volume);
  
  return {
    strength: (acc + volAcc) / 2,
    bias: isBullish ? 'BULLISH' : 'BEARISH'
  };
}

// V162: Strategy Number 1 - SMC + OTE Professional Logic
export const detectSMCOTE = (
  candles: Candle[],
  htfCandles: Candle[],
  bias: 'BULLISH' | 'BEARISH'
): { detected: boolean; reason: string; entryLevel: number; sl: number; tp: number[] } => {
  if (candles.length < 50 || htfCandles.length < 20) {
    return { detected: false, reason: 'Insufficient data', entryLevel: 0, sl: 0, tp: [] };
  }

  const last = candles[candles.length - 1];
  
  // 1. HTF Trend Identification (H1)
  const htfTrend = getHTFBias(htfCandles);
  if (htfTrend === 'NEUTRAL' || (bias === 'BULLISH' && htfTrend !== 'BULLISH') || (bias === 'BEARISH' && htfTrend !== 'BEARISH')) {
    return { detected: false, reason: 'HTF Trend Mismatch', entryLevel: 0, sl: 0, tp: [] };
  }

  // 2. Identify Major Swing (Dealing Range)
  const range = getDealingRangeInfo(candles);
  const swingLow = range.low;
  const swingHigh = range.high;
  const rangeSize = swingHigh - swingLow;

  // 3. Fibonacci OTE Zone (0.62 - 0.79)
  const fib62 = bias === 'BULLISH' ? swingHigh - (rangeSize * 0.62) : swingLow + (rangeSize * 0.62);
  const fib79 = bias === 'BULLISH' ? swingHigh - (rangeSize * 0.79) : swingLow + (rangeSize * 0.79);
  
  const inOTEZone = bias === 'BULLISH' 
    ? (last.close <= fib62 && last.close >= fib79)
    : (last.close >= fib62 && last.close <= fib79);

  if (!inOTEZone) {
    return { detected: false, reason: 'Outside OTE Zone', entryLevel: 0, sl: 0, tp: [] };
  }

  // 4. Order Block (OB) Identification
  const obDetected = detectOrderBlock(candles);
  if (!obDetected) {
    return { detected: false, reason: 'No Order Block confirmed', entryLevel: 0, sl: 0, tp: [] };
  }

  // 5. Confirmation: BOS / CHoCH
  const choch = detectChoCh(candles);
  if (choch !== bias) {
    return { detected: false, reason: 'No Structure Confirmation (CHoCH)', entryLevel: 0, sl: 0, tp: [] };
  }

  // 6. Stop Loss & Take Profit
  const sl = bias === 'BULLISH' ? swingLow - (calculateATR(candles, 14) * 0.15) : swingHigh + (calculateATR(candles, 14) * 0.15); // Tighter SL for OTE
  const tp1 = bias === 'BULLISH' ? swingHigh : swingLow;
  const tp2 = bias === 'BULLISH' ? swingHigh + (rangeSize * 0.382) : swingLow - (rangeSize * 0.382); // Increased Extension
  const tp3 = bias === 'BULLISH' ? swingHigh + (rangeSize * 0.786) : swingLow - (rangeSize * 0.786); // Targeting deeper liquidity

  return {
    detected: true,
    reason: `SMC+OTE Alignment: ${bias} trend + OB + OTE + CHoCH`,
    entryLevel: last.close,
    sl,
    tp: [tp1, tp2, tp3]
  };
};

// V163: Strategy Number 2 - Liquidity Grab Reversal (Swing)
export const detectSMCSwing = (
  candles: Candle[],
  bias: 'BULLISH' | 'BEARISH'
): { detected: boolean; reason: string; entryLevel: number; sl: number; tp: number[] } => {
  if (candles.length < 50) return { detected: false, reason: 'Insufficient data', entryLevel: 0, sl: 0, tp: [] };

  const last = candles[candles.length - 1];
  const lookback = candles.slice(-80, -1);
  
  // 1. & 2. Liquidity Identification & Grab Detection
  const sweep = detectLiquiditySweep(candles);
  if (!sweep.detected || sweep.type !== bias) {
    return { detected: false, reason: 'No Liquidity Grab detected', entryLevel: 0, sl: 0, tp: [] };
  }

  // 3. CHoCH (Confirmation of reversal)
  const choch = detectChoCh(candles);
  if (choch !== bias) {
    return { detected: false, reason: 'Waiting for CHoCH confirmation', entryLevel: 0, sl: 0, tp: [] };
  }

  // 4. Entry Zone (Refined OB/FVG check)
  const ob = detectOrderBlock(candles);
  const fvg = detectFVG(candles);
  if (!ob && !fvg.detected) {
    return { detected: false, reason: 'No refined entry zone (OB/FVG) after CHoCH', entryLevel: 0, sl: 0, tp: [] };
  }

  // 5. Stop Loss (Extreme of the grab - Tighter)
  const sl = sweep.type === 'BULLISH' ? last.low - (calculateATR(candles, 14) * 0.08) : last.high + (calculateATR(candles, 14) * 0.08);

  // 6. Take Profit (Swing targets)
  const range = getDealingRangeInfo(candles);
  const tp1 = sweep.type === 'BULLISH' ? range.high : range.low;
  const tp2 = sweep.type === 'BULLISH' ? range.high + (Math.abs(range.high - range.low) * 1.0) : range.low - (Math.abs(range.high - range.low) * 1.0); // Full Measured Move (2.0R+)
  
  return {
    detected: true,
    reason: `🎯 [STRATEGY_2] Liquidity Grab (${sweep.type}) + CHoCH + Entry Zone secured.`,
    entryLevel: last.close,
    sl,
    tp: [tp1, tp2]
  };
};

// V164: Strategy Number 3 - Breakout-Retest (Professional Continuation/Reversal)
export const detectBreakoutRetest = (
  candles: Candle[],
  bias: 'BULLISH' | 'BEARISH'
): { detected: boolean; reason: string; entryLevel: number; sl: number; tp: number[] } => {
  if (candles.length < 60) return { detected: false, reason: 'Insufficient data', entryLevel: 0, sl: 0, tp: [] };

  const last = candles[candles.length - 1];
  const prev = candles[candles.length - 2];
  
  // 1. Key Level Identification (SR)
  const lookback = candles.slice(-100, -5); // Look for historical levels
  const findSwings = (data: Candle[], type: 'high' | 'low') => {
    return data.filter((c, i, arr) => {
      if (i < 5 || i > arr.length - 6) return false;
      const range = arr.slice(i-5, i+6);
      if (type === 'high') return c.high === Math.max(...range.map(x => x.high));
      return c.low === Math.min(...range.map(x => x.low));
    });
  };

  const majorHighs = findSwings(lookback, 'high').map(c => c.high);
  const majorLows = findSwings(lookback, 'low').map(c => c.low);
  
  if (majorHighs.length === 0 || majorLows.length === 0) {
    return { detected: false, reason: 'No clear SR levels found', entryLevel: 0, sl: 0, tp: [] };
  }

  // 2. Breakout Detection (Look back for a recent breakout in the last 15 candles)
  const recentHistorical = candles.slice(-20, -1);
  let breakoutLevel = 0;
  let breakoutFound = false;

  if (bias === 'BULLISH') {
    const resistance = Math.max(...majorHighs);
    // Find the first candle in recent history that closed ABOVE the major resistance
    for (let i = 0; i < recentHistorical.length; i++) {
        if (recentHistorical[i].close > resistance && recentHistorical[i].bodySize > calculateATR(candles, 14)) {
            breakoutFound = true;
            breakoutLevel = resistance;
            break;
        }
    }
  } else {
    const support = Math.min(...majorLows);
    for (let i = 0; i < recentHistorical.length; i++) {
        if (recentHistorical[i].close < support && recentHistorical[i].bodySize > calculateATR(candles, 14)) {
            breakoutFound = true;
            breakoutLevel = support;
            break;
        }
    }
  }

  if (!breakoutFound) return { detected: false, reason: 'No recent breakout detected', entryLevel: 0, sl: 0, tp: [] };

  // 3. & 4. Retest & Confirmation
  // Price must be touching/near the breakout level + confirmation candle
  const distFromLevel = Math.abs(last.close - breakoutLevel) / breakoutLevel;
  const inRetestZone = distFromLevel < 0.0015; // Within 0.15%

  const rej = detectWickRejection(candles);
  const engulf = detectCandlestickPattern(candles);
  const isConfirmed = rej.detected || engulf.type === 'ENGULFING';

  if (!inRetestZone || !isConfirmed) {
     return { detected: false, reason: 'Waiting for Retest/Confirmation at level', entryLevel: 0, sl: 0, tp: [] };
  }

  // 6. Stop Loss
  const atr = calculateATR(candles, 14);
  const sl = bias === 'BULLISH' ? breakoutLevel - (atr * 1.2) : breakoutLevel + (atr * 1.2); // Tighter SL for breakout
  
  // 7. Take Profit
  const range = getDealingRangeInfo(candles);
  const tp1 = bias === 'BULLISH' ? range.high : range.low;
  const tp2 = bias === 'BULLISH' ? last.close + (Math.abs(last.close - sl) * 3.5) : last.close - (Math.abs(last.close - sl) * 3.5); // Targeting 1:3.5+ RR

  return {
    detected: true,
    reason: `🎯 [STRATEGY_3] Breakout-Retest ${bias} confirmed at ${breakoutLevel.toFixed(1)}`,
    entryLevel: last.close,
    sl,
    tp: [tp1, tp2]
  };
};

// V167: Strategy Number 5 - EMA + RSI Confluence (Professional Trend Following)
export const detectEMARsiConfluence = (
  candles: Candle[],
  bias: 'BULLISH' | 'BEARISH'
): { detected: boolean; reason: string; entryLevel: number; sl: number; tp: number[] } => {
  if (candles.length < 200) return { detected: false, reason: 'Insufficient data for 200 EMA', entryLevel: 0, sl: 0, tp: [] };

  const last = candles[candles.length - 1];
  
  // 1. EMA Trend Filter
  const ema50 = calculateEMA(candles, 50);
  const ema200 = calculateEMA(candles, 200);
  const isEMAAligned = bias === 'BULLISH' 
    ? (last.close > ema50 && ema50 > ema200) 
    : (last.close < ema50 && ema50 < ema200);

  if (!isEMAAligned) return { detected: false, reason: 'EMA Trend mismatch', entryLevel: 0, sl: 0, tp: [] };

  // 2. RSI Confirmation
  const rsi = calculateRSI(candles, 14);
  const isRSIMom = bias === 'BULLISH' ? rsi > 50 : rsi < 50;
  if (!isRSIMom) return { detected: false, reason: 'RSI Momentum mismatch', entryLevel: 0, sl: 0, tp: [] };

  // 3. Support/Resistance Rejection
  const range = getDealingRangeInfo(candles);
  const srLevel = bias === 'BULLISH' ? range.low : range.high; 
  const retest = Math.abs(last.close - srLevel) / srLevel < 0.002; // Near recent extreme

  const rej = detectWickRejection(candles);
  const engulf = detectCandlestickPattern(candles);
  const confirmed = rej.detected || engulf.type === 'ENGULFING';

  if (!confirmed) return { detected: false, reason: 'Waiting for SR Rejection confirmation', entryLevel: 0, sl: 0, tp: [] };

  const atr = calculateATR(candles, 14);
  const sl = bias === 'BULLISH' ? last.low - (atr * 1.25) : last.high + (atr * 1.25); // Tighter SL
  const tp1 = bias === 'BULLISH' ? range.high : range.low;
  const tp2 = bias === 'BULLISH' ? last.close + (Math.abs(last.close - sl) * 3.0) : last.close - (Math.abs(last.close - sl) * 3.0); // 1:3.0 RR target

  return {
    detected: true,
    reason: `🎯 [STRATEGY_5] EMA+RSI Confluence ${bias} at SR level`,
    entryLevel: last.close,
    sl,
    tp: [tp1, tp2]
  };
};

// V168: Strategy Number 6 - Trendline Break + Retest (Scalping Precision)
export const detectTrendlineBreak = (
  candles: Candle[],
  bias: 'BULLISH' | 'BEARISH'
): { detected: boolean; reason: string; entryLevel: number; sl: number; tp: number[] } => {
  if (candles.length < 50) return { detected: false, reason: 'Insufficient data', entryLevel: 0, sl: 0, tp: [] };
  
  const last = candles[candles.length - 1];
  const lookback = candles.slice(-40);
  
  // Simplified Trendline Detection (Searching for 3 touches)
  const findTouches = (data: Candle[], side: 'high' | 'low') => {
     const points = [];
     for(let i=2; i<data.length-2; i++) {
        if(side === 'high' && data[i].high >= data[i-1].high && data[i].high >= data[i-2].high && data[i].high >= data[i+1].high && data[i].high >= data[i+2].high) {
            points.push({ price: data[i].high, index: i });
        } else if (side === 'low' && data[i].low <= data[i-1].low && data[i].low <= data[i-2].low && data[i].low <= data[i+1].low && data[i].low <= data[i+2].low) {
            points.push({ price: data[i].low, index: i });
        }
     }
     return points;
  };

  const trendSide = bias === 'BULLISH' ? 'high' : 'low'; // Bullish bias looks to break a DOWNTREND line (highs)
  const touches = findTouches(lookback, trendSide);
  
  if (touches.length < 2) return { detected: false, reason: 'No clear trendline detected', entryLevel: 0, sl: 0, tp: [] };

  // Check for break in the last 10 candles
  const recent = candles.slice(-10);
  const breakCandleIdx = recent.findIndex(c => bias === 'BULLISH' ? c.close > touches[touches.length-1].price : c.close < touches[touches.length-1].price);
  
  if (breakCandleIdx === -1) return { detected: false, reason: 'No trendline break found', entryLevel: 0, sl: 0, tp: [] };

  // Confirmation on recent candles (Retest)
  const rej = detectWickRejection(candles);
  const confirmed = rej.detected || detectCandlestickPattern(candles).type === 'ENGULFING';

  if (!confirmed) return { detected: false, reason: 'Trendline break detected, waiting for retest/confirmation', entryLevel: 0, sl: 0, tp: [] };

  const atr = calculateATR(candles, 14);
  const sl = bias === 'BULLISH' ? last.low - (atr * 0.8) : last.high + (atr * 0.8);
  const tp1 = bias === 'BULLISH' ? last.close + (Math.abs(last.close - sl) * 2) : last.close - (Math.abs(last.close - sl) * 2);

  return {
    detected: true,
    reason: `⚡ [STRATEGY_6] Trendline Break ${bias} + Confirmation triggered`,
    entryLevel: last.close,
    sl,
    tp: [tp1]
  };
};

// V169: Strategy Number 7 - S/R Rejection + Engulfing (Reversal)
export const detectSREngulfing = (
  candles: Candle[],
  bias: 'BULLISH' | 'BEARISH'
): { detected: boolean; reason: string; entryLevel: number; sl: number; tp: number[] } => {
  if (candles.length < 40) return { detected: false, reason: 'Insufficient data', entryLevel: 0, sl: 0, tp: [] };
  
  const last = candles[candles.length - 1];
  const range = getDealingRangeInfo(candles);
  
  // 1. Check if at S/R level
  const targetLevel = bias === 'BULLISH' ? range.low : range.high;
  const dist = Math.abs(last.close - targetLevel) / targetLevel;
  if (dist > 0.002) return { detected: false, reason: 'Price not at a key levels', entryLevel: 0, sl: 0, tp: [] };

  // 2. Engulfing pattern at the level
  const pattern = detectCandlestickPattern(candles);
  if (pattern.type !== 'ENGULFING' || pattern.sentiment !== bias) {
    // Also allow Pin Bar (Hammer) as per Strategy 7 details
    if (pattern.type !== 'HAMMER' && pattern.type !== 'SHOOTING_STAR') {
        return { detected: false, reason: 'No Engulfing or Rejection pattern at SR', entryLevel: 0, sl: 0, tp: [] };
    }
    if (bias === 'BULLISH' && pattern.type !== 'HAMMER') return { detected: false, reason: 'Wait for Bullish Pin Bar', entryLevel: 0, sl: 0, tp: [] };
    if (bias === 'BEARISH' && pattern.type !== 'SHOOTING_STAR') return { detected: false, reason: 'Wait for Bearish Pin Bar', entryLevel: 0, sl: 0, tp: [] };
  }

  const atr = calculateATR(candles, 14);
  const sl = bias === 'BULLISH' ? last.low - (atr * 0.4) : last.high + (atr * 0.4); // Very tight SL for SR Rejection
  const tp = bias === 'BULLISH' ? last.close + (Math.abs(last.close - sl) * 4.0) : last.close - (Math.abs(last.close - sl) * 4.0); // Targeting 1:4.0 RR

  return {
    detected: true,
    reason: `🎯 [STRATEGY_7] ${bias} Rejection/Engulfing at Key SR Level`,
    entryLevel: last.close,
    sl,
    tp: [tp]
  };
};

export const calculateSuperhumanScore = (
  candles: Candle[], 
  killzoneTime: number = Date.now(),
  htfBias: StrategyType = 'INSTITUTIONAL',
  isScalping: boolean = false
): { 
  score: number, 
  activeBias: 'BULLISH' | 'BEARISH', 
  logs: string[], 
  regime: MarketRegime, 
  reasoning: string[],
  nexusNodes: { smc: number; momentum: number; context: number },
  conviction: 'NORMAL' | 'HIGH' | 'SOVEREIGN',
  expansion: { detected: boolean; potential: number },
  qvd: { mass: number; isInstitutional: boolean },
  smcStrategy1?: { detected: boolean; tp: number[]; sl: number; reason: string },
  smcStrategy2?: { detected: boolean; tp: number[]; sl: number; reason: string },
  smcStrategy3?: { detected: boolean; tp: number[]; sl: number; reason: string },
  smcStrategy5?: { detected: boolean; tp: number[]; sl: number; reason: string },
  smcStrategy6?: { detected: boolean; tp: number[]; sl: number; reason: string },
  smcStrategy7?: { detected: boolean; tp: number[]; sl: number; reason: string }
} => {
  if (candles.length < 60) {
    return { 
      score: 0, 
      activeBias: 'BULLISH', 
      logs: [], 
      regime: 'MEAN_REVERSION', 
      reasoning: ["Insufficient data."],
      nexusNodes: { smc: 0, momentum: 0, context: 0 },
      conviction: 'NORMAL',
      expansion: { detected: false, potential: 0 },
      qvd: { mass: 0, isInstitutional: false }
    };
  }
  
  const regime = detectMarketRegime(candles);
  const narrative = analyzeNarrative(candles, htfBias);
  const last = candles[candles.length - 1];
  const mpi = calculateMPI(candles);
  const expansion = detectExpansionImpulse(candles);
  const ofi = detectOrderFlowImbalance(candles);
  const trap = detectLiquidityTrap(candles);
  const entropy = detectInstitutionalEntropy(candles);
  const fractal = detectFractalSync(candles);
  const qvd = detectVolumeDisplacement(candles);
  
  // V162: Strategy Number 1 - SMC OTE Assessment
  const smcOteLong = detectSMCOTE(candles, candles.slice(-100), 'BULLISH'); 
  const smcOteShort = detectSMCOTE(candles, candles.slice(-100), 'BEARISH');

  // V163: Strategy Number 2 - SMC Swing assessment
  const smcSwingLong = detectSMCSwing(candles, 'BULLISH');
  const smcSwingShort = detectSMCSwing(candles, 'BEARISH');

  // V164: Strategy Number 3 - Breakout Retest assessment
  const smcBRLong = detectBreakoutRetest(candles, 'BULLISH');
  const smcBRShort = detectBreakoutRetest(candles, 'BEARISH');

  // V170: New Human Logic Strategies (5, 6, 7)
  const s5Long = detectEMARsiConfluence(candles, 'BULLISH');
  const s5Short = detectEMARsiConfluence(candles, 'BEARISH');
  const s6Long = detectTrendlineBreak(candles, 'BULLISH');
  const s6Short = detectTrendlineBreak(candles, 'BEARISH');
  const s7Long = detectSREngulfing(candles, 'BULLISH');
  const s7Short = detectSREngulfing(candles, 'BEARISH');
  
  // V151: Human Logic Extensions (Reducing Noise)
  const last2 = candles.slice(-2);
  const volumeTrend = last.volume > last2[0].volume; 
  const candlePattern = detectCandlestickPattern(candles);
  const htfAlignment = htfBias === narrative.bias; 
  
  const reasoning: string[] = [`Regime: ${regime}`];
  const momentumValue = calculateMomentum(candles, 12);
  const activeBias = momentumValue > 0 ? 'BULLISH' : 'BEARISH';
  const reflex = detectReflexBreath(candles, activeBias);
  const logs: string[] = [`🧠 [V150_AETHER_MIND] Holographic synthesis active.`];
  
  // STABILITY GUARD
  if (!entropy.isStable && !qvd.isInstitutional) {
    reasoning.push("Institutional Entropy detected. Market noise too high.");
  }

  // NODE 1: INSTITUTIONAL MODEL (SMC) - The "Intent"
  let smcAlpha = narrative.quality;
  const sweep = detectLiquiditySweep(candles);
  const mss = detectChoCh(candles);
  
  // V165: HUMAN CONTEXT FILTER
  const isTrendRegime = regime === 'INSTITUTIONAL_TREND';
  const isExpansionRegime = regime === 'LIQUIDITY_EXPANSION';
  const isMeanReversion = regime === 'MEAN_REVERSION';

  // Strategy Alpha Logic - Environment specific
  if (isTrendRegime) {
      if (smcOteLong.detected && activeBias === 'BULLISH') { smcAlpha += 400; reasoning.push(`🎯 [S1] Trend Follow Bullish.`); }
      if (smcOteShort.detected && activeBias === 'BEARISH') { smcAlpha += 400; reasoning.push(`🎯 [S1] Trend Follow Bearish.`); }
      if (smcBRLong.detected && activeBias === 'BULLISH') { smcAlpha += 350; reasoning.push(`🎯 [S3] Breakout Momentum Bullish.`); }
      if (smcBRShort.detected && activeBias === 'BEARISH') { smcAlpha += 350; reasoning.push(`🎯 [S3] Breakout Momentum Bearish.`); }
      if (s5Long.detected && activeBias === 'BULLISH') { smcAlpha += 300; reasoning.push(`🎯 [S5] EMA+RSI Trend Confluence.`); }
      if (s5Short.detected && activeBias === 'BEARISH') { smcAlpha += 300; reasoning.push(`🎯 [S5] EMA+RSI Trend Confluence.`); }
  }

  if (isMeanReversion || isExpansionRegime) {
      if (smcSwingLong.detected && activeBias === 'BULLISH') { smcAlpha += 500; reasoning.push(`🎯 [S2] Liquidity Reversal Bullish.`); }
      if (smcSwingShort.detected && activeBias === 'BEARISH') { smcAlpha += 500; reasoning.push(`🎯 [S2] Liquidity Reversal Bearish.`); }
      if (s7Long.detected && activeBias === 'BULLISH') { smcAlpha += 450; reasoning.push(`🎯 [S7] SR Rejection Reversal.`); }
      if (s7Short.detected && activeBias === 'BEARISH') { smcAlpha += 450; reasoning.push(`🎯 [S7] SR Rejection Reversal.`); }
  }

  if (isScalping) {
      if (s6Long.detected && activeBias === 'BULLISH') { smcAlpha += 400; reasoning.push(`⚡ [S6] Scalping Trendline Break.`); }
      if (s6Short.detected && activeBias === 'BEARISH') { smcAlpha += 400; reasoning.push(`⚡ [S6] Scalping Trendline Break.`); }
  }

  // Strategy Multiplexing
  const smcStrategy1 = isTrendRegime ? (activeBias === 'BULLISH' ? smcOteLong : smcOteShort) : undefined;
  const smcStrategy2 = (isExpansionRegime || isMeanReversion) ? (activeBias === 'BULLISH' ? smcSwingLong : smcSwingShort) : undefined;
  const smcStrategy3 = isTrendRegime ? (activeBias === 'BULLISH' ? smcBRLong : smcBRShort) : undefined;
  const smcStrategy5 = isTrendRegime ? (activeBias === 'BULLISH' ? s5Long : s5Short) : undefined;
  const smcStrategy6 = isScalping ? (activeBias === 'BULLISH' ? s6Long : s6Short) : undefined;
  const smcStrategy7 = (isExpansionRegime || isMeanReversion) ? (activeBias === 'BULLISH' ? s7Long : s7Short) : undefined;

  // Additional Nodes
  if (sweep.detected) smcAlpha += 180;
  if (trap.detected && trap.type === (activeBias === 'BULLISH' ? 'BULLISH' : 'BEARISH')) smcAlpha += 200;
  if (mss === (activeBias === 'BULLISH' ? 'BULLISH' : 'BEARISH')) smcAlpha += 140;
  if (qvd.isInstitutional) smcAlpha += 120;

  // NODE 2: MOMENTUM & ORDER FLOW 
  let momAlpha = 0;
  const squeeze = calculateSqueeze(candles);
  const dive = detectDivergence(candles);

  if (squeeze.squeezed) momAlpha += 120;
  if (Math.abs(momentumValue) > 0.35) momAlpha += 140;
  if (expansion.detected) momAlpha += 180;
  if (ofi.bias === activeBias) momAlpha += 130 * Math.min(4.0, ofi.strength);
  if (dive.detected) momAlpha += 180;
  if (fractal.synced) momAlpha += 110;
  if (reflex) momAlpha += 160;

  // NODE 3: ENVIRONMENTAL MODEL
  let ctxAlpha = 0;
  const range = getDealingRangeInfo(candles);
  const killzone = isInKillzone(killzoneTime);
  const pricePos = range.isDiscount(last.close) ? 'DISCOUNT' : (range.isPremium(last.close) ? 'PREMIUM' : 'EQUILIBRIUM');

  if ((activeBias === 'BULLISH' && pricePos === 'DISCOUNT') || (activeBias === 'BEARISH' && pricePos === 'PREMIUM')) {
    ctxAlpha += 220;
    reasoning.push(`Premium/Discount alignment: ${pricePos}.`);
  } else {
    ctxAlpha -= 600; 
    reasoning.push(`Warning: Crowded Retail Zone (${pricePos}). Rejection active.`);
  }

  if (killzone) ctxAlpha += 100;
  if ((activeBias === 'BULLISH' && candlePattern.sentiment === 'BEARISH') || (activeBias === 'BEARISH' && candlePattern.sentiment === 'BULLISH')) ctxAlpha -= 400;
  if (!volumeTrend && !qvd.isInstitutional) ctxAlpha -= 150;
  if (htfAlignment) smcAlpha += 150;
  else if (htfBias !== 'NEUTRAL') ctxAlpha -= 300;

  let conviction: 'NORMAL' | 'HIGH' | 'SOVEREIGN' = 'NORMAL';
  if (smcAlpha > 400 && expansion.detected && qvd.isInstitutional && entropy.isStable && htfAlignment) conviction = 'SOVEREIGN';
  else if (smcAlpha > 300 || (expansion.detected && trap.detected)) conviction = 'HIGH';

  const smcWeight = conviction === 'SOVEREIGN' ? 1.0 : (mpi > 0.8 ? 0.90 : 0.80);
  const momWeight = 0.05;
  const ctxWeight = 0.25;

  const unifiedScore = (smcAlpha * smcWeight) + (momAlpha * momWeight) + (ctxAlpha * ctxWeight);
  const regimeMultiplier = { 'INSTITUTIONAL_TREND': 1.85, 'LIQUIDITY_EXPANSION': 2.80, 'MEAN_REVERSION': 0.40, 'VOLATILITY_CRUSH': 0.15 }[regime];
  const baseFinal = (unifiedScore + (isScalping ? 50 : 0)) * regimeMultiplier;
  const finalScore = (entropy.isStable || qvd.isInstitutional) ? baseFinal : baseFinal * 0.15;

  return { 
    score: Math.max(0, finalScore), 
    activeBias, 
    logs, 
    regime, 
    reasoning,
    nexusNodes: { smc: smcAlpha, momentum: momAlpha, context: ctxAlpha },
    conviction,
    expansion,
    qvd,
    smcStrategy1,
    smcStrategy2,
    smcStrategy3,
    smcStrategy5,
    smcStrategy6,
    smcStrategy7
  };
};


// V15 Stealth: Relative Volatility Index (RVI) - Measure context quality
export const calculateRVI = (candles: Candle[], period: number = 10): number => {
  if (candles.length < period) return 50;
  const recent = candles.slice(-period);
  const upStd = recent.filter(c => c.close > c.open).reduce((acc, c) => acc + (c.high - c.low), 0);
  const downStd = recent.filter(c => c.close <= c.open).reduce((acc, c) => acc + (c.high - c.low), 0);
  
  if (upStd + downStd === 0) return 50;
  return (upStd / (upStd + downStd)) * 100;
};

export const detectCandlestickPattern = (candles: Candle[]): { type: 'HAMMER' | 'SHOOTING_STAR' | 'ENGULFING' | null; sentiment: 'BULLISH' | 'BEARISH' | null } => {
  if (candles.length < 2) return { type: null, sentiment: null };
  const last = candles[candles.length - 1];
  const prev = candles[candles.length - 2];
  
  const bodySize = last.bodySize;
  const totalSize = last.high - last.low;
  const upperWick = last.high - Math.max(last.open, last.close);
  const lowerWick = Math.min(last.open, last.close) - last.low;

  // 1. Hammer / Pin Bar Sentiment
  if (lowerWick > bodySize * 2 && upperWick < bodySize * 0.5) {
    return { type: 'HAMMER', sentiment: 'BULLISH' };
  }
  
  // 2. Shooting Star
  if (upperWick > bodySize * 2 && lowerWick < bodySize * 0.5) {
    return { type: 'SHOOTING_STAR', sentiment: 'BEARISH' };
  }

  // 3. Engulfing
  const isBullishEngulfing = prev.close < prev.open && last.close > last.open && last.close > prev.open && last.open < prev.close;
  const isBearishEngulfing = prev.close > prev.open && last.close < last.open && last.close < prev.open && last.open > prev.close;

  if (isBullishEngulfing) return { type: 'ENGULFING', sentiment: 'BULLISH' };
  if (isBearishEngulfing) return { type: 'ENGULFING', sentiment: 'BEARISH' };

  return { type: null, sentiment: null };
};

export const detectMarketPhase = (candles: Candle[]): 'ACCUMULATION' | 'TRENDING' | 'DISTRIBUTION' | 'VOLATILE' => {
  const recent = candles.slice(-30);
  const bodySizes = recent.map(c => c.bodySize);
  const avgBody = bodySizes.reduce((a, b) => a + b, 0) / 30;
  const volatility = Math.max(...recent.map(c => c.high)) - Math.min(...recent.map(c => c.low));
  
  const last5 = candles.slice(-5);
  const trendStrength = Math.abs(last5[last5.length-1].close - last5[0].open);
  
  if (volatility > avgBody * 15) return 'VOLATILE';
  if (trendStrength > avgBody * 5) return 'TRENDING';
  
  const high = Math.max(...recent.map(c => c.high));
  const low = Math.min(...recent.map(c => c.low));
  const range = high - low;
  if (range < avgBody * 8) return 'ACCUMULATION';
  
  return 'DISTRIBUTION';
};

// V17 Humanoid: RSI Calculation
export const calculateRSI = (candles: Candle[], period: number = 14): number => {
  if (candles.length <= period) return 50;
  const changes = candles.slice(-period).map((c, i, arr) => i === 0 ? 0 : c.close - arr[i-1].close);
  const gains = changes.filter(v => v > 0);
  const losses = changes.filter(v => v < 0).map(v => Math.abs(v));
  
  const avgGain = gains.reduce((a, b) => a + b, 0) / period;
  const avgLoss = losses.reduce((a, b) => a + b, 0) / period;
  
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
};

// V17 Humanoid: Divergence Detection (Hidden Institutional Clues)
export const detectDivergence = (candles: Candle[]): { detected: boolean; type: 'BULLISH' | 'BEARISH' | null } => {
  if (candles.length < 30) return { detected: false, type: null };
  const last = candles[candles.length - 1];
  const lookback = candles.slice(-20, -1);
  const oldHigh = Math.max(...lookback.map(c => c.high));
  const oldLow = Math.min(...lookback.map(c => c.low));
  
  const lastRSI = calculateRSI(candles, 14);
  const oldRSIs = candles.slice(-30, -2).map((_, i, arr) => calculateRSI(candles.slice(0, candles.length - 30 + i), 14));
  const maxRSI = Math.max(...oldRSIs);
  const minRSI = Math.min(...oldRSIs);

  // Bearish Divergence: Price higher high, RSI lower high
  if (last.high > oldHigh && lastRSI < maxRSI - 5) return { detected: true, type: 'BEARISH' };
  // Bullish Divergence: Price lower low, RSI higher low
  if (last.low < oldLow && lastRSI > minRSI + 5) return { detected: true, type: 'BULLISH' };

  return { detected: false, type: null };
};

// V18 Humanoid: Momentum Pulse (Rate of Change)
export const calculateMomentum = (candles: Candle[], period: number = 10): number => {
  if (candles.length <= period) return 0;
  const current = candles[candles.length - 1].close;
  const old = candles[candles.length - 1 - period].close;
  return ((current - old) / old) * 100;
};

// V18 Humanoid: ATR for Dynamic Volatility Stops
export const calculateATR = (candles: Candle[], period: number = 14): number => {
  if (candles.length < period) return candles[0]?.close * 0.01 || 10;
  const trueRanges = candles.slice(-period).map((c, i, arr) => {
    if (i === 0) return c.high - c.low;
    const prevClose = arr[i-1].close;
    return Math.max(c.high - c.low, Math.abs(c.high - prevClose), Math.abs(c.low - prevClose));
  });
  return trueRanges.reduce((a, b) => a + b, 0) / period;
};

// V19 Humanoid: Stochastic RSI (Fast Momentum)
export const calculateStochRSI = (candles: Candle[], period: number = 14): { k: number; d: number } => {
  if (candles.length < period * 2) return { k: 50, d: 50 };
  const rsis = candles.slice(-period * 2).map((_, i, arr) => calculateRSI(candles.slice(0, candles.length - period * 2 + i), 14));
  const recentRSI = rsis.slice(-period);
  const lowRSI = Math.min(...recentRSI);
  const highRSI = Math.max(...recentRSI);
  
  const stoch = ((recentRSI[recentRSI.length-1] - lowRSI) / (highRSI - lowRSI || 1)) * 100;
  return { k: stoch, d: stoch }; // Simplified for K/D signals
};

export const getSessionStats = (candles: Candle[]) => {
  const recent = candles.slice(-48); // ~4 hours of 5m data or last few hours
  const high = Math.max(...recent.map(c => c.high));
  const low = Math.min(...recent.map(c => c.low));
  return {
    high,
    low,
    mean: (high + low) / 2
  };
};

// V22 ELITE: Squeeze Momentum (Bollinger/Keltner)
export const calculateSqueeze = (candles: Candle[], period: number = 20): { squeezed: boolean; momentum: number } => {
  if (candles.length < period) return { squeezed: false, momentum: 0 };
  const closes = candles.slice(-period).map(c => c.close);
  const mean = closes.reduce((a, b) => a + b, 0) / period;
  const stdDev = Math.sqrt(closes.map(x => Math.pow(x - mean, 2)).reduce((a, b) => a + b, 0) / period);
  
  // Bollinger Bands
  const bbUpper = mean + (2 * stdDev);
  const bbLower = mean - (2 * stdDev);
  
  // Keltner Channels (Simplified)
  const atr = calculateATR(candles, period);
  const kcUpper = mean + (1.5 * atr);
  const kcLower = mean - (1.5 * atr);
  
  const squeezed = bbUpper < kcUpper && bbLower > kcLower;
  const momentum = calculateMomentum(candles, 10);
  
  return { squeezed, momentum };
};

// V22 ELITE: Supply/Demand Zone Mapping
export const findEliteZones = (candles: Candle[]) => {
  const zones: { type: 'SUPPLY' | 'DEMAND'; price: number; strength: number }[] = [];
  if (candles.length < 50) return zones;

  for (let i = candles.length - 20; i < candles.length - 2; i++) {
    const c1 = candles[i];
    const c2 = candles[i+1];
    
    // Demand (Bullish Engulfing with Volume)
    if (c2.close > c1.high && c2.volume > c1.volume * 1.5) {
      zones.push({ type: 'DEMAND', price: c1.low, strength: c2.volume });
    }
    // Supply (Bearish Engulfing with Volume)
    if (c2.close < c1.low && c2.volume > c1.volume * 1.5) {
      zones.push({ type: 'SUPPLY', price: c1.high, strength: c2.volume });
    }
  }
  return zones.sort((a, b) => b.strength - a.strength).slice(0, 3);
};

export const calculateEMA = (candles: Candle[], period: number): number => {
  if (candles.length === 0) return 0;
  const k = 2 / (period + 1);
  let ema = candles[0].close;
  for (let i = 1; i < candles.length; i++) {
    ema = candles[i].close * k + ema * (1 - k);
  }
  return ema;
};

export const getHTFBias = (htfCandles: Candle[]): 'BULLISH' | 'BEARISH' | 'NEUTRAL' => {
  if (htfCandles.length < 10) return 'NEUTRAL';
  const ema20 = calculateEMA(htfCandles, 20);
  const last = htfCandles[htfCandles.length - 1];
  if (last.close > ema20) return 'BULLISH';
  if (last.close < ema20) return 'BEARISH';
  return 'NEUTRAL';
};

export const getDealingRangeInfo = (candles: Candle[]): { high: number; low: number; equilibrium: number; isDiscount: (p: number) => boolean; isPremium: (p: number) => boolean } => {
  const lookback = candles.slice(-100);
  const high = Math.max(...lookback.map(c => c.high));
  const low = Math.min(...lookback.map(c => c.low));
  const equilibrium = (high + low) / 2;
  
  return {
    high,
    low,
    equilibrium,
    isDiscount: (p: number) => p < (low + (high - low) * 0.5),
    isPremium: (p: number) => p > (high - (high - low) * 0.5)
  };
};

export const detectDisplacement = (candles: Candle[]): boolean => {
  if (candles.length < 10) return false;
  const last = candles[candles.length - 1];
  const prev = candles.slice(-10, -1);
  const avgBody = prev.reduce((acc, c) => acc + c.bodySize, 0) / prev.length;
  
  // Institutional Signature: Body size > 1.8x average with decent energy
  const bodyToTotalRatio = last.bodySize / (last.high - last.low);
  return last.bodySize > avgBody * 1.8 && bodyToTotalRatio > 0.6;
};

export const getPowerOfThree = (candles: Candle[]) => {
  if (candles.length < 24) return null;
  const session = candles.slice(-24); // Daily cycle approximation
  const open = session[0].open;
  const high = Math.max(...session.map(s => s.high));
  const low = Math.min(...session.map(s => s.low));
  const close = session[session.length - 1].close;
  
  return { open, high, low, close, phase: close > open ? 'ACCUMULATION' : 'DISTRIBUTION' };
};

export const detectChoCh = (candles: Candle[]): 'BULLISH' | 'BEARISH' | null => {
  if (candles.length < 20) return null;
  const last = candles[candles.length - 1];
  
  // A true Change of Character requires a displacement-style move breaking the most recent significant structural point
  const lookback = candles.slice(-25, -1);
  const swingHighs = lookback.filter((c, i, arr) => {
      if (i < 2 || i > arr.length - 3) return false;
      return c.high > arr[i-1].high && c.high > arr[i-2].high && c.high > arr[i+1].high && c.high > arr[i+2].high;
  });
  const swingLows = lookback.filter((c, i, arr) => {
      if (i < 2 || i > arr.length - 3) return false;
      return c.low < arr[i-1].low && c.low < arr[i-2].low && c.low < arr[i+1].low && c.low < arr[i+2].low;
  });

  if (swingHighs.length > 0) {
      const lastSwingHigh = swingHighs[swingHighs.length - 1].high;
      if (last.close > lastSwingHigh && last.bodySize > calculateEMA(candles, 14) * 1.5) return 'BULLISH';
  }

  if (swingLows.length > 0) {
      const lastSwingLow = swingLows[swingLows.length - 1].low;
      if (last.close < lastSwingLow && last.bodySize > calculateEMA(candles, 14) * 1.5) return 'BEARISH';
  }
  
  return null;
};

export const detectWickRejection = (candles: Candle[]): { detected: boolean; price: number | null; type: 'BULL' | 'BEAR' | null } => {
  if (candles.length < 3) return { detected: false, price: null, type: null };
  const last = candles[candles.length - 1];
  
  const avgBody = candles.slice(-10).reduce((acc, c) => acc + c.bodySize, 0) / 10;
  
  // Upper wick rejection (Bearish)
  if (last.wickUpper > last.bodySize * 2.5 && last.wickUpper > avgBody * 1.5) {
    return { detected: true, price: last.high, type: 'BEAR' };
  }
  
  // Lower wick rejection (Bullish)
  if (last.wickLower > last.bodySize * 2.5 && last.wickLower > avgBody * 1.5) {
    return { detected: true, price: last.low, type: 'BULL' };
  }
  
  return { detected: false, price: null, type: null };
};

export const isInKillzone = (timestamp: number): boolean => {
  const hour = new Date(timestamp).getUTCHours();
  // London: 7-10 UTC, NY: 12-15 UTC
  return (hour >= 7 && hour <= 10) || (hour >= 12 && hour <= 15);
};

export const isInSilverBullet = (timestamp: number): boolean => {
  const hour = new Date(timestamp).getUTCHours();
  const minute = new Date(timestamp).getUTCMinutes();
  
  // 3 AM - 4 AM EST = 8 AM - 9 AM UTC
  // 10 AM - 11 AM EST = 15 PM - 16 PM UTC
  // 2 PM - 3 PM EST = 19 PM - 20 PM UTC
  const isMorning = hour === 8;
  const isMidDay = hour === 15;
  const isAfternoon = hour === 19;
  
  return isMorning || isMidDay || isAfternoon;
};

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BacktestResult, Candle, Trade, AssetType, StrategyType } from '../types';
import { detectLiquiditySweep, detectOrderBlock, detectFVG, calculateEMA, detectDisplacement, getDealingRangeInfo, detectVolumeCluster, calculateRVI, detectMarketPhase, detectCandlestickPattern, detectDivergence, calculateRSI, calculateMomentum, calculateATR, calculateStochRSI, getSessionStats, calculateSqueeze, findEliteZones, detectChoCh, detectBreakerBlock, calculateSuperhumanScore, calculateAdaptiveSL, getHTFBias, calculateMPI } from './strategies';

export class BacktestEngine {
  public static simulate(days: number, currentPrice: number, realData?: Candle[], asset: AssetType = 'CRYPTO', mode: 'INSTITUTIONAL' | 'SCALPING' = 'INSTITUTIONAL', initialBalance: number = 1000): BacktestResult {
    const candleCount = realData ? realData.length : days * 288;
    let price = currentPrice;
    const candles: Candle[] = [];
    const trades: Trade[] = [];
    let balance = initialBalance; 
    let peaks = [balance];
    let dailyLoss = 0;
    let lastLossReset = 0;
    let cooldownUntil = 0;
    let consecutiveLosses = 0;

    const BINANCE_FEE_RATE = asset === 'GOLD' ? 0.00015 : 0.0003; 
    const SLIPPAGE_FACTOR = 0.0001; 
    const SPREAD_COST = asset === 'GOLD' ? 0.05 : 0.5; 

    const dailyLogsMap: Record<string, { pnl: number, trades: number, executions: Trade[] }> = {}; 
    
    for (let i = 0; i < candleCount; i++) {
        let candle: Candle;
        if (realData && realData[i]) {
            candle = realData[i];
        } else {
            // V31: Chaotic Institutional Fractal Generator (Aether Chaos)
            const phase = (i % 288);
            let volatility = asset === 'CRYPTO' ? 0.002 : 0.0008;
            
            // Random Chaos Surge (Black Swan)
            const chaosRand = Math.random();
            const isChaosEvent = chaosRand > 0.998;
            
            // Macro Sentiment Shift (Slowly rotating bias)
            const macroSentiment = Math.sin(i / (200 + (Math.random() * 100))) * 0.005; 
            
            const hour = Math.floor(phase / 12);
            if ((hour >= 7 && hour <= 10) || (hour >= 13 && hour <= 16)) volatility *= 2.8; // More aggressive killzones

            if (isChaosEvent) volatility *= (5.0 + Math.random() * 10); // Volatility Explosion

            const noise = (Math.random() - 0.5) * volatility;
            const change = price * (macroSentiment + noise);
            
            candle = {
                time: Date.now() - (candleCount - i) * 60000 + (Math.random() * 5000), // Time jitter
                open: price,
                high: price + Math.max(0, change) + (Math.random() * price * volatility * 0.7),
                low: price + Math.min(0, change) - (Math.random() * price * volatility * 0.7),
                close: price + change,
                volume: (500 + Math.random() * 5000) * (isChaosEvent ? 10 : 1),
                wickUpper: 0,
                wickLower: 0,
                bodySize: Math.abs(change)
            };
        }
        
        const dateKey = new Date(candle.time).toISOString().split('T')[0];
        if (!dailyLogsMap[dateKey]) dailyLogsMap[dateKey] = { pnl: 0, trades: 0, executions: [] };

        // Reset Daily Risk
        const currentDay = new Date(candle.time).setHours(0,0,0,0);
        if (lastLossReset !== currentDay) {
            dailyLoss = 0;
            lastLossReset = currentDay;
        }

      candles.push(candle);
      price = candle.close;
      const subCandles = candles.slice(0, i + 1);

        // 1. Process Open Trades
        trades.filter(t => t.status === 'OPEN').forEach(t => {
            const isLong = t.type === 'LONG';
            const pnlPerUnit = isLong ? (candle.close - t.entry) : (t.entry - candle.close);
            const slDist = Math.abs(t.entry - t.sl);
            const rRatio = pnlPerUnit / slDist;

            // V162: Strategy 1 Multi-TP Logic
            const hitTP1 = t.tp2 && (isLong ? candle.high >= t.tp2 : candle.low <= t.tp2);
            const hitTP2 = t.tp3 && (isLong ? candle.high >= t.tp3 : candle.low <= t.tp3);
            const isOTE = t.strategy === 'STRATEGY_1_SMC_OTE';
            const isSMC2 = t.strategy === 'STRATEGY_2_LIQUIDITY_REVERSAL';
            const isSMC3 = t.strategy === 'STRATEGY_3_BREAKOUT_RETEST';

            // V161: Predator's Patience - Secured Management
            const beThreshold = 1.1; // Move to BE early (+1.1R)
            const tp1Threshold = t.conviction === 'SOVEREIGN' ? 6.5 : 4.5;
            const tp2Threshold = t.conviction === 'SOVEREIGN' ? 14.0 : 8.5;

            if ((rRatio >= beThreshold || (isOTE && rRatio > 0.8) || (isSMC2 && rRatio > 0.6) || (isSMC3 && rRatio > 0.7)) && !t.beMoved) {
                const profitBuffer = slDist * 0.15; // Secure small buffer
                t.sl = isLong ? t.entry + profitBuffer : t.entry - profitBuffer;
                t.beMoved = true;
            }

            // V160: Active Scaling Partials
            if ((rRatio >= tp1Threshold || hitTP1) && !t.partialTaken) {
                const partialUnits = (t.units || 0) * 0.4; 
                const partialProfit = partialUnits * pnlPerUnit;
                const exitFee = partialUnits * candle.close * BINANCE_FEE_RATE;
                
                const netPartialPnL = partialProfit - exitFee;
                balance += netPartialPnL;
                t.profit = (t.profit || 0) + netPartialPnL; 
                t.units = (t.units || 0) - partialUnits;
                t.partialTaken = true;
                
                const lockRatio = 2.0; 
                const lockBuffer = slDist * lockRatio;
                t.sl = isLong ? t.entry + lockBuffer : t.entry - lockBuffer;
            }

            if ((rRatio >= tp2Threshold || hitTP2) && t.partialTaken && !t.partialTaken2) {
                const partialUnits = (t.units || 0) * 0.5; 
                const partialProfit = partialUnits * pnlPerUnit;
                const exitFee = partialUnits * candle.close * BINANCE_FEE_RATE;
                
                const netPartialPnL = partialProfit - exitFee;
                balance += netPartialPnL;
                t.profit = (t.profit || 0) + netPartialPnL;
                t.units = (t.units || 0) - partialUnits;
                t.partialTaken2 = true;
                
                const lockRatio = 4.0;
                const lockBuffer = slDist * lockRatio;
                t.sl = isLong ? t.entry + lockBuffer : t.entry - lockBuffer;
            }

            // God Candle Tracker (High Velocity Trailing)
            if (rRatio >= 10.0) {
                const trailBuffer = slDist * (t.conviction === 'SOVEREIGN' ? 0.60 : 0.80);
                const newSl = isLong ? candle.close - trailBuffer : candle.close + trailBuffer;
                if (isLong && newSl > t.sl) t.sl = newSl;
                else if (!isLong && newSl < t.sl) t.sl = newSl;
            }

            // Exit Logic
        const isHitTP = isLong ? candle.high >= t.tp : candle.low <= t.tp;
        const isHitSL = isLong ? candle.low <= t.sl : candle.high >= t.sl;

        if (isHitTP || isHitSL) {
          t.status = 'CLOSED';
          const exitPrice = isHitTP ? t.tp : t.sl;
          t.result = isHitTP ? 'WIN' : 'LOSS';
          
          const finalUnits = t.units || 0;
          const finalProfit = (isLong ? (exitPrice - t.entry) : (t.entry - exitPrice)) * finalUnits;
          const feeSlippage = finalUnits * exitPrice * (BINANCE_FEE_RATE + SLIPPAGE_FACTOR);
          
          const netFinalPnL = finalProfit - feeSlippage;
          t.profit = (t.profit || 0) + netFinalPnL;
          balance += netFinalPnL;
          peaks.push(balance);
          
          if (t.result === 'LOSS' && (t.profit || 0) < 0) {
              dailyLoss += Math.abs(t.profit || 0);
              consecutiveLosses++;
              
              // Matrix Breaker: 15m default, but scales exponentially
              let coolMins = 15;
              if (consecutiveLosses === 2) coolMins = 60;
              else if (consecutiveLosses >= 3) coolMins = 240;
              
              cooldownUntil = candle.time + (coolMins * 60000);
          } else {
              consecutiveLosses = 0;
              cooldownUntil = candle.time + 300000; // 5m win-pause
          }

          dailyLogsMap[dateKey].pnl += (t.profit || 0);
          dailyLogsMap[dateKey].trades += 1;
          dailyLogsMap[dateKey].executions.push({ ...t });
        }
      });

      // 2. Entry Logic (V150 Aether Mind: Holographic Intelligence)
      const openTrades = trades.filter(t => t.status === 'OPEN');
      const maxDailyLoss = balance * 0.05; // 5% Daily cutoff for high-intensity mode
      
        if (subCandles.length >= 60 && openTrades.length < 5 && balance > 20 && dailyLoss < maxDailyLoss && candle.time >= cooldownUntil) {
          const htfBias = getHTFBias(subCandles);
          const isScalping = mode === 'SCALPING';
          const { score, activeBias, logs, regime, reasoning, conviction, expansion, smcStrategy1, smcStrategy2, smcStrategy3, smcStrategy5, smcStrategy6, smcStrategy7 } = calculateSuperhumanScore(subCandles, candle.time, htfBias, isScalping);
          
          // V159: Predatory Intensity - Increasing Density
          const mpi = calculateMPI(subCandles);
          const baseThreshold = isScalping ? 85.0 : 110.0; // Lowered significantly
          const mpiMultiplier = Math.max(0.35, Math.min(1.15, 1 / (mpi * 1.8)));
          const convictionMultiplier = conviction === 'SOVEREIGN' ? 0.65 : (conviction === 'HIGH' ? 0.80 : 1.0);
          
          const riskTightening = consecutiveLosses > 0 ? (1 + (consecutiveLosses * 0.15)) : 1.0;
          
          let priceDiscipline = 1.0;
          const lastT = trades[trades.length - 1];
          if (lastT && lastT.result === 'LOSS') {
            const d = Math.abs(candle.close - lastT.entry) / lastT.entry;
            if (d < 0.001) priceDiscipline = 1.25; 
          }

          const threshold = (baseThreshold * mpiMultiplier * convictionMultiplier * riskTightening * priceDiscipline);

          // V163: ADVANCED HUMAN CONTEXT PROTECTION (Risk Management V2)
          let isHumanValid = true;
          const last10 = subCandles.slice(-10);
          const rangeSize = Math.max(...last10.map(c => c.high)) - Math.min(...last10.map(c => c.low));
          const avgAtr = calculateATR(subCandles, 14);
          
          // 1. Choppiness & Momentum - Refined
          const rsi = calculateRSI(subCandles, 14);
          if (rangeSize < avgAtr * (isScalping ? 0.20 : 0.40)) isHumanValid = false;
          
          if (!isScalping) {
            if (activeBias === 'BULLISH' && rsi > 72) isHumanValid = false;
            if (activeBias === 'BEARISH' && rsi < 28) isHumanValid = false;
            
            // 2. Narrative Alignment - Still strict (Crucial for Profitable Edge)
            if (htfBias !== 'NEUTRAL' && htfBias !== (activeBias === 'BULLISH' ? 'BULLISH' : 'BEARISH')) isHumanValid = false;
          } else {
            // In scalping, only restrict absolute top/bottom chasing
            if (activeBias === 'BULLISH' && rsi > 85) isHumanValid = false;
            if (activeBias === 'BEARISH' && rsi < 15) isHumanValid = false;
          }
  
          // 3. V163 Reward-to-Risk Requirement (Minimum 3.0 Real RR for swing, 1.5 for scalping)
          const lookPrev = subCandles.slice(-30);
          const targetHigh = Math.max(...lookPrev.map(c => c.high));
          const targetLow = Math.min(...lookPrev.map(c => c.low));
          const potentialProfit = activeBias === 'BULLISH' ? (targetHigh - candle.close) : (candle.close - targetLow);
          const projectedSL = avgAtr * (isScalping ? 0.85 : 1.35); 
          
          const minRRRequired = isScalping ? 1.5 : 3.0;
          if (potentialProfit / projectedSL < minRRRequired) isHumanValid = false; 
 
          if (score >= threshold && isHumanValid) {
          const isLong = activeBias === 'BULLISH';
          
          // V161 Structural SL
          const lookback = subCandles.slice(-40);
          const sLow = Math.min(...lookback.map(c => c.low));
          const sHigh = Math.max(...lookback.map(c => c.high));
          const atrVal = calculateATR(subCandles, 14);
          
          let slLevel: number;
          if (smcStrategy1?.detected) {
            slLevel = smcStrategy1.sl;
          } else if (smcStrategy2?.detected) {
            slLevel = smcStrategy2.sl;
          } else if (smcStrategy3?.detected) {
            slLevel = smcStrategy3.sl;
          } else if (smcStrategy5?.detected) {
            slLevel = smcStrategy5.sl;
          } else if (smcStrategy6?.detected) {
            slLevel = smcStrategy6.sl;
          } else if (smcStrategy7?.detected) {
            slLevel = smcStrategy7.sl;
          } else if (isLong) {
              slLevel = Math.min(sLow - (atrVal * 0.1), candle.close - (atrVal * 1.4));
          } else {
              slLevel = Math.max(sHigh + (atrVal * 0.1), candle.close + (atrVal * 1.4));
          }

          const slDist = Math.abs(candle.close - slLevel);
          
          // V161 Asymmetric Scaling: Minimum 1:4.5 coverage
          let rr = 4.5; // Baseline: 1 win covers 4.5 losses
          if (smcStrategy1?.detected) {
            const tp3 = smcStrategy1.tp[2];
            rr = Math.abs(tp3 - candle.close) / slDist;
          } else if (smcStrategy2?.detected) {
            const tp2 = smcStrategy2.tp[1];
            rr = Math.abs(tp2 - candle.close) / slDist;
          } else if (smcStrategy3?.detected) {
            const tp2 = smcStrategy3.tp[1];
            rr = Math.abs(tp2 - candle.close) / slDist; 
          } else if (smcStrategy5?.detected) {
            const tp2 = smcStrategy5.tp[1];
            rr = Math.abs(tp2 - candle.close) / slDist;
          } else if (smcStrategy6?.detected) {
            const tp1 = smcStrategy6.tp[0];
            rr = Math.abs(tp1 - candle.close) / slDist;
          } else if (smcStrategy7?.detected) {
            const tp1 = smcStrategy7.tp[0];
            rr = Math.abs(tp1 - candle.close) / slDist;
          } else if (conviction === 'SOVEREIGN') rr = 18.0; 
          else if (conviction === 'HIGH') rr = 12.0;
          else if (regime === 'INSTITUTIONAL_TREND') rr = 9.0;
          else rr = Math.max(4.5, (score / 25)); 

          const tpDist = slDist * rr;

          // V150: Conviction-based Sovereign Risk Scaling
          let baseRisk = 0.015; // 1.5% base
          let alphaMultiplier = 1.0;
          
          // Matrix Protection: Degraded Risk after losses
          if (consecutiveLosses === 1) alphaMultiplier = 0.5;
          else if (consecutiveLosses >= 2) alphaMultiplier = 0.25;

          if (smcStrategy1?.detected) alphaMultiplier *= 3.2;
          else if (smcStrategy2?.detected) alphaMultiplier *= 3.8;
          else if (smcStrategy3?.detected) alphaMultiplier *= 3.0; // Strategy 3 solid logic
          else if (smcStrategy5?.detected) alphaMultiplier *= 1.8;
          else if (smcStrategy6?.detected) alphaMultiplier *= 1.5;
          else if (smcStrategy7?.detected) alphaMultiplier *= 2.2;
          else if (conviction === 'SOVEREIGN') alphaMultiplier *= 4.2; 
          else if (conviction === 'HIGH') alphaMultiplier *= 2.8; 

          // DD Protection
          const currentPeak = Math.max(...peaks, balance);
          const maxDdNow = currentPeak > 1 ? (currentPeak - balance) / currentPeak : 0;
          const ddMultiplier = maxDdNow > 0.25 ? 0.5 : (maxDdNow > 0.15 ? 0.75 : 1.0);
          const finalRisk = baseRisk * alphaMultiplier * ddMultiplier;

          const riskAmount = balance * finalRisk;
          const units = riskAmount / slDist;

          const btTP2 = smcStrategy1?.detected ? smcStrategy1.tp[0] : (smcStrategy2?.detected ? smcStrategy2.tp[0] : (smcStrategy3?.detected ? smcStrategy3.tp[0] : (smcStrategy5?.detected ? smcStrategy5.tp[0] : undefined)));
          const btTP3 = smcStrategy1?.detected ? smcStrategy1.tp[1] : (smcStrategy2?.detected ? smcStrategy2.tp[1] : (smcStrategy3?.detected ? smcStrategy3.tp[1] : (smcStrategy5?.detected ? smcStrategy5.tp[1] : undefined)));
          const btStrategyName = smcStrategy1?.detected ? 'STRATEGY_1_SMC_OTE' 
            : (smcStrategy2?.detected ? 'STRATEGY_2_LIQUIDITY_REVERSAL' 
            : (smcStrategy3?.detected ? 'STRATEGY_3_BREAKOUT_RETEST' 
            : (smcStrategy5?.detected ? 'STRATEGY_5_EMA_RSI' 
            : (smcStrategy6?.detected ? 'STRATEGY_6_TRENDLINE_SCALP' 
            : (smcStrategy7?.detected ? 'STRATEGY_7_SR_ENGULFING' 
            : 'SMC_SUPERHUMAN')))));

          trades.push({
            id: `bt_${i}_v150`,
            time: candle.time,
            type: isLong ? 'LONG' : 'SHORT',
            entry: candle.close,
            sl: slLevel,
            initialSL: slLevel,
            tp: isLong ? candle.close + tpDist : candle.close - tpDist,
            tp2: btTP2,
            tp3: btTP3,
            status: 'OPEN',
            strategy: btStrategyName as StrategyType,
            environment: 'INSTITUTIONAL',
            reason: smcStrategy1?.detected ? smcStrategy1.reason 
              : (smcStrategy2?.detected ? smcStrategy2.reason 
              : (smcStrategy3?.detected ? smcStrategy3.reason 
              : (smcStrategy5?.detected ? smcStrategy5.reason 
              : (smcStrategy6?.detected ? smcStrategy6.reason 
              : (smcStrategy7?.detected ? smcStrategy7.reason 
              : `V150 Aether: ${conviction} | Alpha ${score.toFixed(0)} | Risk ${(finalRisk*100).toFixed(2)}%`))))),
            reasoning_chain: reasoning,
            alpha_confidence: Math.min(100, (score / threshold) * 94),
            units: units
          });
        }
      }
    }

    const wins = trades.filter(t => t.result === 'WIN').length;
    const totalPnL = trades.reduce((acc, t) => acc + (t.profit || 0), 0);
    const totalProfit = trades.reduce((acc, t) => t.profit && t.profit > 0 ? acc + t.profit : acc, 0);
    const totalLoss = trades.reduce((acc, t) => t.profit && t.profit < 0 ? acc + Math.abs(t.profit) : acc, 0);
    
    // Max Drawdown calculation
    let maxDd = 0;
    let peak = peaks[0];
    peaks.forEach(bal => {
      if (bal > peak) peak = bal;
      const dd = peak > 0 ? (peak - bal) / peak : 0;
      if (dd > maxDd) maxDd = dd;
    });

    const dailyLogs = Object.entries(dailyLogsMap).map(([date, data]) => ({
      date,
      pnl: isNaN(data.pnl) ? 0 : data.pnl,
      trades: isNaN(data.trades) ? 0 : data.trades,
      executions: data.executions
    })).sort((a,b) => a.date.localeCompare(b.date));

    return {
      totalTrades: trades.length,
      winRate: trades.length > 0 ? (wins / trades.length) * 100 : 0,
      totalPnL,
      maxDrawdown: maxDd * 100,
      trades: trades.slice(-20), 
      allTrades: trades,
      dailyLogs,
      profitFactor: totalLoss > 0 ? totalProfit / totalLoss : totalProfit > 0 ? 100 : 0
    };
  }
}

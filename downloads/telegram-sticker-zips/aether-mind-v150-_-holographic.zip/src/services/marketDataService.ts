/**
 * Market Data Service
 * Provides authentic, high-fidelity market data from public exchange APIs.
 */

import { Candle } from "../types";

export const fetchRealHistoricalData = async (symbol: string = 'BTCUSDT', interval: string = '1h', limit: number = 1000): Promise<Candle[]> => {
  try {
    let allKlines: any[] = [];
    let currentEndTime: number | null = null;
    const maxChunkSize = 1000;
    let remaining = limit;

    while (remaining > 0) {
      const fetchLimit = Math.min(remaining, maxChunkSize);
      let url = `/api/market-data?symbol=${symbol}&interval=${interval}&limit=${fetchLimit}`;
      if (currentEndTime !== null) {
        url += `&endTime=${currentEndTime}`;
      }

      let data: any[] = [];
      try {
        const proxyResponse = await fetch(url);
        if (proxyResponse.ok) {
          data = await proxyResponse.json();
        }
      } catch (e) {
        // Silent fallback to direct Binance
      }

      if (!Array.isArray(data) || data.length === 0) {
        // Fallback directly to Binance if proxy is down or empty
        try {
          let directUrl = `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${fetchLimit}`;
          if (currentEndTime !== null) {
            directUrl += `&endTime=${currentEndTime}`;
          }
          const response = await fetch(directUrl);
          if (response.ok) {
            data = await response.json();
          }
        } catch (e) {
          break; // Both sources failed (might be offline or server error)
        }
      }

      if (!Array.isArray(data) || data.length === 0) {
        break; // No more data
      }

      // Add to front because we are fetching backwards (older data)
      allKlines = data.concat(allKlines);
      remaining -= data.length;

      // The openTime of the first (earliest) candle in the returned set
      const earliestOpenTime = data[0][0];
      currentEndTime = earliestOpenTime - 1;

      // Prevent infinite loop if we get fewer items than requested but can't go older
      if (data.length < fetchLimit) {
        break; 
      }
    }

    if (allKlines.length === 0) {
      return [];
    }

    // Sort by open time ascending
    allKlines.sort((a, b) => a[0] - b[0]);

    // De-duplicate in case of timestamp overlaps
    const uniqueKlinesMap = new Map<number, any>();
    allKlines.forEach(k => uniqueKlinesMap.set(k[0], k));
    const uniqueSortedKlines = Array.from(uniqueKlinesMap.values()).sort((a, b) => a[0] - b[0]);

    // Slice to the requested limit from the end (take the most recent)
    const finalKlines = uniqueSortedKlines.slice(-limit);

    return finalKlines.map(k => ({
      time: k[0],
      open: parseFloat(k[1]),
      high: parseFloat(k[2]),
      low: parseFloat(k[3]),
      close: parseFloat(k[4]),
      volume: parseFloat(k[5]),
      wickUpper: parseFloat(k[2]) - Math.max(parseFloat(k[1]), parseFloat(k[4])),
      wickLower: Math.min(parseFloat(k[1]), parseFloat(k[4])) - parseFloat(k[3]),
      bodySize: Math.abs(parseFloat(k[4]) - parseFloat(k[1]))
    }));
  } catch (error) {
    console.warn("Market Data Service primary source failed, using fallback.", error);
    return [];
  }
};

export const fetchInstitutionalLevels = async (symbol: string): Promise<{ pdh: number; pdl: number } | null> => {
  try {
    const response = await fetch(`https://api.binance.com/api/v3/ticker/24hr?symbol=${symbol}`);
    if (!response.ok) throw new Error("Binance API unreachable");
    const data = await response.json();
    if (data.highPrice && data.lowPrice) {
      return {
        pdh: parseFloat(data.highPrice),
        pdl: parseFloat(data.lowPrice)
      };
    }
    return null;
  } catch (error) {
    return null;
  }
};

export const fetchHTFData = async (symbol: string, interval: '1h' | '1d' = '1h'): Promise<Candle[]> => {
  try {
    const response = await fetch(`https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=50`);
    if (!response.ok) throw new Error("Failed to fetch klines");
    const data = await response.json();
    if (!Array.isArray(data)) return [];
    return data.map(k => ({
      time: k[0],
      open: parseFloat(k[1]),
      high: parseFloat(k[2]),
      low: parseFloat(k[3]),
      close: parseFloat(k[4]),
      volume: parseFloat(k[5]),
      wickUpper: parseFloat(k[2]) - Math.max(parseFloat(k[1]), parseFloat(k[4])),
      wickLower: Math.min(parseFloat(k[1]), parseFloat(k[4])) - parseFloat(k[3]),
      bodySize: Math.abs(parseFloat(k[4]) - parseFloat(k[1]))
    }));
  } catch (error) {
    return [];
  }
};

export const fetchLivePrice = async (symbol: string = 'BTCUSDT'): Promise<number | null> => {
  const sources = [
    async () => {
      const res = await fetch(`/api/price?symbol=${symbol}`);
      const data = await res.json();
      return parseFloat(data.price);
    },
    async () => {
      const res = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${symbol}`);
      const data = await res.json();
      return parseFloat(data.price);
    },
    async () => {
      const pair = symbol.replace('USDT', '-USD');
      const res = await fetch(`https://api.coinbase.com/v2/prices/${pair}/spot`);
      const data = await res.json();
      return parseFloat(data.data.amount);
    }
  ];

  for (const source of sources) {
    try {
      const price = await source();
      if (!isNaN(price) && price > 0) return price;
    } catch (e) {
      continue;
    }
  }
  return null;
};

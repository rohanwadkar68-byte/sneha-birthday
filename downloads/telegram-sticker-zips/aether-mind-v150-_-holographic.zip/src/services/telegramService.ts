/**
 * Telegram Communication Service
 * Connects the Neural Core to the user's mobile interface.
 */

export const sendTelegramAlert = async (message: string, retries = 3) => {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout

    // Ensure absolute path resolution for reliable fetch in nested routes
    const endpoint = typeof window !== 'undefined' 
      ? `${window.location.origin}/api/telegram` 
      : '/api/telegram';

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message }),
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    
    // Check for empty or non-JSON responses
    const contentType = response.headers.get("content-type");
    if (contentType && contentType.includes("application/json")) {
      const data = await response.json();
      if (!response.ok) {
        console.warn("Telegram Dispatch Audit:", data);
        return data;
      }
      return data;
    } else {
      const text = await response.text();
      console.warn("Non-JSON Response from Telegram Bridge:", text);
      return { error: 'Invalid response from bridge', detail: text.substring(0, 100) };
    }
  } catch (error: any) {
    if (retries > 0) {
      await new Promise(r => setTimeout(r, 2000));
      return sendTelegramAlert(message, retries - 1);
    }
    console.debug("Telegram broadcast skipped:", error.message);
    return { error: 'TELEGRAM_OFFLINE' };
  }
};

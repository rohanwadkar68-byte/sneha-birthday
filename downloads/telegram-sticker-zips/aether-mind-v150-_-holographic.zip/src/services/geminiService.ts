import { GoogleGenAI, Type } from "@google/genai";

let genAIInstance: GoogleGenAI | null = null;

const getGenAI = () => {
  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    throw new Error("GEMINI_API_KEY is not configured in the environment.");
  }
  if (!genAIInstance) {
    genAIInstance = new GoogleGenAI({ apiKey: key });
  }
  return genAIInstance;
};

export interface ValidationResult {
  valid: boolean;
  reason: string;
  confidence: number;
}

const retry = async <T>(fn: () => Promise<T>, retries = 5, delay = 1500): Promise<T> => {
  try {
    return await fn();
  } catch (error: any) {
    const detail = error.message?.toLowerCase() || "";
    // Expanded transient detection for Google RPC/XHR/Fetch errors
    const isTransient = 
      detail.includes('500') || 
      detail.includes('xhr') || 
      detail.includes('fetch') || 
      detail.includes('rpc failed') ||
      detail.includes('internal error') ||
      detail.includes('quota') || // Sometimes quota is transient
      detail.includes('timeout');

    if (retries > 0 && isTransient) {
      console.log(`Neural Link unstable [${detail}]. Retrying in ${delay}ms... (${retries} attempts left)`);
      await new Promise(r => setTimeout(r, delay));
      return retry(fn, retries - 1, delay * 2);
    }
    
    if (detail.includes('403') || detail.includes('permission') || detail.includes('api_key_invalid')) {
      throw new Error("403_PERMISSION_DENIED: Your GEMINI_API_KEY is invalid or restricted. Please check 'Settings' -> 'Secrets' in the AI Studio editor and ensure the key is correct.");
    }
    
    throw error;
  }
};

export const analyzeTradeWithGemini = async (data: {
  marketContext: string;
  strategy: string;
  score: number;
  delta: string;
  wickUpper: string;
  wickLower: string;
}): Promise<ValidationResult> => {
  const prompt = `
    Analyze this trading setup for a professional hedge fund.
    CONTEXT: ${data.marketContext}
    STRATEGY: ${data.strategy}
    CONFLUENCE_SCORE: ${data.score}/6
    PRICE_ACTION: Delta ${data.delta}, Wicks U:${data.wickUpper}/L:${data.wickLower}
    
    Return a professional assessment of whether to execute this trade.
  `.trim();

  try {
    const ai = getGenAI();
    const response = await retry(async () => {
      return await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          systemInstruction: "You are the QUANT_ELITE_PRO Neural Analyst. Objective: 75%+ Win-Rate. Focus: INSTITUTIONAL INDUCEMENT & DISPLACEMENT. Your job is to verify 'Stop Hunts' (price breaking recent liquidity prior to MSS), 'Silver Bullet' execution (Killzone alignment), and 'Displacement' (high energy institutional impulsive moves). REJECT all retail patterns or low-energy consolidations. A pro trader enters ONLY after retail has been trapped at a support/resistance level and smart money has displaced the price through that level. Analyze the 'Inducement Low/High' specifically.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              valid: { type: Type.BOOLEAN },
              reason: { type: Type.STRING },
              confidence: { type: Type.NUMBER },
            },
            required: ["valid", "reason", "confidence"],
          },
        },
      });
    });

    const text = response.text;
    if (!text) throw new Error("Empty response from AI");
    return JSON.parse(text);
  } catch (error: any) {
    console.error("Critical Neural Interface Failure:", error);
    const detail = error.message || JSON.stringify(error);
    return {
      valid: false,
      reason: `Neural Link Lost: ${detail.substring(0, 150)}`,
      confidence: 0,
    };
  }
};

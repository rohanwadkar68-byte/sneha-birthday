/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs/promises";
import "dotenv/config";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const MEMORY_FILE = path.join(process.cwd(), "memory.json");

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware
  app.use(express.json());

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", time: new Date().toISOString() });
  });

  // Memory Persistence API
  app.get("/api/memory", async (req, res) => {
    try {
      const data = await fs.readFile(MEMORY_FILE, "utf-8");
      res.json(JSON.parse(data));
    } catch (error) {
      res.status(500).json({ error: "Failed to load memory" });
    }
  });

  app.post("/api/memory", async (req, res) => {
    try {
      const { memory } = req.body;
      await fs.writeFile(MEMORY_FILE, JSON.stringify(memory, null, 2), "utf-8");
      res.json({ status: "saved" });
    } catch (error) {
      res.status(500).json({ error: "Failed to save memory" });
    }
  });

  app.post("/api/telegram", async (req, res) => {
    try {
      const { message } = req.body;
      const token = process.env.TELEGRAM_BOT_TOKEN;
      const chatId = process.env.TELEGRAM_CHAT_ID;

      if (!token || !chatId) {
        console.warn("[Telegram Bridge] Credentials missing. skipping alert.");
        return res.status(200).json({ success: false, error: "Credentials missing" });
      }

      console.log(`[Telegram Bridge] Dispatching neural alert... (len: ${message.length})`);

      const telegramUrl = `https://api.telegram.org/bot${token}/sendMessage`;
      const controller = new AbortController();
      const timeout = setTimeout(() => {
        controller.abort();
        console.error("[Telegram Bridge] EXTERNAL_TIMEOUT: Telegram API too slow.");
      }, 12000); 

      try {
        const response = await fetch(telegramUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            chat_id: chatId,
            text: message,
            parse_mode: "HTML"
          }),
          signal: controller.signal
        });
        clearTimeout(timeout);

        const data = await response.json();
        if (!response.ok) {
          console.error("[Telegram Bridge] API_FAILURE:", data);
          return res.status(response.status).json(data);
        }
        res.json({ success: true, data });
      } catch (innerError: any) {
        clearTimeout(timeout);
        throw innerError;
      }
    } catch (error: any) {
      const isTime = error.name === 'AbortError';
      console.error(`[Telegram Bridge] ${isTime ? 'TIMEOUT' : 'ERROR'}:`, error.message);
      res.status(isTime ? 504 : 500).json({ 
        error: isTime ? "Gateway Timeout" : "Telegram Dispatch Failed",
        detail: error.message 
      });
    }
  });

  app.get("/api/market-data", async (req, res) => {
    try {
      const { symbol, interval, limit, endTime } = req.query;
      let binanceUrl = `https://api.binance.com/api/v3/klines?symbol=${symbol || 'BTCUSDT'}&interval=${interval || '1h'}&limit=${limit || 1000}`;
      if (endTime) {
        binanceUrl += `&endTime=${endTime}`;
      }
      const response = await fetch(binanceUrl);
      const data = await response.json();
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch market data" });
    }
  });

  app.get("/api/price", async (req, res) => {
    try {
      const { symbol } = req.query;
      const response = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${symbol || 'BTCUSDT'}`);
      const data = await response.json();
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch price" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production static files
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`LiquidityBot Server running on http://localhost:${PORT}`);
  });
}

startServer();
